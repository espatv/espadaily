# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
import io
import math
import os
import random
import shutil
import threading
import time
import urllib.error
import urllib.request
import zipfile
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

_addon = xbmcaddon.Addon()
_ID = _addon.getAddonInfo("id")
_ADDON_PATH = _addon.getAddonInfo("path")
_PROFILE = xbmcvfs.translatePath(_addon.getAddonInfo("profile"))

_SKIN_BASE = os.path.join(_ADDON_PATH, "resources", "skins", "Default", "1080i")
_XML_BASENAME = "script-signature"

_BG_URI = f"special://home/addons/{_ID}/resources/media/white.png"

_TILES_URL = "https://github.com/fullstackcurso/espatv/releases/download/v1.0.1/sig_tiles.zip"
_TILES_DIR = os.path.join(_PROFILE, "sig_tiles")
_TILES_DIR_URI = _addon.getAddonInfo("profile").rstrip("/") + "/sig_tiles"
_TILES_BUNDLED = os.path.join(_ADDON_PATH, "resources", "media", "sig_tiles")
_TILES_BUNDLED_URI = f"special://home/addons/{_ID}/resources/media/sig_tiles"
_TILES_ZIP_MAX_BYTES = 5 * 1024 * 1024

_SOUNDS_DIR = os.path.join(_ADDON_PATH, "resources", "sounds")
_EFECTO_SFX = os.path.join(_SOUNDS_DIR, "efecto.wav")

# ascii.jpg no viene en el addon; se descarga al primer uso y se cachea en el perfil
_ASCII_JPG_URL = "https://github.com/fullstackcurso/espatv/releases/download/v1.0.1/asciied.jpg"
_ASCII_JPG_CACHE = os.path.join(_PROFILE, "asciied.jpg")
_ASCII_JPG_URI = _addon.getAddonInfo("profile").rstrip("/") + "/asciied.jpg"
_DOWNLOAD_TIMEOUT_S = 15
_HEAD_TIMEOUT_S = 8
_DOWNLOAD_MIN_BYTES = 1024
_JPEG_MAGIC = b'\xff\xd8\xff'  # bytes iniciales de cualquier JPEG

# Serializa descargas dentro del mismo proceso. Sin esto, prefetch+on-demand
# pueden truncar el mismo .part mutuamente.
_download_lock = threading.Lock()

# Cuanto tiempo (segundos) tiene que tener un XML antiguo antes de poder borrarlo
# en _cleanup_old_xmls. Evita que un proceso paralelo borre el XML en uso de otro.
_XML_CLEANUP_AGE_S = 60

# Display ascii.jpg (452x440) escalado a altura 1080
_DISPLAY_H = 1080
_DISPLAY_W = int(1080 * 452 / 440)  # ~1109
_OFFSET_X = (1920 - _DISPLAY_W) // 2
_OFFSET_Y = 0

# Jigsaw tiles
_J_GRID_R = 15
_J_GRID_C = 15
_J_DELAY_MAX = 2200
_J_TIME_MIN = 700
_J_TIME_MAX = 1400

# Fondo de chars volando
_BG_CHARS_COUNT = 700
_BG_CHARS_POOL = "oO8#:.,;@*+%/\\|-_=<>"
_BG_DELAY_MAX = 5500
_BG_TIME_MIN = 1200
_BG_TIME_MAX = 2500
_BG_COLOR = "55FFFFFF"  # blanco al 33% opacidad, tenue, no compite con tiles
_BG_FONT = "font13"

# Letterbox cinematografico (barras negras arriba/abajo)
_BAR_H = 80

# Onda de choque (dots radiando desde centro al impacto)
_SHOCK_DOTS = 32
_SHOCK_R_START = 10
_SHOCK_R_END = 600
_SHOCK_DUR_MS = 500

# IDs manipulados dinamicamente
_NAME_LABEL_ID = 100

# Timings
_AUTO_CLOSE_S = 15.0
_ASSEMBLE_AT_S = 4.0
_PUNCH_DUR_S = 0.25
_REVEAL_BEFORE_S = 3.0  # cuanto antes del cierre se retira el letterbox

# Matrix decode (cada char ciclea por chars random antes de fijarse)
_SCRAMBLE_POOL = "!@#$%^&*?ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
_SCRAMBLE_STEP_S = 0.025   # tiempo entre cambios de scramble
_SCRAMBLE_CYCLES = 6       # ciclos antes de fijar el char correcto

# Idle del nombre (post-decode): tick rapido para cursor + onda de brillo
_IDLE_TICK_S = 0.05
_CURSOR_PERIOD_TICKS = 10  # 10 * 50ms = 500ms toggle del cursor
_SHINE_PERIOD_TICKS = 110  # 110 * 50ms = 5.5s entre olas de brillo
_SHINE_PASS_TICKS = 55     # 55 * 50ms = 2.75s para cruzar el texto (lenta)
_SHINE_WINDOW = 3          # ancho de la ola en chars (banda, no punto)
_SHINE_COLOR = "FFFFD700"  # oro pleno, alto contraste contra blanco

_TYPED_TEXT = "Fundado por RubénSDFA1laberot"
_EASTER_EGG_MSG = "¡Enhorabuena! Has descubierto el easter egg"


def _remote_available():
    try:
        req = urllib.request.Request(
            _ASCII_JPG_URL,
            method='HEAD',
            headers={"User-Agent": f"EspaDaily/{_ID}"},
        )
        with urllib.request.urlopen(req, timeout=_HEAD_TIMEOUT_S) as resp:
            return getattr(resp, "status", 200) == 200
    except (urllib.error.HTTPError, urllib.error.URLError):
        return False


def _is_cached_ok():
    """True si el fichero local existe, tiene tamaño minimo y empieza con bytes JPEG."""
    try:
        if not os.path.exists(_ASCII_JPG_CACHE):
            return False
        if os.path.getsize(_ASCII_JPG_CACHE) < _DOWNLOAD_MIN_BYTES:
            return False
        with open(_ASCII_JPG_CACHE, "rb") as f:
            head = f.read(3)
        return head.startswith(_JPEG_MAGIC)
    except OSError:
        return False


def _ensure_ascii_jpg(silent=False):
    """Garantiza que ascii.jpg esta en cache local y es un JPEG valido.
       Devuelve el path local, o None si la descarga falla. silent=True omite la
       notificacion 'Cargando recursos...' (se usa en el prefetch en background).

       Para la concurrencia, un lock serializa las descargas dentro del proceso y
       el .part lleva el PID para que dos procesos no se trunquen entre si (gana
       quien renombra ultimo, mismo contenido). Se valida la cabecera JPEG para
       descartar respuestas HTML de error y se re-chequea el cache tras el lock
       por si otro hilo ya termino.
    """
    if _is_cached_ok():
        return _ASCII_JPG_CACHE

    if not silent:
        xbmcgui.Dialog().notification(
            "EspaDaily", "Cargando recursos...", xbmcgui.NOTIFICATION_INFO, 5000
        )

    with _download_lock:
        # Otro thread del mismo proceso pudo haber descargado mientras esperabamos
        if _is_cached_ok():
            return _ASCII_JPG_CACHE

        os.makedirs(_PROFILE, exist_ok=True)
        xbmc.log(f'[EspaDaily] ascii_signature: descargando {_ASCII_JPG_URL} (silent={silent})', xbmc.LOGINFO)

        tmp_path = f"{_ASCII_JPG_CACHE}.{os.getpid()}.part"
        try:
            req = urllib.request.Request(
                _ASCII_JPG_URL,
                headers={"User-Agent": f"EspaDaily/{_ID}"},
            )
            with urllib.request.urlopen(req, timeout=_DOWNLOAD_TIMEOUT_S) as resp:
                status = getattr(resp, "status", 200)
                if status != 200:
                    raise ValueError(f"HTTP {status}")
                data = resp.read()
            if not data or len(data) < _DOWNLOAD_MIN_BYTES:
                raise ValueError(f"respuesta demasiado corta ({len(data) if data else 0} bytes)")
            if not data.startswith(_JPEG_MAGIC):
                raise ValueError("respuesta no es un JPEG (HTML de error?)")

            with open(tmp_path, "wb") as f:
                f.write(data)
            os.replace(tmp_path, _ASCII_JPG_CACHE)
            xbmc.log(f'[EspaDaily] ascii_signature: descargado ({len(data)} bytes)', xbmc.LOGINFO)
            return _ASCII_JPG_CACHE
        except Exception as e:
            xbmc.log(f'[EspaDaily] ascii_signature: descarga falla: {e}', xbmc.LOGERROR)
            for path in (tmp_path, _ASCII_JPG_CACHE):
                try:
                    if os.path.exists(path) and not _is_cached_ok():
                        os.remove(path)
                except OSError:
                    pass
            return None


def _tiles_complete(dir_path):
    """True si estan los 225 t_RR_CC.jpg esperados en dir_path."""
    try:
        for r in range(_J_GRID_R):
            for c in range(_J_GRID_C):
                if not os.path.exists(os.path.join(dir_path, f"t_{r:02d}_{c:02d}.jpg")):
                    return False
        return True
    except OSError:
        return False


def _ensure_tiles():
    """Garantiza los tiles del jigsaw y devuelve la base URI del <texture>, o None."""
    if _tiles_complete(_TILES_DIR):
        return _TILES_DIR_URI
    if _tiles_complete(_TILES_BUNDLED):
        return _TILES_BUNDLED_URI

    with _download_lock:
        # Otro hilo pudo dejarlos listos mientras esperabamos el lock.
        if _tiles_complete(_TILES_DIR):
            return _TILES_DIR_URI

        tmp_dir = f"{_TILES_DIR}.{os.getpid()}.tmp"
        try:
            xbmc.log(f'[EspaDaily] ascii_signature: descargando {_TILES_URL}', xbmc.LOGINFO)
            req = urllib.request.Request(_TILES_URL, headers={"User-Agent": f"EspaDaily/{_ID}"})
            with urllib.request.urlopen(req, timeout=_DOWNLOAD_TIMEOUT_S) as resp:
                if getattr(resp, "status", 200) != 200:
                    raise ValueError(f"HTTP {getattr(resp, 'status', '?')}")
                data = resp.read()
            if not data or len(data) < _DOWNLOAD_MIN_BYTES:
                raise ValueError(f"respuesta demasiado corta ({len(data) if data else 0} bytes)")
            if len(data) > _TILES_ZIP_MAX_BYTES:
                raise ValueError(f"zip demasiado grande ({len(data)} bytes)")
            if not data.startswith(b"PK"):
                raise ValueError("la respuesta no es un ZIP")

            shutil.rmtree(tmp_dir, ignore_errors=True)
            os.makedirs(tmp_dir, exist_ok=True)
            tmp_real = os.path.realpath(tmp_dir)
            with zipfile.ZipFile(io.BytesIO(data)) as zf:
                for entry in zf.namelist():
                    dest = os.path.realpath(os.path.join(tmp_dir, entry))
                    if dest != tmp_real and not dest.startswith(tmp_real + os.sep):
                        raise ValueError(f"entrada sospechosa en el zip: {entry}")
                zf.extractall(tmp_dir)

            if not _tiles_complete(tmp_dir):
                raise ValueError("el zip no contiene los 225 tiles esperados")

            # Mover a su sitio. os.replace no admite dir destino no vacio en Windows, asi que
            # se borra antes. El lock serializa; el peor caso de carrera entre procesos es un
            # fallo aislado, no corrupcion.
            if os.path.isdir(_TILES_DIR):
                shutil.rmtree(_TILES_DIR, ignore_errors=True)
            os.replace(tmp_dir, _TILES_DIR)
            xbmc.log('[EspaDaily] ascii_signature: tiles descargados', xbmc.LOGINFO)
            return _TILES_DIR_URI
        except Exception as e:
            xbmc.log(f'[EspaDaily] ascii_signature: tiles fallo: {e}', xbmc.LOGERROR)
            shutil.rmtree(tmp_dir, ignore_errors=True)
            # Si otro proceso los dejo validos pese a nuestro fallo, usalos.
            if _tiles_complete(_TILES_DIR):
                return _TILES_DIR_URI
            return None


def _xml_escape(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _play_sfx(path):
    if not os.path.exists(path):
        return
    try:
        xbmc.playSFX(path)
    except Exception as e:
        xbmc.log(f'[EspaDaily] playSFX fallo: {e}', xbmc.LOGDEBUG)


def _wrap_window(controls_xml):
    return f"""<?xml version="1.0" encoding="utf-8"?>
<window>
    <defaultcontrol>2</defaultcontrol>
    <controls>
        <control type="image">
            <left>0</left><top>0</top>
            <width>1920</width><height>1080</height>
            <texture>{_BG_URI}</texture>
            <colordiffuse>FF000000</colordiffuse>
        </control>

{controls_xml}

        <control type="button" id="2">
            <left>0</left><top>1200</top>
            <width>1</width><height>1</height>
            <label> </label>
            <visible>false</visible>
        </control>
    </controls>
</window>
"""


def _write_xml(xml, xml_name):
    """Escribe el XML al disco. Devuelve el path absoluto."""
    if not os.path.exists(_SKIN_BASE):
        os.makedirs(_SKIN_BASE)
    path = os.path.join(_SKIN_BASE, xml_name)
    with open(path, "w", encoding="utf-8") as f:
        f.write(xml)
    return path


def _make_xml_name():
    """Nombre unico por invocacion para defeat el cache de WindowXMLDialog de Kodi."""
    return f"{_XML_BASENAME}-{int(time.time() * 1000)}.xml"


def _cleanup_old_xmls(keep_name):
    """Borra XMLs viejos del basename signature.
       Solo elimina los que llevan mas de _XML_CLEANUP_AGE_S segundos sin tocar,
       para no pisar XMLs que pueda estar usando un proceso paralelo.
    """
    cutoff = time.time() - _XML_CLEANUP_AGE_S
    try:
        for fname in os.listdir(_SKIN_BASE):
            if not (fname.startswith(_XML_BASENAME) and fname.endswith(".xml")):
                continue
            if fname == keep_name:
                continue
            path = os.path.join(_SKIN_BASE, fname)
            try:
                if os.path.getmtime(path) < cutoff:
                    os.remove(path)
            except OSError:
                pass
    except OSError:
        pass


def _build_bg_chars(rng):
    blocks = []
    for _ in range(_BG_CHARS_COUNT):
        ch = rng.choice(_BG_CHARS_POOL)
        x = rng.randint(0, 1900)
        y = rng.randint(0, 1060)
        angle = rng.uniform(0, 2 * math.pi)
        dist = rng.randint(1500, 2800)
        dx = int(math.cos(angle) * dist)
        dy = int(math.sin(angle) * dist)
        delay = rng.randint(0, _BG_DELAY_MAX)
        dur = rng.randint(_BG_TIME_MIN, _BG_TIME_MAX)

        blocks.append(
            f'<control type="label">'
            f'<left>{x}</left><top>{y}</top>'
            f'<width>20</width><height>20</height>'
            f'<font>{_BG_FONT}</font><textcolor>{_BG_COLOR}</textcolor>'
            f'<align>center</align><aligny>center</aligny>'
            f'<label>{_xml_escape(ch)}</label>'
            f'<animation effect="slide" start="{dx},{dy}" end="0,0" '
            f'time="{dur}" delay="{delay}" tween="cubic" easing="out">WindowOpen</animation>'
            f'</control>'
        )
    return blocks


def _build_jigsaw_tiles(rng, tiles_uri):
    """225 tiles del jigsaw con slide+rotate+zoom paralelos. Bounce al aterrizar."""
    tile_w = _DISPLAY_W // _J_GRID_C
    tile_h = _DISPLAY_H // _J_GRID_R

    blocks = []
    for r in range(_J_GRID_R):
        for c in range(_J_GRID_C):
            x = _OFFSET_X + c * tile_w
            y = _OFFSET_Y + r * tile_h
            angle = rng.uniform(0, 2 * math.pi)
            dist = rng.randint(1400, 2400)
            dx = int(math.cos(angle) * dist)
            dy = int(math.sin(angle) * dist)
            delay = rng.randint(0, _J_DELAY_MAX)
            dur = rng.randint(_J_TIME_MIN, _J_TIME_MAX)
            spin = rng.choice((-1, 1)) * rng.randint(180, 540)

            blocks.append(
                f'<control type="image">'
                f'<left>{x}</left><top>{y}</top>'
                f'<width>{tile_w}</width><height>{tile_h}</height>'
                f'<texture>{tiles_uri}/t_{r:02d}_{c:02d}.jpg</texture>'
                f'<animation effect="slide" start="{dx},{dy}" end="0,0" '
                f'time="{dur}" delay="{delay}" tween="bounce" easing="out">WindowOpen</animation>'
                f'<animation effect="rotate" center="auto" start="0" end="{spin}" '
                f'time="{dur}" delay="{delay}" tween="cubic" easing="out">WindowOpen</animation>'
                f'<animation effect="zoom" center="auto" start="30" end="100" '
                f'time="{dur}" delay="{delay}" tween="cubic" easing="out">WindowOpen</animation>'
                f'</control>'
            )
    return blocks


def _build_tiles_group(tiles_xml):
    """Envuelve los tiles en un group con solo el punch zoom condicional."""
    return f"""<control type="group">
    <animation effect="zoom" center="auto" start="100" end="106" time="120"
               condition="String.IsEqual(Window.Property(punch),true)">Conditional</animation>
{tiles_xml}
</control>"""


def _build_shockwave():
    """32 dots blancos saliendo radialmente del centro cuando punch=true."""
    cx, cy = 960, 540
    blocks = []
    for i in range(_SHOCK_DOTS):
        a = (i / _SHOCK_DOTS) * 2 * math.pi
        x = int(cx + math.cos(a) * _SHOCK_R_START) - 10
        y = int(cy + math.sin(a) * _SHOCK_R_START) - 10
        dx = int(math.cos(a) * (_SHOCK_R_END - _SHOCK_R_START))
        dy = int(math.sin(a) * (_SHOCK_R_END - _SHOCK_R_START))
        blocks.append(
            f'<control type="label">'
            f'<left>{x}</left><top>{y}</top>'
            f'<width>20</width><height>20</height>'
            f'<font>{_BG_FONT}</font><textcolor>FFFFFFFF</textcolor>'
            f'<align>center</align><aligny>center</aligny>'
            f'<label>·</label>'
            f'<visible>String.IsEqual(Window.Property(punch),true)</visible>'
            f'<animation effect="slide" start="0,0" end="{dx},{dy}" '
            f'time="{_SHOCK_DUR_MS}" tween="cubic" easing="out" '
            f'condition="String.IsEqual(Window.Property(punch),true)">Conditional</animation>'
            f'<animation effect="fade" start="100" end="0" '
            f'time="{_SHOCK_DUR_MS}" '
            f'condition="String.IsEqual(Window.Property(punch),true)">Conditional</animation>'
            f'</control>'
        )
    return blocks


def _build_letterbox():
    """Barras cinematograficas:
       - Entran al abrir (WindowOpen)
       - Se retiran a t=12s para revelar el retrato completo (Property reveal)
       - Se retiran tambien en cierre anticipado (WindowClose)
    """
    top = (
        f'<control type="image">'
        f'<left>0</left><top>0</top>'
        f'<width>1920</width><height>{_BAR_H}</height>'
        f'<texture>{_BG_URI}</texture>'
        f'<colordiffuse>FF000000</colordiffuse>'
        f'<animation effect="slide" start="0,-{_BAR_H}" end="0,0" '
        f'time="600" tween="cubic" easing="out">WindowOpen</animation>'
        f'<animation effect="slide" start="0,0" end="0,-{_BAR_H}" '
        f'time="900" tween="cubic" easing="inout" reversible="false" '
        f'condition="String.IsEqual(Window.Property(reveal),true)">Conditional</animation>'
        f'<animation effect="slide" start="0,0" end="0,-{_BAR_H}" '
        f'time="400" tween="cubic" easing="in">WindowClose</animation>'
        f'</control>'
    )
    bot = (
        f'<control type="image">'
        f'<left>0</left><top>{1080 - _BAR_H}</top>'
        f'<width>1920</width><height>{_BAR_H}</height>'
        f'<texture>{_BG_URI}</texture>'
        f'<colordiffuse>FF000000</colordiffuse>'
        f'<animation effect="slide" start="0,{_BAR_H}" end="0,0" '
        f'time="600" tween="cubic" easing="out">WindowOpen</animation>'
        f'<animation effect="slide" start="0,0" end="0,{_BAR_H}" '
        f'time="900" tween="cubic" easing="inout" reversible="false" '
        f'condition="String.IsEqual(Window.Property(reveal),true)">Conditional</animation>'
        f'<animation effect="slide" start="0,0" end="0,{_BAR_H}" '
        f'time="400" tween="cubic" easing="in">WindowClose</animation>'
        f'</control>'
    )
    return [top, bot]


def _build_name_label():
    """Label centrado en la barra inferior, vacio al inicio; se rellena por codigo.
       Se funde a 0 cuando reveal=true (3s antes del cierre) para dejar el retrato limpio.
    """
    return (
        f'<control type="label" id="{_NAME_LABEL_ID}">'
        f'<left>0</left><top>{1080 - _BAR_H + 15}</top>'
        f'<width>1920</width><height>50</height>'
        f'<font>font13</font><textcolor>FFFFFFFF</textcolor>'
        f'<align>center</align><aligny>center</aligny>'
        f'<label></label>'
        f'<animation effect="fade" start="100" end="0" time="700" reversible="false" '
        f'condition="String.IsEqual(Window.Property(reveal),true)">Conditional</animation>'
        f'</control>'
    )


def _build_full_image_overlay():
    """ascii.jpg como overlay sin costuras. Cubre el mosaico de tiles
       fundiendose al impacto (t=4s) para dar imagen final limpia.
    """
    return (
        f'<control type="image">'
        f'<left>{_OFFSET_X}</left><top>{_OFFSET_Y}</top>'
        f'<width>{_DISPLAY_W}</width><height>{_DISPLAY_H}</height>'
        f'<texture>{_ASCII_JPG_URI}</texture>'
        f'<animation effect="fade" start="0" end="100" '
        f'time="400" delay="{int(_ASSEMBLE_AT_S * 1000)}">WindowOpen</animation>'
        f'</control>'
    )


def _build_underline():
    """Linea blanca fina bajo el nombre. Crece desde el centro hacia los lados
       cuando se completa el decode (named=true). Se funde con el reveal final.
    """
    w = 380
    left = (1920 - w) // 2
    top = 1080 - _BAR_H + 55  # justo bajo el nombre
    return (
        f'<control type="image">'
        f'<left>{left}</left><top>{top}</top>'
        f'<width>{w}</width><height>2</height>'
        f'<texture>{_BG_URI}</texture>'
        f'<colordiffuse>FFFFFFFF</colordiffuse>'
        f'<visible>String.IsEqual(Window.Property(named),true)</visible>'
        f'<animation effect="zoom" center="auto" start="0" end="100" '
        f'time="600" tween="cubic" easing="out">Visible</animation>'
        f'<animation effect="fade" start="100" end="0" time="700" reversible="false" '
        f'condition="String.IsEqual(Window.Property(reveal),true)">Conditional</animation>'
        f'</control>'
    )


def _build_xml(tiles_uri):
    rng = random.Random()
    bg = _build_bg_chars(rng)
    tiles = _build_jigsaw_tiles(rng, tiles_uri)
    tiles_group = _build_tiles_group("\n".join(tiles))
    full_image = _build_full_image_overlay()
    shockwave = _build_shockwave()
    letterbox = _build_letterbox()
    name_label = _build_name_label()
    underline = _build_underline()

    # Z-order (de fondo a primer plano):
    #   1. chars BG (mas alejados)
    #   2. group de tiles (con punch), animacion de convergencia
    #   3. JPG completa, overlay limpio a partir del impacto (t=4s)
    #   4. shockwave (sobre la JPG durante el impacto)
    #   5. letterbox bars (marcos negros)
    #   6. nombre + subrayado
    all_controls = (
        "\n".join(bg) + "\n" +
        tiles_group + "\n" +
        full_image + "\n" +
        "\n".join(shockwave) + "\n" +
        "\n".join(letterbox) + "\n" +
        name_label + "\n" +
        underline
    )
    return _wrap_window(all_controls)


class AsciiSignatureDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._cancelled = False
        self._auto_close_timer = None
        self._assemble_timer = None
        self._unpunch_timer = None
        self._reveal_timer = None

    def onInit(self):
        xbmc.log('[EspaDaily] ascii_signature: onInit', xbmc.LOGINFO)
        self._auto_close_timer = threading.Timer(_AUTO_CLOSE_S, self.close)
        self._auto_close_timer.daemon = True
        self._auto_close_timer.start()

        self._assemble_timer = threading.Timer(_ASSEMBLE_AT_S, self._on_assembled)
        self._assemble_timer.daemon = True
        self._assemble_timer.start()

        self._reveal_timer = threading.Timer(
            _AUTO_CLOSE_S - _REVEAL_BEFORE_S, self._reveal_image
        )
        self._reveal_timer.daemon = True
        self._reveal_timer.start()

        _play_sfx(_EFECTO_SFX)

    def _on_assembled(self):
        if self._cancelled:
            return
        xbmc.log('[EspaDaily] ascii_signature: _on_assembled (t=4s)', xbmc.LOGINFO)
        xbmcgui.Dialog().notification(
            "EspaDaily", _EASTER_EGG_MSG, xbmcgui.NOTIFICATION_INFO, 4000
        )
        self.setProperty("punch", "true")

        self._unpunch_timer = threading.Timer(_PUNCH_DUR_S, self._clear_punch)
        self._unpunch_timer.daemon = True
        self._unpunch_timer.start()

        threading.Thread(target=self._type_name, daemon=True).start()

    def _clear_punch(self):
        if self._cancelled:
            return
        self.setProperty("punch", "false")

    def _reveal_image(self):
        if self._cancelled:
            return
        xbmc.log('[EspaDaily] ascii_signature: reveal (t=12s)', xbmc.LOGINFO)
        self.setProperty("reveal", "true")

    def _type_name(self):
        try:
            lbl = self.getControl(_NAME_LABEL_ID)
        except Exception:
            return

        # FASE 1: Matrix decode, cada char ciclea por random antes de fijarse
        decoded = ""
        for target_ch in _TYPED_TEXT:
            if self._cancelled:
                return
            if target_ch == " ":
                decoded += " "
                try:
                    lbl.setLabel(decoded + "|")
                except Exception:
                    return
                time.sleep(_SCRAMBLE_STEP_S * 2)
                continue
            for _ in range(_SCRAMBLE_CYCLES):
                if self._cancelled:
                    return
                scramble_ch = random.choice(_SCRAMBLE_POOL)
                try:
                    lbl.setLabel(decoded + scramble_ch + "|")
                except Exception:
                    return
                time.sleep(_SCRAMBLE_STEP_S)
            decoded += target_ch
            try:
                lbl.setLabel(decoded + "|")
            except Exception:
                return

        # Subrayado aparece al completarse el nombre
        self.setProperty("named", "true")

        # FASE 2: Idle, cursor parpadeando + onda de brillo recorriendo el texto
        tick = 0
        n = len(_TYPED_TEXT)
        half_win = _SHINE_WINDOW // 2
        # Rango efectivo para que la ola entre/salga limpio por los bordes:
        # shine_pos va de -half_win a n+half_win, asi la banda se ve aparecer y salir
        shine_range = n + _SHINE_WINDOW
        while not self._cancelled:
            cycle = tick % _SHINE_PERIOD_TICKS
            cursor = "|" if (tick // _CURSOR_PERIOD_TICKS) % 2 == 0 else " "
            if cycle < _SHINE_PASS_TICKS:
                shine_center = int((cycle / _SHINE_PASS_TICKS) * shine_range) - half_win
                start = max(0, shine_center - half_win)
                end = min(n, shine_center + half_win + 1)
            else:
                start = end = 0
            if start < end:
                label = (
                    _TYPED_TEXT[:start]
                    + f"[COLOR {_SHINE_COLOR}]" + _TYPED_TEXT[start:end] + "[/COLOR]"
                    + _TYPED_TEXT[end:]
                    + cursor
                )
            else:
                label = _TYPED_TEXT + cursor
            try:
                lbl.setLabel(label)
            except Exception:
                return
            tick += 1
            time.sleep(_IDLE_TICK_S)

    def close(self):
        self._cancelled = True
        for t in (self._auto_close_timer, self._assemble_timer,
                  self._unpunch_timer, self._reveal_timer):
            if t is not None:
                t.cancel()
        super().close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 110, 216):
            self.close()


def show_signature():
    """Lanza la animacion Jigsaw con todos los efectos.
       Antes de empezar descarga ascii.jpg si no esta cacheada; si la descarga
       falla, no se lanza la animacion.
    """
    try:
        if not _remote_available():
            xbmcgui.Dialog().notification(
                "EspaDaily",
                "Recurso no disponible en GitHub",
                xbmcgui.NOTIFICATION_ERROR,
                4000,
            )
            return
        jpg_path = _ensure_ascii_jpg()
        if not jpg_path:
            xbmcgui.Dialog().notification(
                "EspaDaily",
                "No se pudieron cargar los recursos",
                xbmcgui.NOTIFICATION_ERROR,
                4000,
            )
            return

        tiles_uri = _ensure_tiles()
        if not tiles_uri:
            xbmcgui.Dialog().notification(
                "EspaDaily",
                "No se pudieron cargar los recursos",
                xbmcgui.NOTIFICATION_ERROR,
                4000,
            )
            return

        xml = _build_xml(tiles_uri)
        xml_name = _make_xml_name()
        _write_xml(xml, xml_name)
        _cleanup_old_xmls(xml_name)
        xbmc.log(f'[EspaDaily] ascii_signature: lanzando {xml_name}', xbmc.LOGINFO)
        dlg = AsciiSignatureDialog(xml_name, _ADDON_PATH, "Default", "1080i")
        dlg.doModal()
        del dlg
    except Exception as e:
        xbmc.log(f'[EspaDaily] ascii_signature error: {e}', xbmc.LOGERROR)
