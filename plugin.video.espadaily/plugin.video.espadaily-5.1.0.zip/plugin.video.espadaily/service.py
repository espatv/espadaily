# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
import time
import xbmc
import xbmcaddon

_ADDON_ID = 'plugin.video.espadaily'
_DELAY_MAP    = [0, 5, 10, 15, 30, 60]
_DELAY_LABELS = ['Sin espera', '5 seg', '10 seg', '15 seg', '30 seg', '1 min']


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[EspaDaily Service] {msg}', level)


def _parse_delay(raw):
    # El menú interno guarda el texto del label ("30 seg").
    # si por algún motivo hay un índice numérico ("4") también funciona.
    try:
        idx = int(raw)
        return _DELAY_MAP[idx] if 0 <= idx < len(_DELAY_MAP) else 0
    except (ValueError, TypeError):
        try:
            return _DELAY_MAP[_DELAY_LABELS.index(raw)]
        except ValueError:
            return 0


def _collect_tasks():
    # Devuelve tareas {'delay', 'cmd', 'check_id'} combinando addons y favoritos.
    # check_id != None solo en addons, para avisar si están desinstalados.
    try:
        addon = xbmcaddon.Addon(_ADDON_ID)
    except RuntimeError:
        _log('No se pudo cargar el addon.', xbmc.LOGERROR)
        return []
    tasks = []
    for i in range(1, 4):
        if addon.getSetting(f'autostart_{i}_enabled') != 'true':
            continue
        addon_id = addon.getSetting(f'autostart_{i}_id').strip()
        if not addon_id:
            continue
        delay = _parse_delay(addon.getSetting(f'autostart_{i}_delay'))
        tasks.append({'delay': delay, 'cmd': f'RunAddon({addon_id})', 'check_id': addon_id})
    for i in range(1, 4):
        if addon.getSetting(f'autofav_{i}_enabled') != 'true':
            continue
        cmd = addon.getSetting(f'autofav_{i}_cmd').strip()
        if not cmd:
            continue
        delay = _parse_delay(addon.getSetting(f'autofav_{i}_delay'))
        tasks.append({'delay': delay, 'cmd': cmd, 'check_id': None})
    tasks.sort(key=lambda t: t['delay'])
    return tasks


def _wait_ready(monitor):
    for _ in range(600):  # max 60 s (100 ms por iteración)
        if monitor.abortRequested():
            return False
        if not xbmc.getCondVisibility('Window.IsVisible(startup)'):
            return True
        xbmc.sleep(100)
    return not monitor.abortRequested()


def _launch(task):
    check_id = task['check_id']
    if check_id:
        try:
            xbmcaddon.Addon(check_id)
        except RuntimeError:
            _log(f'Addon no instalado o desactivado: {check_id}', xbmc.LOGWARNING)
            return
    xbmc.executebuiltin(task['cmd'])
    _log(f'Lanzado: {task["cmd"]}', xbmc.LOGINFO)


def _run_autostart(monitor):
    tasks = _collect_tasks()
    if not tasks:
        return  # nada configurado
    _log(f'Tareas activas: {[t["cmd"] for t in tasks]}', xbmc.LOGINFO)
    if not _wait_ready(monitor):
        return

    # t0: momento en que Kodi está listo. Los delays de cada tarea son ABSOLUTOS
    # desde este instante, no acumulativos. La lista va ordenada por delay, así que
    # un favorito con retardo corto no espera a un addon con retardo largo.
    t0 = time.time()

    for task in tasks:
        if monitor.abortRequested():
            break
        remaining = task['delay'] - (time.time() - t0)
        if remaining > 0 and monitor.waitForAbort(remaining):
            break
        if not monitor.abortRequested():
            _launch(task)


def _autostart_webapp(monitor):
    # La webapp se lanza vía el plugin (RunPlugin), no importando webapp aquí: el
    # servidor depende del módulo `connector`, que solo carga default.py. En el
    # contexto del servicio ese módulo no existe. RunPlugin arranca la webapp en el
    # mismo camino que el menú manual, donde su hilo daemon sí sobrevive.
    try:
        if xbmcaddon.Addon(_ADDON_ID).getSetting('webapp_autostart') != 'true':
            return
    except RuntimeError:
        _log('No se pudo cargar el addon.', xbmc.LOGERROR)
        return
    if not _wait_ready(monitor):
        return
    xbmc.executebuiltin(f'RunPlugin(plugin://{_ADDON_ID}/?action=webapp_espa_autostart)')
    _log('Autostart de la webapp disparado.', xbmc.LOGINFO)


def run():
    monitor = xbmc.Monitor()
    crt = None
    try:
        if xbmcaddon.Addon(_ADDON_ID).getSetting('crt_enabled') == 'true':
            import crt_overlay
            crt = crt_overlay.CrtManager()  # mantiene viva la ref al Player
            _log('Modo CRT activo: servicio persistente arrancado.', xbmc.LOGINFO)
    except Exception as e:
        # El filtro CRT jamás debe impedir el autostart; si algo falla, se loguea
        # y se continúa sin él.
        crt = None
        _log(f'No se pudo iniciar el filtro CRT, se continúa sin él: {e}', xbmc.LOGERROR)

    _run_autostart(monitor)
    _autostart_webapp(monitor)

    if crt is None:
        return  # sin CRT y hecho el autostart: salir sin dejar proceso activo

    # Con el filtro CRT activo el servicio vive toda la sesión escuchando el player.
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
        crt.tick()
    crt.cleanup()


run()
