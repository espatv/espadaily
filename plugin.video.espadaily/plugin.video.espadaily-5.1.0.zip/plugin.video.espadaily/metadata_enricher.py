# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
"""Enriquecimiento centralizado de metadatos de películas y series vía TMDB.
"""
import json
import os
import sqlite3
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import xbmc
import xbmcaddon
import xbmcvfs

from core_settings import _ESPADAILY_TMDB_API_KEY

_TMDB_BASE = "https://api.themoviedb.org/3"
_IMG_W342  = "https://image.tmdb.org/t/p/w342"
_IMG_W185  = "https://image.tmdb.org/t/p/w185"
_IMG_ORIG  = "https://image.tmdb.org/t/p/original"
_TTL_SEC   = 30 * 86400
_LOG_TAG   = "[EspaDaily-ME]"

_KODI_MEDIATYPE = {'movie': 'movie', 'show': 'tvshow'}

_write_lock   = threading.Lock()
_thread_local = threading.local()
_session      = requests.Session()


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("{0} {1}".format(_LOG_TAG, msg), level)


def _api_key():
    return _ESPADAILY_TMDB_API_KEY or ''


def _profile_dir():
    return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))


def _db_path():
    return os.path.join(_profile_dir(), 'espadaily_metadata.db')


def _connection():
    conn = getattr(_thread_local, 'conn', None)
    if conn is not None:
        return conn
    path = _db_path()
    parent = os.path.dirname(path)
    if parent and not os.path.exists(parent):
        os.makedirs(parent, exist_ok=True)
    conn = sqlite3.connect(path, timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS meta ("
        " key TEXT PRIMARY KEY,"
        " data TEXT NOT NULL,"
        " fetched_at INTEGER NOT NULL"
        ")"
    )
    conn.commit()
    _thread_local.conn = conn
    return conn


def _reset_thread_state():
    conn = getattr(_thread_local, 'conn', None)
    if conn is not None:
        try:
            conn.close()
        except sqlite3.Error:
            pass
        del _thread_local.conn


def _cache_get(key):
    if not key:
        return None
    try:
        row = _connection().execute(
            "SELECT data, fetched_at FROM meta WHERE key=?", (key,)
        ).fetchone()
    except sqlite3.Error as e:
        _log("cache_get: {0}".format(e), xbmc.LOGWARNING)
        return None
    if not row or (time.time() - row[1]) >= _TTL_SEC:
        return None
    try:
        return json.loads(row[0])
    except ValueError:
        return None


def _cache_set(key, meta):
    if not key:
        return
    try:
        payload = json.dumps(meta, ensure_ascii=False)
    except (TypeError, ValueError) as e:
        _log("cache_set encode: {0}".format(e), xbmc.LOGWARNING)
        return
    now = int(time.time())
    try:
        with _write_lock:
            conn = _connection()
            conn.execute(
                "INSERT OR REPLACE INTO meta(key, data, fetched_at) VALUES(?,?,?)",
                (key, payload, now),
            )
            conn.commit()
    except sqlite3.Error as e:
        _log("cache_set: {0}".format(e), xbmc.LOGWARNING)


def _delete_keys(keys):
    rows = [(k,) for k in keys if k]
    if not rows:
        return
    try:
        with _write_lock:
            conn = _connection()
            conn.executemany("DELETE FROM meta WHERE key=?", rows)
            conn.commit()
    except sqlite3.Error as e:
        _log("delete_keys: {0}".format(e), xbmc.LOGWARNING)


def delete_by_imdb_ids(imdb_ids):
    _delete_keys(["imdb:{0}".format(i) for i in imdb_ids if i])


def delete_items(items):
    """Elimina del caché los descriptores ``{tmdb_id, imdb_id, title, year, media_type}``."""
    keys = [
        _canon_key(i.get('tmdb_id'), i.get('imdb_id'), i.get('title'),
                   i.get('year'), i.get('media_type', 'movie'))
        for i in items
    ]
    _delete_keys(keys)


def clear_all():
    """Vacía toda la caché de metadatos."""
    try:
        with _write_lock:
            conn = _connection()
            conn.execute("DELETE FROM meta")
            conn.commit()
    except sqlite3.Error as e:
        _log("clear_all: {0}".format(e), xbmc.LOGWARNING)


def prune_and_vacuum():
    """Borra entradas caducadas (>TTL), compacta la base de datos y devuelve (filas_borradas, bytes_liberados)."""
    path = _db_path()
    if not os.path.exists(path):
        return 0, 0
    try:
        size_before = os.path.getsize(path)
    except OSError:
        size_before = 0
    cutoff = int(time.time()) - _TTL_SEC
    deleted = 0
    with _write_lock:
        _reset_thread_state()
        try:
            conn = sqlite3.connect(path, timeout=10)
        except sqlite3.Error as e:
            _log("prune_and_vacuum connect: {0}".format(e), xbmc.LOGWARNING)
            return 0, 0
        try:
            try:
                cur = conn.execute("DELETE FROM meta WHERE fetched_at < ?", (cutoff,))
                deleted = cur.rowcount or 0
                conn.commit()
            except sqlite3.Error as e:
                _log("prune_and_vacuum delete: {0}".format(e), xbmc.LOGWARNING)
            try:
                conn.execute("VACUUM")
                conn.commit()
            except sqlite3.Error as e:
                _log("prune_and_vacuum vacuum: {0}".format(e), xbmc.LOGWARNING)
        finally:
            try:
                conn.close()
            except sqlite3.Error:
                pass
    try:
        size_after = os.path.getsize(path) if os.path.exists(path) else 0
    except OSError:
        size_after = size_before
    return deleted, max(0, size_before - size_after)


def _to_int(value):
    if value is None or value == '' or isinstance(value, bool):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _canon_key(tmdb_id, imdb_id, title, year, media_type):
    tmdb_int = _to_int(tmdb_id)
    if tmdb_int:
        return "tmdb:{0}:{1}".format(media_type, tmdb_int)
    if imdb_id:
        return "imdb:{0}".format(imdb_id)
    if title:
        normalized = title.lower().strip()
        if normalized:
            return "title:{0}:{1}:{2}".format(media_type, normalized, year or '')
    return None


def _build_cast(credits):
    return [
        {
            'name':      a.get('name', ''),
            'role':      a.get('character', ''),
            'thumbnail': "{0}{1}".format(_IMG_W185, a['profile_path']) if a.get('profile_path') else '',
        }
        for a in (credits.get('cast') or [])[:10]
    ]


def _build_director(media_type, payload):
    crew = (payload.get('credits') or {}).get('crew') or []
    director_from_crew = next(
        (p.get('name', '') for p in crew if p.get('job') == 'Director'),
        '',
    )
    if media_type == 'show':
        creators = ', '.join(
            c.get('name', '') for c in (payload.get('created_by') or []) if c.get('name')
        )
        return creators or director_from_crew
    return director_from_crew


def _parse(d, media_type):
    poster_path   = d.get('poster_path')
    backdrop_path = d.get('backdrop_path')
    credits       = d.get('credits') or {}
    genres        = [g.get('name', '') for g in (d.get('genres') or [])]
    ext_ids       = d.get('external_ids') or {}
    imdb_id       = d.get('imdb_id') or ext_ids.get('imdb_id', '')

    raw_date = d.get('release_date') or d.get('first_air_date') or ''
    year = int(raw_date[:4]) if raw_date[:4].isdigit() else 0

    runtime = d.get('runtime') or 0
    if not runtime and media_type == 'show':
        rt_list = d.get('episode_run_time') or []
        runtime = rt_list[0] if rt_list else 0

    try:
        rating = float(d.get('vote_average') or 0)
    except (TypeError, ValueError):
        rating = 0.0

    return {
        'ids':            {'tmdb': d.get('id'), 'imdb': imdb_id},
        'media_type':     media_type,
        'title':          d.get('title') or d.get('name') or '',
        'original_title': d.get('original_title') or d.get('original_name') or '',
        'year':           year,
        'overview':       d.get('overview') or '',
        'tagline':        d.get('tagline') or '',
        'genres':         genres,
        'rating':         rating,
        'votes':          int(d.get('vote_count') or 0),
        'runtime':        runtime,
        'certification':  '',
        'director':       _build_director(media_type, d),
        'cast':           _build_cast(credits),
        'poster':         "{0}{1}".format(_IMG_W342, poster_path) if poster_path else '',
        'fanart':         "{0}{1}".format(_IMG_ORIG, backdrop_path) if backdrop_path else '',
    }


def _tmdb_get(path, params):
    api_key = _api_key()
    if not api_key:
        return None
    full = dict(params, api_key=api_key)
    try:
        r = _session.get("{0}/{1}".format(_TMDB_BASE, path), params=full, timeout=8)
    except requests.RequestException as e:
        _log("request error ({0}): {1}".format(path, e), xbmc.LOGWARNING)
        return None
    if r.status_code != 200:
        return None
    try:
        return r.json()
    except ValueError:
        return None


def _fetch_by_tmdb_id(tmdb_id, media_type):
    endpoint = 'tv' if media_type == 'show' else 'movie'
    base = {'append_to_response': 'credits,external_ids', 'language': 'es-ES'}
    payload = _tmdb_get("{0}/{1}".format(endpoint, tmdb_id), base)
    if not payload:
        return None
    if not payload.get('overview'):
        en = _tmdb_get("{0}/{1}".format(endpoint, tmdb_id), dict(base, language='en-US'))
        if en and en.get('overview'):
            payload['overview'] = en['overview']
    return _parse(payload, media_type)


def _find_by_imdb(imdb_id, media_type):
    payload = _tmdb_get("find/{0}".format(imdb_id), {'external_source': 'imdb_id'})
    if not payload:
        return None
    movies = payload.get('movie_results') or []
    shows  = payload.get('tv_results') or []
    if media_type == 'show' and shows:
        return _fetch_by_tmdb_id(shows[0].get('id'), 'show')
    if media_type == 'movie' and movies:
        return _fetch_by_tmdb_id(movies[0].get('id'), 'movie')
    if movies:
        return _fetch_by_tmdb_id(movies[0].get('id'), 'movie')
    if shows:
        return _fetch_by_tmdb_id(shows[0].get('id'), 'show')
    return None


def _pick_search_match(results, year, media_type):
    if not results:
        return None
    target = _to_int(year)
    if not target:
        return results[0]
    date_field = 'first_air_date' if media_type == 'show' else 'release_date'
    same_year = [
        r for r in results
        if (r.get(date_field) or '')[:4].isdigit()
        and int((r.get(date_field) or '')[:4]) == target
    ]
    if same_year:
        return max(same_year, key=lambda r: r.get('vote_count') or 0)
    return results[0]


def _search_by_title(title, year, media_type):
    endpoint = 'tv' if media_type == 'show' else 'movie'
    year_key = 'first_air_date_year' if media_type == 'show' else 'year'
    params   = {'query': title, 'language': 'es-ES'}
    if year:
        params[year_key] = year
    payload = _tmdb_get("search/{0}".format(endpoint), params)
    if not payload:
        return None
    pick = _pick_search_match(payload.get('results') or [], year, media_type)
    if not pick:
        return None
    return _fetch_by_tmdb_id(pick.get('id'), media_type)


def enrich(tmdb_id=None, imdb_id=None, title=None, year=None,
           media_type='movie', use_cache_only=False):
    tmdb_int = _to_int(tmdb_id)
    key = _canon_key(tmdb_int, imdb_id, title, year, media_type)
    if not key:
        return {}

    cached = _cache_get(key)
    if cached is not None:
        return cached
    if use_cache_only:
        return {}

    if tmdb_int:
        meta = _fetch_by_tmdb_id(tmdb_int, media_type)
    elif imdb_id:
        meta = _find_by_imdb(imdb_id, media_type)
    elif title:
        meta = _search_by_title(title, year, media_type)
    else:
        meta = None

    if not meta:
        return {}

    _cache_set(key, meta)
    fetched_tmdb = (meta.get('ids') or {}).get('tmdb')
    fetched_imdb = (meta.get('ids') or {}).get('imdb')
    if fetched_tmdb:
        alt = "tmdb:{0}:{1}".format(media_type, fetched_tmdb)
        if alt != key:
            _cache_set(alt, meta)
    if fetched_imdb:
        alt = "imdb:{0}".format(fetched_imdb)
        if alt != key:
            _cache_set(alt, meta)
    return meta


def batch_enrich(items, use_cache_only=False, max_workers=4):
    results = [{} for _ in items]

    def _one(idx, item):
        return idx, enrich(
            tmdb_id=item.get('tmdb_id'),
            imdb_id=item.get('imdb_id'),
            title=item.get('title'),
            year=item.get('year'),
            media_type=item.get('media_type', 'movie'),
            use_cache_only=use_cache_only,
        )

    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = [ex.submit(_one, i, item) for i, item in enumerate(items)]
        for future in as_completed(futures):
            try:
                idx, meta = future.result()
                results[idx] = meta or {}
            except Exception as e:
                _log("batch_enrich item: {0}".format(e), xbmc.LOGWARNING)
    return results


def batch_fetch_with_progress(items, progress_dialog, max_workers=6):
    total = len(items)
    if total == 0:
        return 0

    def _fetch(item):
        return enrich(
            tmdb_id=item.get('tmdb_id'),
            imdb_id=item.get('imdb_id'),
            title=item.get('title'),
            year=item.get('year'),
            media_type=item.get('media_type', 'movie'),
        )

    completed = 0
    success   = 0
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(_fetch, item): item for item in items}
        for future in as_completed(futures):
            if progress_dialog.iscanceled():
                break
            item = futures[future]
            completed += 1
            label = item.get('title') or '...'
            progress_dialog.update(
                int(completed * 100 / total),
                "({0}/{1}) {2}".format(completed, total, label),
            )
            try:
                if future.result():
                    success += 1
            except Exception as e:
                _log("batch_fetch item: {0}".format(e), xbmc.LOGWARNING)
    return success


def _build_plot(meta):
    tagline  = meta.get('tagline') or ''
    overview = meta.get('overview') or ''
    return "[B]{0}[/B]\n\n{1}".format(tagline, overview) if tagline else overview


def _kodi_mediatype(media_type):
    return _KODI_MEDIATYPE.get(media_type, 'movie')


def fetch_watch_providers(tmdb_id, media_type='movie'):
    """Devuelve proveedores en España (flatrate/free/buy/rent) desde TMDB. {} si no hay."""
    tid = _to_int(tmdb_id)
    if not tid:
        return {}
    cache_key = 'providers:{0}:{1}'.format(media_type, tid)
    cached = _cache_get(cache_key)
    if cached is not None:
        return cached
    if not _api_key():
        return {}
    endpoint = 'tv' if media_type == 'show' else 'movie'
    data = _tmdb_get('{0}/{1}/watch/providers'.format(endpoint, tid), {})
    if not data:
        return {}
    es = data.get('results', {}).get('ES', {})
    result = {
        'flatrate': [p['provider_name'] for p in es.get('flatrate', [])],
        'free':     [p['provider_name'] for p in es.get('free', [])],
        'buy':      [p['provider_name'] for p in es.get('buy', [])],
        'rent':     [p['provider_name'] for p in es.get('rent', [])],
        'link':     es.get('link', ''),
    }
    _cache_set(cache_key, result)
    return result


def apply_to_listitem(li, meta, addon_fanart=''):
    if not meta:
        return
    poster = meta.get('poster') or ''
    li.setArt({
        'icon':   'DefaultVideo.png',
        'thumb':  poster,
        'poster': poster,
        'fanart': meta.get('fanart') or addon_fanart,
    })
    info = {
        'title':     meta.get('title') or '',
        'year':      meta.get('year') or 0,
        'plot':      _build_plot(meta),
        'mediatype': _kodi_mediatype(meta.get('media_type')),
        'genre':     ' / '.join(meta.get('genres') or []),
        'rating':    meta.get('rating') or 0,
        'votes':     str(meta.get('votes') or 0),
        'duration':  (meta.get('runtime') or 0) * 60,
    }
    original = meta.get('original_title') or ''
    if original:
        info['originaltitle'] = original
    director = meta.get('director') or ''
    if director:
        info['director'] = director
    certification = meta.get('certification') or ''
    if certification:
        info['mpaa'] = certification
    li.setInfo('video', info)
    cast = meta.get('cast') or []
    if cast:
        li.setCast(cast)
