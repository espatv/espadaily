# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
# Modo TV: guia de canales en directo. Cuadricula de canales a la derecha y la
# programacion (EPG) del canal enfocado a la izquierda. La reproduccion delega
# en las acciones play_live_* del addon via PlayMedia (no resuelve streams aqui).
import sys
import threading
import urllib.parse
from datetime import datetime, timedelta, timezone

import xbmc
import xbmcgui
import xbmcaddon

import connector
import epg_texto

_LOG = "[EspaDaily/ModoTV]"

_ID_EPG = 400
_ID_LOADING = 500
_ID_GRID = 600
_ID_CLOSE_BTN = 901

_FOCUS_POLL_MS = 250
_EPG_NEXT_COUNT = 7

_CLOSE_ACTIONS = {xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK}

# Numero logico de canal, para ordenar igual que el menu de TV en Directo.
_LCN = {
    "La 1": 1, "La 2": 2, "Antena 3": 3, "Cuatro": 4, "Telecinco": 5,
    "laSexta": 6, "Canal 24h": 7, "Teledeporte": 8, "Boing": 9,
    "Clan TVE": 10, "Neox": 11, "Nova": 12, "Mega": 13, "Energy": 14,
    "Factoría de Ficción": 15, "Atreseries": 16, "Be Mad": 17, "Divinity": 18,
}

# El nombre del canal en directo coincide con el display-name de epg_texto._CHANNELS
# salvo este caso: "Factoría de Ficción" se publica como "FDF" en la EPG.
_EPG_ALIAS = {"Factoría de Ficción": "FDF"}


def _ch_li(ch, idx):
    logo = ch["logo"]
    li = xbmcgui.ListItem(label=ch["name"])
    li.setArt({"thumb": logo, "icon": logo, "poster": logo, "fanart": logo, "landscape": logo})
    li.setProperty("ad_title", ch["name"])
    li.setProperty("ad_image", logo)
    li.setProperty("ad_idx", str(idx))
    return li


def _epg_li(prog, is_now):
    hora = epg_texto._fmt_time(prog["start"])
    titulo = prog.get("title", "")
    if is_now:
        label = "[B][COLOR gold]{0}[/COLOR]  {1}  [COLOR gold]EN CURSO[/COLOR][/B]".format(hora, titulo)
    else:
        label = "[COLOR white]{0}[/COLOR]  {1}".format(hora, titulo)
    li = xbmcgui.ListItem(label=label)
    li.setProperty("ad_title", titulo)
    plot = "{0}  {1}".format(hora, titulo)
    if prog.get("desc"):
        plot += "\n{0}".format(prog["desc"])
    if prog.get("cat"):
        plot += "\n[{0}]".format(prog["cat"])
    li.setProperty("ad_plot", plot)
    return li


def _info_li(text):
    li = xbmcgui.ListItem(label=text)
    li.setProperty("ad_plot", "")
    return li


class ModoTV(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.play_action = None
        self.play_params = None
        self._channels = []
        self._epg = {}          # nombre canal -> lista de programas (orden por start)
        self._loaded = False
        self._closing = False
        self._populate_lock = threading.Lock()
        self._epg_shown_idx = None

    # --- Ciclo de vida ---

    def onInit(self):
        self.setProperty("epg_channel", "")
        self._set_focus_props("")
        threading.Thread(target=self._load_all, daemon=True).start()
        threading.Thread(target=self._focus_poll_loop, daemon=True).start()

    def _load_all(self):
        try:
            self._channels = self._build_channels()
            self._epg = self._build_epg()
            if self._closing:
                return
            self._populate_grid()
        except Exception as e:
            xbmc.log("{0} _load_all error: {1}".format(_LOG, e), xbmc.LOGERROR)
            self._set_loading("[COLOR red]Error al cargar. Pulsa Atras.[/COLOR]")

    def _build_channels(self):
        channels = []
        for c in connector._RTVE_LIVE_CHANNELS:
            channels.append({
                "name": c["name"], "logo": c["logo"], "source": "rtve",
                "play_action": "play_live_rtve", "play_params": {"video_id": c["video_id"]},
            })
        for c in connector._MEDIASET_LIVE_CHANNELS:
            logo = connector._MEDIASET_CH_LOGOS.get(c["id"], "DefaultAddonPVRClient.png")
            channels.append({
                "name": c["name"], "logo": logo, "source": "mediaset",
                "play_action": "play_live_mediaset", "play_params": {"url": c["url"]},
            })
        if self._atresdaily_installed():
            try:
                for c in connector.get_live_channels():
                    logo = connector._ATRES_CH_LOGOS.get(c["id"], "DefaultAddonPVRClient.png")
                    channels.append({
                        "name": c["name"], "logo": logo, "source": "atres",
                        "play_action": "play_live_atres", "play_params": {"ch_id": c["id"]},
                    })
            except Exception as e:
                xbmc.log("{0} canales Atres fallo: {1}".format(_LOG, e), xbmc.LOGWARNING)
        channels.sort(key=lambda x: _LCN.get(x["name"], 99))
        return channels

    @staticmethod
    def _atresdaily_installed():
        try:
            xbmcaddon.Addon("plugin.video.atresdaily")
            return True
        except Exception:
            return False

    def _build_epg(self):
        """nombre canal mostrado -> programas. Vacio si la EPG no se pudo cargar."""
        try:
            xml_channels, programmes = epg_texto._fetch_epg()
        except Exception as e:
            xbmc.log("{0} EPG fetch fallo: {1}".format(_LOG, e), xbmc.LOGWARNING)
            return {}
        if not xml_channels:
            return {}
        # _resolve_channels usa los display-name de epg_texto._CHANNELS ("FDF", etc.).
        by_epg_name = {dn: programmes.get(cid, []) for dn, cid, _info in epg_texto._resolve_channels(xml_channels)}
        out = {}
        for ch in self._channels:
            epg_name = _EPG_ALIAS.get(ch["name"], ch["name"])
            out[ch["name"]] = by_epg_name.get(epg_name, [])
        return out

    # --- Cuadricula de canales ---

    def _populate_grid(self):
        with self._populate_lock:
            if self._closing:
                return
            try:
                grid = self.getControl(_ID_GRID)
                grid.reset()
                grid.addItems([_ch_li(ch, i) for i, ch in enumerate(self._channels)])
            except Exception as e:
                xbmc.log("{0} grid: {1}".format(_LOG, e), xbmc.LOGWARNING)
            try:
                self.getControl(_ID_LOADING).setVisible(False)
            except Exception:
                pass
            if self._channels:
                try:
                    self.setFocusId(_ID_GRID)
                except Exception:
                    pass
            else:
                self._set_loading("[COLOR orange]No hay canales disponibles.[/COLOR]")
        self._loaded = True
        self._refresh_epg()

    # --- Panel EPG (izquierda) ---

    def _current_grid_index(self):
        try:
            grid = self.getControl(_ID_GRID)
            pos = grid.getSelectedPosition()
            if pos < 0:
                return None
            li = grid.getListItem(pos)
            return int(li.getProperty("ad_idx"))
        except Exception:
            return None

    def _refresh_epg(self):
        """Repuebla el panel EPG con la programacion del canal enfocado en el grid.
        Solo actua si el foco esta en el grid (si esta en el EPG, el usuario navega)."""
        try:
            if self.getFocusId() != _ID_GRID:
                return
        except Exception:
            return
        idx = self._current_grid_index()
        if idx is None or not (0 <= idx < len(self._channels)):
            return
        # El check-then-act sobre _epg_shown_idx va DENTRO del lock: el hilo de
        # carga y el de poll pueden llamar aqui a la vez con el mismo idx; sin esto
        # ambos repueblan el control 400 (reset+addItems doble -> parpadeo).
        with self._populate_lock:
            if self._closing or idx == self._epg_shown_idx:
                return
            ch = self._channels[idx]
            self._epg_shown_idx = idx
            self.setProperty("epg_channel", ch["name"])
            self._set_focus_props(ch["logo"])
            self._fill_epg_list(self._epg.get(ch["name"], []))

    def _fill_epg_list(self, progs):
        try:
            ctrl = self.getControl(_ID_EPG)
        except Exception:
            return
        ctrl.reset()
        items = self._epg_items(progs)
        if not items:
            items = [_info_li("Sin programación disponible")]
        ctrl.addItems(items)

    def _epg_items(self, progs):
        if not progs:
            return []
        now_utc = datetime.now(timezone.utc).replace(tzinfo=None)
        cur_pos = None
        for i, p in enumerate(progs):
            s = epg_texto._parse_epg_dt(p["start"])
            if s is None:
                continue
            e = epg_texto._parse_epg_dt(p["stop"]) if p.get("stop") else None
            if e is None:
                e = s + timedelta(hours=1)
            if s <= now_utc < e:
                cur_pos = i
                break
        if cur_pos is None:
            # Nada en curso: mostrar solo lo que aun no ha empezado. Si toda la
            # parrilla del canal ya paso, no mostramos nada (-> "Sin programacion").
            cur_pos = next((i for i, p in enumerate(progs)
                            if (epg_texto._parse_epg_dt(p["start"]) or now_utc) >= now_utc), None)
            if cur_pos is None:
                return []
            window = progs[cur_pos:cur_pos + _EPG_NEXT_COUNT + 1]
            return [_epg_li(p, False) for p in window]
        window = progs[cur_pos:cur_pos + _EPG_NEXT_COUNT + 1]
        return [_epg_li(p, i == 0) for i, p in enumerate(window)]

    # --- Reproduccion (delegada en play_live_* via PlayMedia) ---

    def _play(self, idx):
        if not (0 <= idx < len(self._channels)):
            return
        ch = self._channels[idx]
        self.play_action = ch["play_action"]
        self.play_params = ch["play_params"]
        self._closing = True
        self.close()

    # --- Eventos ---

    def onAction(self, action):
        if action.getId() in _CLOSE_ACTIONS:
            self._closing = True
            self.close()

    def onClick(self, controlId):
        if not self._loaded:
            return
        if controlId == _ID_CLOSE_BTN:
            self._closing = True
            self.close()
            return
        if controlId == _ID_GRID:
            idx = self._current_grid_index()
            if idx is not None:
                self._play(idx)
            return
        if controlId == _ID_EPG:
            try:
                li = self.getControl(_ID_EPG).getListItem(self.getControl(_ID_EPG).getSelectedPosition())
                plot = li.getProperty("ad_plot")
                if plot:
                    xbmcgui.Dialog().textviewer(self.getProperty("epg_channel"), plot)
            except Exception:
                pass

    # --- Fondo dinamico y poll de foco ---

    def _focus_poll_loop(self):
        monitor = xbmc.Monitor()
        last = None
        while not self._closing and not monitor.abortRequested():
            try:
                cur = self._focus_key()
                if cur != last:
                    if self._loaded:
                        self._refresh_epg()
                    last = cur
            except Exception:
                pass
            if monitor.waitForAbort(_FOCUS_POLL_MS / 1000.0):
                break

    def _focus_key(self):
        try:
            return (self.getFocusId(), self.getControl(_ID_GRID).getSelectedPosition())
        except Exception:
            return None

    def _set_focus_props(self, fanart):
        self.setProperty("focused_fanart", fanart)

    def _set_loading(self, msg):
        try:
            c = self.getControl(_ID_LOADING)
            c.setLabel(msg)
            c.setVisible(True)
        except Exception:
            pass


def show():
    addon_path = xbmcaddon.Addon().getAddonInfo("path")
    win = ModoTV("experimental_tv_espa.xml", addon_path, "Default", "1080i")
    try:
        win.doModal()
        action = win.play_action
        params = win.play_params
    finally:
        del win

    if action and params:
        qs = {"action": action}
        qs.update(params)
        url = sys.argv[0] + "?" + urllib.parse.urlencode(qs)
        xbmc.executebuiltin("PlayMedia({0})".format(url))
