# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
"""Escáner HTML de vídeos embebidos y enlaces P2P.

Descarga el HTML de una página y extrae URLs de vídeo usando patrones
comunes: etiquetas HTML5 ``<video>`` / ``<source>``, meta Open Graph,
iframes de plataformas conocidas (YouTube, Dailymotion, Vimeo, Twitch,
Rumble, Odysee, VK, OK.ru, Rutube), datos estructurados JSON-LD,
fuentes declaradas en JavaScript inline (JWPlayer, Flowplayer) y
atributos ``data-*`` de carga diferida.
También soporta canales de Telegram, magnets, torrents y enlaces AceStream.

Funciona sin dependencias externas (solo ``urllib`` y ``re`` de la
librería estándar), lo que permite ejecutarlo en cualquier plataforma,
incluido Android.
"""
import html as _html
import json
import re
from urllib.parse import urljoin, urlparse, unquote_plus
from urllib.request import urlopen, Request

try:
    import xbmc
    _log = lambda msg: xbmc.log(f"[EspaDaily/scanner] {msg}", xbmc.LOGDEBUG)
except ImportError:
    _log = lambda msg: None

_VIDEO_EXTENSIONS = frozenset((
    '.mp4', '.m3u8', '.webm', '.mkv', '.avi', '.mpd',
    '.ts', '.flv', '.mov', '.wmv', '.m3u',
))

_MAX_HTML_BYTES = 512 * 1024  # 512 KB: defensa contra páginas gigantes.
_MAX_RESULTS = 500  # límite alto: páginas con cientos de enlaces
_HEAD_TIMEOUT = 4
_DOWNLOAD_TIMEOUT = 10

from _user_agents import UA_DESKTOP as _UA

_TG_CHANNEL_RE = re.compile(
    r'^https?://t\.me/(?!s/)([a-zA-Z][a-zA-Z0-9_]{3,})/?$', re.I
)

_KNOWN_VIDEO_DOMAINS = frozenset((
    'youtube.com', 'youtu.be', 'twitch.tv', 'vimeo.com',
    'dailymotion.com', 'dai.ly', 'rumble.com', 'odysee.com',
    'soundcloud.com',
))

# API pública

def scan_page(url, timeout=None, html_content=None):
    """Analiza una URL o HTML en crudo y devuelve los vídeos detectados.

    Args:
        url:          Dirección base para resolver URLs relativas.
        timeout:      Segundos máximos para la descarga del HTML.
        html_content: Si se provee, no se descarga la URL y se usa este contenido.

    Returns:
        Lista de dicts con claves ``title``, ``url``, ``filesize`` y ``ext``.
    """
    if timeout is None:
        timeout = _DOWNLOAD_TIMEOUT

    url = _normalize_telegram_url(url)
    if html_content is None:
        html = _download_html(url, timeout)
    else:
        html = html_content
        
    if not html:
        return []

    seen = set()
    results = []

    extractors = (
        _extract_telegram_links,
        _extract_og_videos,
        _extract_html5_videos,
        _extract_jsonld_videos,
        _extract_iframes,
        _extract_js_sources,
        _extract_data_attrs,
        _extract_direct_urls,
        _extract_magnets_torrents,
    )

    for extract in extractors:
        for entry in extract(html, url):
            video_url = entry.get('url', '')
            if not video_url or video_url in seen:
                continue
            seen.add(video_url)
            results.append(entry)
            if len(results) >= _MAX_RESULTS:
                return results

    # Tamaño on-demand
    for entry in results:
        if entry.get('filesize') is None and _has_video_extension(entry['url']):
            entry['filesize'] = _get_filesize(entry['url'])

    return results

def format_size(byte_count):
    if byte_count is None or byte_count < 0:
        return ''
    if byte_count == 0:
        return '0 B'

    units = ('B', 'KB', 'MB', 'GB', 'TB')
    size = float(byte_count)
    for unit in units:
        if size < 1024.0:
            if unit == 'B':
                return f'{size:.0f} {unit}'
            return f'{size:.1f} {unit}'
        size /= 1024.0
    return f'{size:.1f} PB'

def format_duration(seconds):
    if seconds is None or seconds < 0:
        return ''
    seconds = int(seconds)
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h > 0:
        return f'{h:02d}:{m:02d}:{s:02d}'
    return f'{m:02d}:{s:02d}'

# Descarga

_ACCEPTED_TYPES = ('text/html', 'text/xml', 'application/xhtml+xml',
                   'application/xml')

def _normalize_telegram_url(url):
    if not isinstance(url, str):
        return url
    m = _TG_CHANNEL_RE.match(url)
    if m:
        return f'https://t.me/s/{m.group(1)}'
    return url

def _download_html(url, timeout):
    try:
        req = Request(url, headers={'User-Agent': _UA})
        with urlopen(req, timeout=timeout) as resp:
            content_type = resp.headers.get('Content-Type', '')
            if not any(ct in content_type for ct in _ACCEPTED_TYPES):
                _log(f'Content-Type no soportado: {content_type}')
                return ''
            raw = resp.read(_MAX_HTML_BYTES)
        return raw.decode('utf-8', errors='replace')
    except Exception as exc:
        _log(f'Error descargando {url}: {exc!r}')
        return ''

# Extractores

def _extract_og_videos(html, base_url):
    results = []
    pattern = re.compile(
        r'<meta\s+[^>]*?(?:property|name)=["\']og:video(?::url)?["\']'
        r'[^>]*?content=["\']([^"\']+)',
        re.I,
    )
    pattern_rev = re.compile(
        r'<meta\s+[^>]*?content=["\']([^"\']+)["\']'
        r'[^>]*?(?:property|name)=["\']og:video(?::url)?["\']',
        re.I,
    )
    og_title = _extract_meta_content(html, 'og:title') or ''

    urls_found = set()
    for m in pattern.finditer(html):
        urls_found.add(m.group(1).strip())
    for m in pattern_rev.finditer(html):
        urls_found.add(m.group(1).strip())

    for video_url in urls_found:
        video_url = urljoin(base_url, video_url)
        results.append({
            'title': og_title or _title_from_url(video_url),
            'url': video_url,
            'filesize': None,
            'ext': _get_extension(video_url),
        })
    return results

def _extract_html5_videos(html, base_url):
    results = []
    video_src_re = re.compile(
        r'<video\s[^>]*?(?:data-src|src)=["\']([^"\']+)', re.I,
    )
    for m in video_src_re.finditer(html):
        src = urljoin(base_url, m.group(1).strip())
        results.append({
            'title': _title_from_url(src),
            'url': src,
            'filesize': None,
            'ext': _get_extension(src),
        })

    source_re = re.compile(r'<source\s([^>]+)', re.I)
    for m in source_re.finditer(html):
        attrs = m.group(1)
        src_m = re.search(r'(?:data-src|src)=["\']([^"\']+)', attrs)
        if not src_m:
            continue
        src = urljoin(base_url, src_m.group(1).strip())
        has_video_type = bool(re.search(r'type=["\']video/', attrs, re.I))
        if not _has_video_extension(src) and not has_video_type:
            continue
        results.append({
            'title': _title_from_url(src),
            'url': src,
            'filesize': None,
            'ext': _get_extension(src),
        })
    return results

def _extract_iframes(html, base_url):
    results = []
    iframe_re = re.compile(r'<iframe\s[^>]*?src=["\']([^"\']+)', re.I)

    for m in iframe_re.finditer(html):
        src = m.group(1).strip()
        
        yt = re.search(r'youtube(?:-nocookie)?\.com/embed/([a-zA-Z0-9_-]+)', src)
        if yt:
            results.append({'title': f'YouTube: {yt.group(1)}', 'url': f'https://www.youtube.com/watch?v={yt.group(1)}', 'filesize': None, 'ext': ''})
            continue

        dm = re.search(r'dailymotion\.com/embed/video/([a-zA-Z0-9]+)', src)
        if dm:
            results.append({'title': f'Dailymotion: {dm.group(1)}', 'url': f'https://www.dailymotion.com/video/{dm.group(1)}', 'filesize': None, 'ext': ''})
            continue

        vm = re.search(r'player\.vimeo\.com/video/(\d+)', src)
        if vm:
            results.append({'title': f'Vimeo: {vm.group(1)}', 'url': f'https://vimeo.com/{vm.group(1)}', 'filesize': None, 'ext': ''})
            continue

        tw = re.search(r'player\.twitch\.tv/\?[^"\']*?channel=([a-zA-Z0-9_]+)', src)
        if tw:
            results.append({'title': f'Twitch: {tw.group(1)}', 'url': f'https://www.twitch.tv/{tw.group(1)}', 'filesize': None, 'ext': ''})
            continue

        tc = re.search(r'clips\.twitch\.tv/embed\?[^"\']*?clip=([a-zA-Z0-9_-]+)', src)
        if tc:
            results.append({'title': f'Twitch Clip: {tc.group(1)}', 'url': f'https://clips.twitch.tv/{tc.group(1)}', 'filesize': None, 'ext': ''})
            continue

        rb = re.search(r'rumble\.com/embed/([a-zA-Z0-9]+)', src)
        if rb:
            results.append({'title': f'Rumble: {rb.group(1)}', 'url': f'https://rumble.com/embed/{rb.group(1)}', 'filesize': None, 'ext': ''})
            continue

        od = re.search(r'odysee\.com/\$/embed/([^"\'?#]+)', src)
        if od:
            results.append({'title': f'Odysee: {od.group(1)}', 'url': f'https://odysee.com/{od.group(1).rstrip("/")}', 'filesize': None, 'ext': ''})
            continue

        vk = re.search(r'vk\.com/video_ext\.php\?[^"\']*?oid=(-?\d+)[^"\']*?id=(\d+)', src)
        if vk:
            results.append({'title': f'VK: {vk.group(1)}_{vk.group(2)}', 'url': f'https://vk.com/video{vk.group(1)}_{vk.group(2)}', 'filesize': None, 'ext': ''})
            continue

        ok = re.search(r'ok\.ru/videoembed/(\d+)', src)
        if ok:
            results.append({'title': f'OK.ru: {ok.group(1)}', 'url': f'https://ok.ru/video/{ok.group(1)}', 'filesize': None, 'ext': ''})
            continue

        rt = re.search(r'rutube\.ru/(?:play/embed|embed)/([a-f0-9]+)', src, re.I)
        if rt:
            results.append({'title': f'Rutube: {rt.group(1)}', 'url': f'https://rutube.ru/video/{rt.group(1)}', 'filesize': None, 'ext': ''})
            continue

        if _has_video_extension(src):
            abs_src = urljoin(base_url, src)
            results.append({'title': _title_from_url(abs_src), 'url': abs_src, 'ext': _get_extension(abs_src)})
            
    return results

def _extract_direct_urls(html, base_url):
    results = []
    anchor_map = _build_anchor_map(html, predicate=lambda h: h.lower().startswith(('http://', 'https://')))
    url_re = re.compile(
        r'(https?://[^\s"\'<>]+\.(?:mp4|m3u8|webm|mkv|avi|mpd|ts|flv|mov|wmv))'
        r'(?:[?#][^\s"\'<>]*)?', re.I
    )
    for m in url_re.finditer(html):
        raw = m.group(0).strip().rstrip(')')
        results.append({
            'title': anchor_map.get(raw) or _title_from_url(raw),
            'url': raw,
            'filesize': None,
            'ext': _get_extension(raw),
        })
    return results

_MAGNET_RE = re.compile(r'(?:href|data-magnet|data-url)\s*=\s*["\'](magnet:\?[^"\']+)["\']', re.I)
_TORRENT_RE = re.compile(r'(?:href|src|data-url)\s*=\s*["\']((?:https?:)?(?://|/)?[^"\'\s<>]+\.torrent(?:[?#][^"\'\s<>]*)?)["\']', re.I)
_ACESTREAM_RE = re.compile(r'acestream://([a-fA-F0-9]{40})(?![a-fA-F0-9])', re.I)

def _magnet_display_name(magnet):
    m = re.search(r'[?&]dn=([^&]+)', magnet)
    if not m: return ''
    try:
        return unquote_plus(m.group(1))[:120]
    except ValueError:
        return ''

def _torrent_display_name(torrent_url):
    try:
        path = urlparse(torrent_url).path
        name = path.rsplit('/', 1)[-1]
        if name.lower().endswith('.torrent'): name = name[:-8]
        return name[:120]
    except ValueError:
        return ''

def _extract_magnets_torrents(html, base_url):
    results = []
    magnet_anchor_map = _build_anchor_map(html, predicate=lambda h: h.lower().startswith('magnet:?'))
    torrent_anchor_map = _build_anchor_map(html, predicate=lambda h: '.torrent' in h.lower())

    for m in _MAGNET_RE.finditer(html):
        magnet = m.group(1)
        if 'xt=' not in magnet: continue
        title = _magnet_display_name(magnet) or magnet_anchor_map.get(magnet, '') or 'Magnet'
        results.append({'url': magnet, 'title': title, 'filesize': None, 'ext': '', 'kind': 'magnet'})

    for m in _TORRENT_RE.finditer(html):
        raw = m.group(1)
        resolved = urljoin(base_url, raw)
        if not resolved.lower().startswith(('http://', 'https://')): continue
        title = _torrent_display_name(resolved) or torrent_anchor_map.get(raw, '') or '.torrent'
        results.append({'url': resolved, 'title': title, 'filesize': None, 'ext': 'torrent', 'kind': 'torrent'})

    seen_ace = set()
    for m in _ACESTREAM_RE.finditer(html):
        hash_id = m.group(1).lower()
        if hash_id in seen_ace: continue
        seen_ace.add(hash_id)
        # Extraer nombre del contexto anterior
        name = _extract_name_from_context(html, m.start())
        if not name or name.lower().startswith(('http', 'acestream')):
            name = f'Acestream {hash_id[:8]}'
        results.append({'url': f'acestream://{hash_id}', 'title': name, 'filesize': None, 'ext': '', 'kind': 'acestream'})

    return results

def _extract_name_from_context(html_ctx, match_start):
    start_pos = max(0, match_start - 250)
    context = html_ctx[start_pos:match_start]
    context = re.sub(r'<[^>]+>', ' ', context)
    context = context.replace('&nbsp;', ' ')
    lines = [line.strip() for line in context.split('\n') if line.strip()]
    if lines:
        clean_name = re.sub(r'[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑ\s\-_:.]', ' ', lines[-1]).strip()
        clean_name = re.sub(r'\s+', ' ', clean_name)
        if len(clean_name) > 2:
            return clean_name[-60:].strip()
    return ""

def _extract_telegram_links(html, base_url):
    if 'tgme_widget_message' not in html:
        return []

    results = []
    msg_re = re.compile(
        r'class=["\'][^"\']*tgme_widget_message_text[^"\']*["\'][^>]*>(.*?)</div>',
        re.I | re.S,
    )
    anchor_re = re.compile(
        r'<a\b[^>]*?href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
        re.I | re.S,
    )
    plain_url_re = re.compile(r'(?:https?://|magnet:\?|acestream://)[^\s<>"\']+', re.I)

    seen = set()
    for msg_m in msg_re.finditer(html):
        block = msg_m.group(1)
        for m in anchor_re.finditer(block):
            u = m.group(1).strip()
            if u and u not in seen and _is_playable_url(u):
                seen.add(u)
                text = _clean_anchor_text(m.group(2))
                results.append({'title': text or _title_from_url(u), 'url': u, 'filesize': None, 'ext': _get_extension(u)})
        for m in plain_url_re.finditer(re.sub(r'<[^>]+>', ' ', block)):
            u = m.group(0).strip().rstrip('.,;)')
            if u and u not in seen and _is_playable_url(u):
                seen.add(u)
                results.append({'title': _title_from_url(u), 'url': u, 'filesize': None, 'ext': _get_extension(u)})
    return results

def _extract_jsonld_videos(html, base_url):
    results = []
    for m in re.finditer(r'<script\s+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>', html, re.I | re.S):
        try:
            data = json.loads(m.group(1))
        except (json.JSONDecodeError, ValueError):
            continue

        videos = data if isinstance(data, list) else [data] if isinstance(data, dict) else []
        for item in videos:
            if not isinstance(item, dict): continue
            vtype = item.get('@type', '')
            if vtype not in ('VideoObject', 'Video'): continue
            content_url = item.get('contentUrl') or item.get('embedUrl') or ''
            if not content_url: continue
            content_url = urljoin(base_url, content_url)
            title = item.get('name') or _title_from_url(content_url)
            seconds = _parse_iso_duration(item.get('duration') or '')
            results.append({'title': title, 'url': content_url, 'filesize': None, 'ext': _get_extension(content_url), 'duration': seconds})
    return results

def _extract_js_sources(html, base_url):
    results = []
    js_keys = r'file|src|source|url|video_url|mp4_url|hls'
    js_exts = r'mp4|m3u8|webm|mkv|avi|mpd|ts|flv|mov|wmv'
    js_re = re.compile(
        r'["\'](?:' + js_keys + r')["\']\s*:\s*'
        r'["\'](https?://[^"\']+\.(?:' + js_exts + r')(?:[?#][^"\']*)?)\s*["\']', re.I
    )
    for m in js_re.finditer(html):
        video_url = m.group(1).strip()
        results.append({'title': _title_from_url(video_url), 'url': video_url, 'filesize': None, 'ext': _get_extension(video_url)})
    return results

def _extract_data_attrs(html, base_url):
    results = []
    data_re = re.compile(r'data-(?:src|video-url|video|file|stream|hls)\s*=\s*["\']([^"\']+)', re.I)
    for m in data_re.finditer(html):
        url = m.group(1).strip()
        if not _has_video_extension(url): continue
        abs_url = urljoin(base_url, url)
        results.append({'title': _title_from_url(abs_url), 'url': abs_url, 'filesize': None, 'ext': _get_extension(abs_url)})
    return results

# Utilidades internas

def _extract_meta_content(html, prop):
    m = re.search(r'<meta\s+[^>]*?(?:property|name)=["\']' + re.escape(prop) + r'["\'][^>]*?content=["\']([^"\']+)', html, re.I)
    if not m:
        m = re.search(r'<meta\s+[^>]*?content=["\']([^"\']+)["\'][^>]*?(?:property|name)=["\']' + re.escape(prop) + r'["\']', html, re.I)
    return m.group(1).strip() if m else None

def _has_video_extension(url):
    try: path = urlparse(url).path.lower()
    except (ValueError, AttributeError): return False
    return any(path.endswith(ext) for ext in _VIDEO_EXTENSIONS)

def _is_playable_url(url):
    if url.startswith(('magnet:', 'acestream://')): return True
    if _has_video_extension(url): return True
    try:
        host = urlparse(url).netloc.lower()
        if host.startswith('www.'): host = host[4:]
        return any(host == d or host.endswith('.' + d) for d in _KNOWN_VIDEO_DOMAINS)
    except (ValueError, AttributeError):
        return False

def _get_extension(url):
    try: path = urlparse(url).path.lower()
    except (ValueError, AttributeError): return ''
    for ext in _VIDEO_EXTENSIONS:
        if path.endswith(ext): return ext.lstrip('.')
    return ''

def _title_from_url(url):
    try: path = urlparse(url).path
    except (ValueError, AttributeError): return url[:80]
    name = path.rstrip('/').rsplit('/', 1)[-1]
    if '.' in name: name = name.rsplit('.', 1)[0]
    return name.replace('-', ' ').replace('_', ' ')[:80] if name else url[:80]

def _clean_anchor_text(raw):
    text = re.sub(r'<[^>]+>', ' ', raw)
    text = _html.unescape(text)
    text = ' '.join(text.split())
    if not text or text.lower().startswith(('http://', 'https://', 'magnet:', 'acestream://')):
        return ''
    return text[:80]

_ANCHOR_HREF_RE = re.compile(r'href\s*=\s*["\']([^"\']+)["\']', re.I)

def _build_anchor_map(html, predicate=None):
    out = {}
    n = len(html)
    if n == 0: return out
    hl = html.lower()
    i = 0
    while i < n:
        open_pos = hl.find('<a', i)
        if open_pos < 0: break
        if open_pos + 2 < n and not hl[open_pos + 2].isspace():
            i = open_pos + 2
            continue
        gt = hl.find('>', open_pos)
        if gt < 0: break
        close = hl.find('</a>', gt + 1)
        if close < 0:
            i = gt + 1
            continue
        href_m = _ANCHOR_HREF_RE.search(html, open_pos, gt)
        if href_m:
            href = href_m.group(1).strip()
            if not predicate or predicate(href):
                if href not in out:
                    text = _clean_anchor_text(html[gt + 1:close])
                    if text: out[href] = text
        i = close + 4
    return out

def _get_filesize(url):
    try:
        req = Request(url, method='HEAD', headers={'User-Agent': _UA})
        with urlopen(req, timeout=_HEAD_TIMEOUT) as resp:
            cl = resp.headers.get('Content-Length')
            if cl and cl.isdigit(): return int(cl)
    except Exception: return None
    return None

def _parse_iso_duration(iso):
    if not iso: return None
    m = re.match(r'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$', iso, re.I)
    if not m: return None
    hours = int(m.group(1) or 0)
    mins = int(m.group(2) or 0)
    secs = int(m.group(3) or 0)
    total = hours * 3600 + mins * 60 + secs
    return total if total > 0 else None
