import { API } from '../api.js';
import { Icons } from '../icons.js';
import { makeSkeleton } from './grid.js';
import { toast } from './toast.js';

export async function renderLive(container, { onPlay }) {
  const wrap = document.createElement('div');
  wrap.className = 'live-view page-enter';
  wrap.innerHTML = `
    <div class="grid-header" style="padding:24px 4% 12px">
      <button class="grid-back" title="Volver">${Icons.arrowLeft}</button>
      <h2 class="grid-title">Directos</h2>
    </div>
    <div class="live-grid" id="live-grid"></div>
  `;
  wrap.querySelector('.grid-back').addEventListener('click', () => {
    if (history.length > 1) history.back();
    else location.href = '/';
  });
  container.appendChild(wrap);

  const grid = wrap.querySelector('#live-grid');
  makeSkeleton(8).forEach(c => {
    c.className = 'card live-card card-skeleton';
    grid.appendChild(c);
  });

  let data;
  try {
    data = await API.liveChannels();
  } catch (e) {
    grid.innerHTML = `<div class="empty-state">Error: ${e.message}</div>`;
    toast(`Error canales: ${e.message}`, 'error');
    return;
  }

  grid.innerHTML = '';
  if (!data.items?.length) {
    grid.innerHTML = `<div class="empty-state">No hay canales disponibles</div>`;
    return;
  }

  for (const item of data.items) {
    grid.appendChild(makeLiveCard(item, onPlay));
  }
}

function makeLiveCard(item, onPlay) {
  const card = document.createElement('div');
  card.className = 'card live-card';

  const imgWrap = document.createElement('div');
  imgWrap.className = 'card-img';

  if (item.thumb) {
    const logoWrap = document.createElement('div');
    logoWrap.className = 'live-card-logo';
    const img = document.createElement('img');
    img.alt = item.title;
    img.loading = 'eager';
    img.onerror = function () {
      if (!this._retried) {
        this._retried = true;
        const orig = this.src;
        this.src = '';
        setTimeout(() => { this.src = orig; }, 1500);
      }
    };
    img.src = item.thumb;
    logoWrap.appendChild(img);
    imgWrap.appendChild(logoWrap);
  } else {
    const ph = document.createElement('div');
    ph.className = 'card-img-placeholder';
    ph.innerHTML = Icons.live;
    imgWrap.appendChild(ph);
  }

  imgWrap.insertAdjacentHTML('beforeend', `
    <div class="card-live-badge"><span class="card-live-dot"></span>EN DIRECTO</div>
  `);

  const overlay = document.createElement('div');
  overlay.className = 'card-overlay';
  overlay.innerHTML = `
    <div class="card-overlay-title">${escHtml(item.title)}</div>
    <div class="card-overlay-actions">
      <button class="card-action-btn play-btn" title="Reproducir">${Icons.play}</button>
    </div>
  `;
  imgWrap.appendChild(overlay);
  card.appendChild(imgWrap);

  const info = document.createElement('div');
  info.className = 'card-info';
  info.innerHTML = `
    <div class="card-info-title">${escHtml(item.title)}</div>
    <div class="card-info-sub" style="color:#cc0000">● En directo</div>
  `;
  card.appendChild(info);

  card.addEventListener('click', () => onPlay(item));
  overlay.querySelector('.play-btn').addEventListener('click', (e) => {
    e.stopPropagation();
    onPlay(item);
  });

  return card;
}

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
