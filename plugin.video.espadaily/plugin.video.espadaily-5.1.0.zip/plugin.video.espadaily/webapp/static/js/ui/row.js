import { Icons } from '../icons.js';
import { makeCard } from './grid.js';

export function makeRow(row, onPlay, onNavigate, favSet) {
  const sec = document.createElement('div');
  sec.className = 'row-section page-enter';

  const header = document.createElement('div');
  header.className = 'row-header';
  header.innerHTML = `<span class="row-title">${escHtml(row.title)}</span>`;
  sec.appendChild(header);

  const wrap = document.createElement('div');
  wrap.className = 'row-scroll-wrap';

  const scroll = document.createElement('div');
  scroll.className = 'row-scroll';

  const btnL = document.createElement('button');
  btnL.className = 'row-arrow left';
  btnL.innerHTML = Icons.arrowLeft;
  btnL.setAttribute('aria-label', 'Anterior');

  const btnR = document.createElement('button');
  btnR.className = 'row-arrow right';
  btnR.innerHTML = Icons.arrowRight;
  btnR.setAttribute('aria-label', 'Siguiente');

  btnL.addEventListener('click', () => scroll.scrollBy({ left: -scroll.clientWidth * 0.8, behavior: 'smooth' }));
  btnR.addEventListener('click', () => scroll.scrollBy({ left: scroll.clientWidth * 0.8, behavior: 'smooth' }));

  for (const item of row.items) {
    scroll.appendChild(makeCard(item, onPlay, onNavigate, favSet, 'landscape'));
  }

  wrap.appendChild(btnL);
  wrap.appendChild(scroll);
  wrap.appendChild(btnR);
  sec.appendChild(wrap);

  // Mostrar flechas solo si hay overflow
  requestAnimationFrame(() => {
    const hasOverflow = scroll.scrollWidth > scroll.clientWidth;
    if (!hasOverflow) {
      btnL.style.display = 'none';
      btnR.style.display = 'none';
    } else {
      const updateArrows = () => {
        const atStart = scroll.scrollLeft <= 10;
        const atEnd = (scroll.scrollLeft + scroll.clientWidth) >= scroll.scrollWidth - 10;
        btnL.style.opacity = atStart ? '0' : '';
        btnL.style.pointerEvents = atStart ? 'none' : '';
        btnR.style.opacity = atEnd ? '0' : '';
        btnR.style.pointerEvents = atEnd ? 'none' : '';
      };
      scroll.addEventListener('scroll', updateArrows, { passive: true });
      updateArrows();
    }
  });

  return sec;
}

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
