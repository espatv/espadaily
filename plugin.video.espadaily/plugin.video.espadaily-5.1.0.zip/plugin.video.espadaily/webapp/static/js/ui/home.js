import { Icons } from '../icons.js';
import { makeRow } from './row.js';
import { makeSkeleton } from './grid.js';
import { toast } from './toast.js';

let _heroItems = [];
let _heroIdx = 0;
let _heroTimer = null;
let _curSource = 'all';
// Token de render: si llega un _load nuevo (p.ej. al cambiar de pestaña de fuente)
// mientras otro sigue en su await, el viejo se descarta y no pisa el DOM del nuevo.
let _renderToken = 0;

const _SRC_LABEL = { rtve: 'RTVE', mediaset: 'MEDIASET', atres: 'ATRESPLAYER' };

export async function renderHome(container, cbs) {
  _curSource = 'all';
  await _load(container, cbs);
}

async function _load(container, { onPlay, onNavigate, favSet }) {
  const token = ++_renderToken;
  if (_heroTimer) { clearInterval(_heroTimer); _heroTimer = null; }
  container.innerHTML = '';

  // Hero skeleton
  const heroEl = document.createElement('section');
  heroEl.className = 'hero';
  heroEl.innerHTML = `<div class="hero-bg skeleton-box" style="position:absolute;inset:0"></div>`;
  container.appendChild(heroEl);

  // Pestañas de filtro por fuente
  const tabs = document.createElement('div');
  tabs.className = 'source-tabs';
  for (const [val, lbl] of [['all', 'Todo'], ['rtve', 'RTVE'], ['mediaset', 'Mediaset']]) {
    const b = document.createElement('button');
    b.className = 'source-tab' + (val === _curSource ? ' active' : '');
    b.textContent = lbl;
    b.addEventListener('click', () => {
      if (_curSource !== val) { _curSource = val; _load(container, { onPlay, onNavigate, favSet }); }
    });
    tabs.appendChild(b);
  }
  container.appendChild(tabs);

  // Filas skeleton
  const rowsEl = document.createElement('section');
  rowsEl.className = 'rows-container';
  for (let i = 0; i < 3; i++) {
    const sec = document.createElement('div');
    sec.className = 'row-section';
    sec.innerHTML = `
      <div class="row-header">
        <span class="skeleton-box" style="height:16px;width:180px;border-radius:4px;display:inline-block"></span>
      </div>
      <div class="row-scroll" style="overflow:hidden"></div>`;
    const scroll = sec.querySelector('.row-scroll');
    makeSkeleton(6).forEach(c => scroll.appendChild(c));
    rowsEl.appendChild(sec);
  }
  container.appendChild(rowsEl);

  let data;
  try {
    // no-store: la home (destacados + directos + catalogo) se pide siempre fresca,
    // sin servirse de la cache HTTP del navegador.
    const r = await fetch('/api/home?source=' + encodeURIComponent(_curSource), { cache: 'no-store' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    data = await r.json();
  } catch (e) {
    if (token !== _renderToken) return;  // render obsoleto: otro _load tomó el relevo
    const isNet = /failed to fetch|networkerror|load failed|http 5/i.test(e.message || '');
    heroEl.remove();
    if (isNet) {
      rowsEl.innerHTML = `
        <div class="empty-state" style="padding:80px 20px;line-height:1.7">
          <div style="font-size:1.3rem;color:var(--text);margin-bottom:12px;font-weight:600">
            El servidor de EspaDaily no está disponible
          </div>
          <div>Vuelve a Kodi y abre <b>EspaDaily WebApp</b> en el apartado Experimental.<br>
          Después recarga esta página.</div>
          <button class="btn btn-primary" style="margin-top:24px" onclick="location.reload()">Reintentar</button>
        </div>`;
    } else {
      toast(`Error cargando inicio: ${e.message}`, 'error');
      rowsEl.innerHTML = `<div class="empty-state">No se pudo cargar el contenido.</div>`;
    }
    return;
  }

  if (token !== _renderToken) return;  // render obsoleto: otro _load tomó el relevo

  // Hero: destacados del catálogo (rota cada 9s)
  _heroItems = (data.featured || []).filter(it => it.thumb).slice(0, 5);
  if (!_heroItems.length) {
    for (const row of (data.rows || [])) {
      for (const it of (row.items || [])) {
        if (it.thumb && it.type === 'video') { _heroItems.push(it); break; }
      }
      if (_heroItems.length >= 5) break;
    }
    _heroItems = _heroItems.slice(0, 5);
  }
  if (_heroItems.length) buildHero(heroEl, onPlay);
  else heroEl.remove();

  // Filas
  rowsEl.innerHTML = '';
  if (!data.rows?.length) {
    rowsEl.innerHTML = `<div class="empty-state">No hay contenido para mostrar.</div>`;
    return;
  }
  for (const row of data.rows) {
    if (!row.items?.length) continue;
    rowsEl.appendChild(makeRow(row, onPlay, onNavigate, favSet));
  }
}

function buildHero(heroEl, onPlay) {
  heroEl.innerHTML = `
    <div class="hero-bg" id="hero-bg"></div>
    <div class="hero-gradient"></div>
    <div class="hero-content" id="hero-content"></div>
    <div class="hero-dots" id="hero-dots"></div>`;

  const bg = heroEl.querySelector('#hero-bg');
  const content = heroEl.querySelector('#hero-content');
  const dotsEl = heroEl.querySelector('#hero-dots');

  const dots = _heroItems.map((_, i) => {
    const d = document.createElement('button');
    d.className = `hero-dot${i === 0 ? ' active' : ''}`;
    d.setAttribute('aria-label', `Destacado ${i + 1}`);
    d.addEventListener('click', () => { showHero(i); resetTimer(); });
    dotsEl.appendChild(d);
    return d;
  });

  function showHero(idx) {
    _heroIdx = idx;
    dots.forEach((d, i) => d.classList.toggle('active', i === idx));
    const item = _heroItems[idx];

    bg.style.opacity = '0';
    setTimeout(() => {
      bg.style.backgroundImage = `url('${item.thumb}')`;
      bg.style.opacity = '1';
    }, 200);

    const label = item.is_live ? 'EN DIRECTO' : (_SRC_LABEL[item.source] || 'DESTACADO');
    content.innerHTML = `
      <div class="hero-label">${label}</div>
      <h2 class="hero-title">${escHtml(item.title)}</h2>
      ${item.plot ? `<p class="hero-plot">${escHtml(item.plot)}</p>` : ''}
      <div class="hero-actions">
        <button class="btn btn-primary hero-play">${Icons.play} Reproducir</button>
      </div>`;
    content.querySelector('.hero-play').addEventListener('click', () => onPlay(item));
  }

  showHero(0);

  function resetTimer() {
    if (_heroTimer) clearInterval(_heroTimer);
    if (_heroItems.length > 1) {
      _heroTimer = setInterval(() => showHero((_heroIdx + 1) % _heroItems.length), 9000);
    }
  }
  resetTimer();
}

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
