# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
import socket
import threading
import xbmc

_server = None
_port = None
_bind_mode = None  # 'local' | 'lan'
_lock = threading.Lock()

_DEFAULT_PORT = 8089


def get_lan_ip():
    """Obtiene la dirección IP LAN de la interfaz activa del dispositivo."""
    try:
        kodi_ip = xbmc.getIPAddress()
        if kodi_ip and kodi_ip not in ('', '127.0.0.1', '0.0.0.0'):
            return kodi_ip
    except Exception:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return '127.0.0.1'


def _read_config():
    """Recupera la configuración de red persistente."""
    try:
        import ui_utils
        cfg = ui_utils.load_json('settings.json')
        lan = bool(cfg.get('webapp_lan_mode', False))
        port = int(cfg.get('webapp_port', _DEFAULT_PORT))
        if port < 1024 or port > 65535:
            port = _DEFAULT_PORT
        return lan, port
    except Exception:
        return False, _DEFAULT_PORT


def _build_url(port, lan_mode):
    is_android = xbmc.getCondVisibility("System.Platform.Android")
    ip = get_lan_ip() if (lan_mode or is_android) else '127.0.0.1'
    return f'http://{ip}:{port}/'


def ensure_running():
    """Inicia o actualiza la instancia del servidor HTTP basándose en la configuración activa."""
    global _server, _port, _bind_mode
    lan_mode, cfg_port = _read_config()
    
    is_android = xbmc.getCondVisibility("System.Platform.Android")
    if is_android:
        lan_mode = True
        
    desired_mode = 'lan' if lan_mode else 'local'

    with _lock:
        # Detener la instancia existente si cambiaron los parámetros de binding o puerto
        if _server is not None and (_bind_mode != desired_mode or _port != cfg_port):
            try:
                _server.server_close()
                threading.Thread(target=_server.shutdown, daemon=True).start()
                xbmc.log(f'[EspaWebApp] Reiniciando (modo {_bind_mode}→{desired_mode}, puerto {_port}→{cfg_port})', xbmc.LOGINFO)
            except Exception:
                pass
            _server = None
            _port = None
            _bind_mode = None

        if _server is not None:
            return _build_url(_port, lan_mode)

        host = '0.0.0.0' if lan_mode else '127.0.0.1'
        try:
            from .server import make_server
            srv, port = make_server(host=host, port=cfg_port)
            _server = srv
            _port = port
            _bind_mode = desired_mode
            t = threading.Thread(target=srv.serve_forever, daemon=True, name='EspaWebApp')
            t.start()
            url = _build_url(port, lan_mode)
            xbmc.log(f'[EspaWebApp] Servidor iniciado en {url}', xbmc.LOGINFO)

            # Si el puerto solicitado está en uso, se persiste el puerto real asignado dinámicamente.
            if port != cfg_port:
                _persist_port(port)
        except Exception as e:
            xbmc.log(f'[EspaWebApp] Error al arrancar servidor: {e}', xbmc.LOGERROR)
            return 'about:blank'

    return _build_url(_port, lan_mode)


def _persist_port(port):
    try:
        import ui_utils
        cfg = ui_utils.load_json('settings.json')
        cfg['webapp_port'] = int(port)
        ui_utils.save_json('settings.json', cfg)
        xbmc.log(f'[EspaWebApp] webapp_port actualizado a {port} en settings.json', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'[EspaWebApp] No se pudo persistir el puerto: {e}', xbmc.LOGWARNING)


def stop():
    global _server, _port, _bind_mode
    with _lock:
        if _server is not None:
            try:
                _server.server_close()
                threading.Thread(target=_server.shutdown, daemon=True).start()
                xbmc.log('[EspaWebApp] Servidor detenido.', xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f'[EspaWebApp] Error al detener: {e}', xbmc.LOGWARNING)
            _server = None
            _port = None
            _bind_mode = None


def get_url():
    if _server and _port:
        return _build_url(_port, _bind_mode == 'lan')
    return None
