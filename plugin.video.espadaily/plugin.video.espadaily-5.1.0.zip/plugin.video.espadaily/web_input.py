# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
"""Servidor HTTP efímero para escribir texto desde el móvil/PC.

Levanta un mini-servidor en la red local bajo demanda, muestra la dirección en un
diálogo de Kodi y espera a que el usuario envíe texto desde el navegador. Se cierra
al recibir el texto, al cancelar o tras el timeout. Inspirado en EspaTV (url_remote.py).
"""
import html
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import xbmc
import xbmcgui

_PORT_START = 8080
_PORT_COUNT = 9          # 8080-8088 (la WebApp persistente usa 8092+)
_TIMEOUT_S = 300
_POLL_S = 0.5
_MAX_BODY = 16 * 1024


def _get_lan_ip():
    try:
        from webapp.bootstrap import get_lan_ip
        return get_lan_ip()
    except Exception:
        try:
            return xbmc.getIPAddress() or '127.0.0.1'
        except (AttributeError, RuntimeError):
            return '127.0.0.1'


class _Server(ThreadingHTTPServer):
    def __init__(self, addr, handler, title, default):
        super().__init__(addr, handler)
        self.title = title
        self.default = default
        self.received = None
        self.event = threading.Event()


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass  # no ensuciar el log de Kodi con las peticiones HTTP

    def do_GET(self):
        if self.path == '/' or self.path.startswith('/?'):
            page = (_PAGE
                    .replace('__VALUE__', html.escape(self.server.default, quote=True))
                    .replace('__TITLE__', html.escape(self.server.title)))
            body = page.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_error(404)

    def do_POST(self):
        if self.path != '/send':
            self.send_error(404)
            return
        try:
            length = int(self.headers.get('Content-Length', 0))
        except ValueError:
            length = 0
        if length <= 0 or length > _MAX_BODY:
            self._json(400, {'error': 'Tamaño inválido'})
            return
        try:
            data = json.loads(self.rfile.read(length).decode('utf-8'))
            text = (data.get('text') or '').strip()
        except (ValueError, AttributeError):
            self._json(400, {'error': 'JSON inválido'})
            return
        if not text:
            self._json(400, {'error': 'Texto vacío'})
            return
        # Guardar y responder ANTES de señalar; así la respuesta llega al navegador
        # antes de que el hilo principal cierre el servidor (evita "error de conexión").
        self.server.received = text
        self._json(200, {'ok': True})
        self.server.event.set()

    def _json(self, code, obj):
        body = json.dumps(obj).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)
        self.wfile.flush()


def receive_text(title='Escribir desde el móvil/PC', default=''):
    """Devuelve el texto recibido, '' si se canceló/agotó/vació, o None si no se pudo
    usar la web (sin red local o puertos ocupados) para que el caller use el teclado."""
    ip = _get_lan_ip()
    if not ip or ip == '127.0.0.1':
        return None

    server = None
    for offset in range(_PORT_COUNT):
        try:
            server = _Server(('', _PORT_START + offset), _Handler, title, default)
            break
        except OSError:
            continue
    if server is None:
        return None

    port = server.server_address[1]
    addr = f'http://{ip}:{port}'
    xbmc.log(f'[EspaDaily] web_input en {addr}', xbmc.LOGINFO)

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    pdp = xbmcgui.DialogProgress()
    pdp.create('EspaDaily - Escribir desde el móvil',
               f'Abre esta dirección en tu navegador:\n\n[B]{addr}[/B]\n\n{title}')

    received = None
    elapsed = 0.0
    try:
        while elapsed < _TIMEOUT_S:
            if pdp.iscanceled():
                break
            if server.event.wait(_POLL_S):
                # Leer solo aquí; si se cancela en el mismo instante que llega el
                # texto, prevalece la cancelación (received queda None).
                received = server.received
                break
            elapsed += _POLL_S
            remaining = int(_TIMEOUT_S - elapsed)
            pdp.update(int(elapsed / _TIMEOUT_S * 100),
                       f'Abre esta dirección en tu navegador:\n\n[B]{addr}[/B]\n\n'
                       f'Esperando texto... ({remaining}s)')
    finally:
        pdp.close()
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)

    if received:
        xbmcgui.Dialog().notification('EspaDaily', 'Texto recibido',
                                      xbmcgui.NOTIFICATION_INFO, 1500)
        return received
    if elapsed >= _TIMEOUT_S:
        xbmcgui.Dialog().notification('EspaDaily', 'Tiempo agotado',
                                      xbmcgui.NOTIFICATION_WARNING, 2000)
    return ''


_PAGE = """<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<title>EspaDaily</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  background:#0d1117;color:#c9d1d9;
  min-height:100vh;display:flex;align-items:center;justify-content:center;
  padding:16px;
}
.card{
  background:#161b22;border:1px solid #30363d;border-radius:12px;
  padding:32px 24px;max-width:480px;width:100%;
  box-shadow:0 8px 32px rgba(0,0,0,.4);
}
h1{
  font-size:1.4em;text-align:center;margin-bottom:6px;
  color:#e6edf3;font-weight:600;
}
.sub{
  text-align:center;color:#8b949e;font-size:.85em;margin-bottom:24px;
}
input[type=text]{
  width:100%;padding:14px 12px;
  background:#0d1117;color:#c9d1d9;
  border:1px solid #30363d;border-radius:8px;
  font-size:16px;outline:none;
  transition:border-color .2s;
}
input[type=text]:focus{border-color:#58a6ff}
input[type=text]::placeholder{color:#484f58}
.btn{
  display:block;width:100%;padding:14px;margin-top:16px;
  background:#1f6feb;color:#fff;
  border:none;border-radius:8px;
  font-size:1em;font-weight:600;cursor:pointer;
  transition:background .2s;
}
.btn:hover{background:#388bfd}
.btn:active{background:#1f6feb;transform:scale(.98)}
.btn:disabled{background:#21262d;color:#484f58;cursor:not-allowed}
.msg{
  margin-top:14px;padding:10px 14px;border-radius:8px;
  font-size:.9em;text-align:center;display:none;
}
.msg.ok{display:flex;align-items:center;justify-content:center;gap:8px;background:#0d2818;color:#3fb950;border:1px solid #238636}
.msg.err{display:block;background:#2d1117;color:#f85149;border:1px solid #da3633}
.check-svg{width:20px;height:20px;flex-shrink:0}
.check-svg circle{stroke:#3fb950;stroke-width:2;fill:none;stroke-dasharray:52;stroke-dashoffset:52;animation:circ .4s ease forwards}
.check-svg path{stroke:#3fb950;stroke-width:2;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:20;stroke-dashoffset:20;animation:tick .3s .35s ease forwards}
@keyframes circ{to{stroke-dashoffset:0}}
@keyframes tick{to{stroke-dashoffset:0}}
.footer{
  text-align:center;color:#484f58;font-size:.75em;margin-top:20px;
}
</style>
</head>
<body>
<div class="card">
  <h1>EspaDaily</h1>
  <p class="sub">__TITLE__</p>
  <input type="text" id="txt" value="__VALUE__" placeholder="Escribe aqui..." autofocus>
  <button class="btn" id="send" onclick="enviar()">Enviar a Kodi</button>
  <div class="msg" id="msg"></div>
  <p class="footer">El servidor se cerrara automaticamente tras recibir el texto.</p>
</div>
<script>
function checkSVG(){
  return '<svg class="check-svg" viewBox="0 0 24 24">'
    +'<circle cx="12" cy="12" r="10"/>'
    +'<path d="M7 12.5l3 3 7-7"/></svg>';
}
function enviar(){
  var txt=document.getElementById('txt').value.trim();
  var msg=document.getElementById('msg');
  var btn=document.getElementById('send');
  msg.className='msg';msg.style.display='none';
  if(!txt){
    msg.className='msg err';msg.textContent='Escribe algo';msg.style.display='block';
    return;
  }
  btn.disabled=true;btn.textContent='Enviando...';
  fetch('/send',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({text:txt})
  })
  .then(function(r){return r.json()})
  .then(function(d){
    if(d.ok){
      msg.className='msg ok';
      msg.innerHTML=checkSVG()+'<span>Texto enviado a Kodi</span>';
      btn.textContent='Enviado';
    }else{
      msg.className='msg err';
      msg.textContent=d.error||'Error desconocido';
      btn.disabled=false;btn.textContent='Enviar a Kodi';
    }
    msg.style.display='';
  })
  .catch(function(){
    msg.className='msg err';
    msg.textContent='Error de conexion con Kodi';
    msg.style.display='block';
    btn.disabled=false;btn.textContent='Enviar a Kodi';
  });
}
var _inp=document.getElementById('txt');
_inp.focus();_inp.select();
_inp.addEventListener('keydown',function(e){
  if(e.key==='Enter'){e.preventDefault();enviar()}
});
</script>
</body>
</html>"""
