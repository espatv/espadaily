# -*- coding: utf-8 -*-
# EspaDaily — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
import os
import json
import re as _re
import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui



_PROFILE_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
if not os.path.exists(_PROFILE_PATH): os.makedirs(_PROFILE_PATH)

_CONTEXT_FILE = os.path.join(_PROFILE_PATH, "full_context.json")
_DEBUG_FILE = os.path.join(_PROFILE_PATH, 'debug_state.json')
_FROZEN_FILE = os.path.join(_PROFILE_PATH, 'frozen_state.json')
_RECENT_FILE = os.path.join(_PROFILE_PATH, 'recent_state.json')
_FAV_FILE = os.path.join(_PROFILE_PATH, 'favorites.json')
_DL_FILE = os.path.join(_PROFILE_PATH, 'downloads_history.json')
_DURATION_FILE = os.path.join(_PROFILE_PATH, 'min_duration.json')
_ADVANCED_SEARCH_FILE = os.path.join(_PROFILE_PATH, 'advanced_search_state.json')
_SNAPSHOT_CTX_FILE = os.path.join(_PROFILE_PATH, 'snapshot_context.json')
_PALANTIR_INTEGRATION_FILE = os.path.join(_PROFILE_PATH, 'palantir_integration_state.json')
_BALANDRO_INTEGRATION_FILE = os.path.join(_PROFILE_PATH, 'balandro_integration_state.json')
_IPTV_ANTI_ERRORS_FILE = os.path.join(_PROFILE_PATH, 'iptv_anti_errors_state.json')
_TDT_ENGINE_FILE = os.path.join(_PROFILE_PATH, 'tdt_engine_state.json')
_ACC_FILE        = os.path.join(_PROFILE_PATH, 'acc_settings.json')


def get_acc_settings():
    if not os.path.exists(_ACC_FILE): return {}
    try:
        with open(_ACC_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return {}

def _save_acc_settings(data):
    with open(_ACC_FILE, 'w', encoding='utf-8') as f: json.dump(data, f)

def get_acc_color_mode():
    return get_acc_settings().get('color_mode', 'none')

def set_acc_color_mode(mode):
    d = get_acc_settings(); d['color_mode'] = mode; _save_acc_settings(d)

def get_acc_force_bold():
    return get_acc_settings().get('force_bold', True)

def set_acc_force_bold(state):
    d = get_acc_settings(); d['force_bold'] = state; _save_acc_settings(d)

def get_acc_strip_symbols():
    return get_acc_settings().get('strip_symbols', False)

def set_acc_strip_symbols(state):
    d = get_acc_settings(); d['strip_symbols'] = state; _save_acc_settings(d)


_ACC_COLOR_MODE    = get_acc_color_mode()
_ACC_FORCE_BOLD    = get_acc_force_bold()
_ACC_STRIP_SYMBOLS = get_acc_strip_symbols()

_ACC_DRG_MAP = {
    'red': 'orange', 'green': 'cyan', 'lime': 'cyan', 'limegreen': 'cyan',
    'darkred': 'darkorange', 'darkgreen': 'darkcyan',
}
_ACC_DBY_MAP = {
    'yellow': 'magenta', 'gold': 'magenta', 'khaki': 'magenta',
    'blue': 'red', 'cyan': 'red', 'aqua': 'red', 'skyblue': 'red',
    'dodgerblue': 'red', 'deepskyblue': 'red', 'lightblue': 'red',
}
_ACC_HCD_KEEP_RED = frozenset({'red', 'darkred', 'crimson'})
_ACC_COLOR_RE     = _re.compile(r'\[COLOR\s+([a-zA-Z]+)\]')
_ACC_BOLD_RE      = _re.compile(r'\[/?B\]')
_ACC_SYMBOL_TABLE = str.maketrans('★●○▲▼◑◐', '**-^v~~')

def _acc_remap(match):
    c = match.group(1).lower()
    if _ACC_COLOR_MODE == 'white':
        return '[COLOR white]'
    elif _ACC_COLOR_MODE == 'daltonic_rg':
        return '[COLOR ' + _ACC_DRG_MAP.get(c, 'white') + ']'
    elif _ACC_COLOR_MODE == 'daltonic_by':
        return '[COLOR ' + _ACC_DBY_MAP.get(c, 'white') + ']'
    elif _ACC_COLOR_MODE == 'hc_dark':
        return '[COLOR ' + (c if c in _ACC_HCD_KEEP_RED else 'yellow') + ']'
    elif _ACC_COLOR_MODE == 'hc_light':
        return '[COLOR ' + (c if c in _ACC_HCD_KEEP_RED else 'black') + ']'
    return match.group(0)

def _acc_transform(s):
    if not isinstance(s, str) or not s:
        return s
    if _ACC_STRIP_SYMBOLS:
        s = s.translate(_ACC_SYMBOL_TABLE)
    if _ACC_FORCE_BOLD:
        if '[B]' not in s:
            s = '[B]' + s + '[/B]'
    else:
        s = _ACC_BOLD_RE.sub('', s)
    if _ACC_COLOR_MODE not in ('', 'none'):
        s = _ACC_COLOR_RE.sub(_acc_remap, s)
    return s

_OrigListItem = xbmcgui.ListItem

def _ListItemFactory(label="", label2="", path="", offscreen=False):
    label = _acc_transform(label)
    if label2:
        label2 = _acc_transform(label2)
    return _OrigListItem(label=label, label2=label2, path=path, offscreen=offscreen)

xbmcgui.ListItem = _ListItemFactory


def is_iptv_anti_errors_active():
    if not os.path.exists(_IPTV_ANTI_ERRORS_FILE): return False
    try:
        with open(_IPTV_ANTI_ERRORS_FILE, 'r', encoding='utf-8') as o:
            return json.load(o).get('active', False)
    except Exception:
        return False

def set_iptv_anti_errors(state):
    with open(_IPTV_ANTI_ERRORS_FILE, 'w', encoding='utf-8') as o:
        json.dump({'active': state}, o)


def is_tdt_inputstream_active():
    if not os.path.exists(_TDT_ENGINE_FILE): return False
    try:
        with open(_TDT_ENGINE_FILE, 'r', encoding='utf-8') as o:
            return json.load(o).get('active', False)
    except Exception:
        return False

def set_tdt_inputstream(state):
    with open(_TDT_ENGINE_FILE, 'w', encoding='utf-8') as o:
        json.dump({'active': state}, o)


def get_context_level():
    if not os.path.exists(_CONTEXT_FILE): return 1 # Default
    try:
        with open(_CONTEXT_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            val = data.get("level", 1)

            if isinstance(val, bool): return 1 if val else 0
            return int(val)
    except Exception: return 1

def cycle_context_level():
    """Cicla el nivel 0 -> 1 -> 2 -> 3 -> 0 y lo guarda. Devuelve el nuevo nivel."""
    current = get_context_level()
    new_level = (current + 1) % 4
    try:
        with open(_CONTEXT_FILE, 'w', encoding='utf-8') as f: json.dump({"level": new_level}, f)
        return new_level
    except Exception:
        return current


def get_snapshot_context_level():
    if not os.path.exists(_SNAPSHOT_CTX_FILE): return -1
    try:
        with open(_SNAPSHOT_CTX_FILE, 'r', encoding='utf-8') as f:
            return int(json.load(f).get("level", -1))
    except Exception: return -1

def cycle_snapshot_context():
    """Cicla -1 -> 0 -> 1 -> 2 -> -1"""
    curr = get_snapshot_context_level()
    new_val = curr + 1
    if new_val > 2: new_val = -1
    
    with open(_SNAPSHOT_CTX_FILE, 'w', encoding='utf-8') as f: json.dump({"level": new_val}, f)
    return new_val

def build_query(title, context_data, force_level=None):
    """Aplica contexto a un titulo segun el nivel configurado."""
    depth = get_context_level() if force_level is None else force_level
    
    if depth == 0: return title.strip()
    if not context_data: return title.strip()

    clean_title = title.strip()
    

    if "||" in context_data:
        parts = context_data.split("||")

        if depth > len(parts): depth = len(parts) 
        used = parts[-depth:]
        ctx_str = " ".join(used)
    else:

        ctx_str = context_data


    if ctx_str.lower() not in clean_title.lower():

        return f"{ctx_str} {clean_title}".strip()
    
    return clean_title



def is_debug_active():
    if not os.path.exists(_DEBUG_FILE): return False
    try:
        with open(_DEBUG_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_debug_active(state):
    with open(_DEBUG_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)



def is_frozen_active():
    if not os.path.exists(_FROZEN_FILE): return False
    try:
        with open(_FROZEN_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False


_PRIORITY_FILE = os.path.join(_PROFILE_PATH, 'priority_state.json')

def is_prioritize_match_active():
    if not os.path.exists(_PRIORITY_FILE): return False
    try:
        with open(_PRIORITY_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_prioritize_match(state):
    with open(_PRIORITY_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)



def is_recent_active():
    if not os.path.exists(_RECENT_FILE): return False
    try:
        with open(_RECENT_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_recent_active(state):
    with open(_RECENT_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)



def get_favorites():
    if not os.path.exists(_FAV_FILE): return []
    try:
        with open(_FAV_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return []

def add_favorite(title, url, icon, platform, action, params=None):
    favs = get_favorites()

    if any(f['title'] == title and f['platform'] == platform for f in favs): return False
    
    favs.append({
        "title": title, "url": url, "icon": icon, 
        "platform": platform, "action": action, "params": params or {}
    })
    try:
        with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(favs, f)
        return True
    except Exception: return False

def remove_favorite(url):
    favs = get_favorites()
    new_favs = [f for f in favs if f['url'] != url]
    with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(new_favs, f)
    return len(favs) != len(new_favs)

def rename_favorite(url, new_title):
    favs = get_favorites()
    changed = False
    for f in favs:
        if f['url'] == url:
            f['title'] = new_title
            changed = True
            break
    if changed:
        with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(favs, f)
    return changed

def move_favorite(url, direction):
    favs = get_favorites()
    index = -1
    for i, f in enumerate(favs):
        if f['url'] == url:
            index = i
            break
            
    if index == -1: return False
    
    if direction == "up" and index > 0:
        favs[index], favs[index-1] = favs[index-1], favs[index]
        with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(favs, f)
        return True
    elif direction == "down" and index < len(favs) - 1:
        favs[index], favs[index+1] = favs[index+1], favs[index]
        with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(favs, f)
        return True
        
    return False



def get_downloads():
    if not os.path.exists(_DL_FILE): return []
    try:
        with open(_DL_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return []

def log_download(title, path, vid):
    dls = get_downloads()

    entry = {"title": title, "path": path, "vid": vid}
    import time
    entry["date"] = time.strftime("%d/%m/%Y %H:%M")
    dls.insert(0, entry)
    dls = dls[:50]
    with open(_DL_FILE, 'w', encoding='utf-8') as f: json.dump(dls, f)

def remove_download(path):
    dls = get_downloads()
    new_dls = [d for d in dls if d['path'] != path]
    with open(_DL_FILE, 'w', encoding='utf-8') as f: json.dump(new_dls, f)


def get_min_duration():
    if not os.path.exists(_DURATION_FILE): return 0
    try:
        with open(_DURATION_FILE, 'r', encoding='utf-8') as f: return json.load(f).get('minutes', 0)
    except Exception: return 0

def set_min_duration(minutes):
    with open(_DURATION_FILE, 'w', encoding='utf-8') as f: json.dump({'minutes': minutes}, f)


def is_advanced_search_active():
    if not os.path.exists(_ADVANCED_SEARCH_FILE): return True
    try:
        with open(_ADVANCED_SEARCH_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', True)
    except Exception: return True

def set_advanced_search_active(state):
    with open(_ADVANCED_SEARCH_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)


_PALANTIR_SEARCH_FILE = os.path.join(_PROFILE_PATH, 'palantir_search_state.json')

def is_palantir_search_active():
    if not os.path.exists(_PALANTIR_SEARCH_FILE): return False
    try:
        with open(_PALANTIR_SEARCH_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_palantir_search_active(state):
    with open(_PALANTIR_SEARCH_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)


def is_palantir_integration_enabled():
    """Devuelve True si la integracion con Palantir 3 esta habilitada (por defecto: True)."""
    if not os.path.exists(_PALANTIR_INTEGRATION_FILE): return True
    try:
        with open(_PALANTIR_INTEGRATION_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', True)
    except Exception: return True

def set_palantir_integration_enabled(state):
    """Guarda el estado del toggle de integracion con Palantir."""
    with open(_PALANTIR_INTEGRATION_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)

def is_palantir_installed():
    """Comprueba si plugin.video.palantir3 esta instalado en el sistema."""
    try:
        return xbmc.getCondVisibility("System.HasAddon(plugin.video.palantir3)")
    except Exception:
        return False

def is_balandro_integration_enabled():
    """Devuelve True si la integracion con Balandro esta habilitada (por defecto: True)."""
    if not os.path.exists(_BALANDRO_INTEGRATION_FILE): return True
    try:
        with open(_BALANDRO_INTEGRATION_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', True)
    except Exception: return True

def set_balandro_integration_enabled(state):
    """Guarda el estado del toggle de integracion con Balandro."""
    with open(_BALANDRO_INTEGRATION_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)

def is_balandro_installed():
    """Comprueba si plugin.video.balandro esta instalado en el sistema."""
    try:
        return xbmc.getCondVisibility("System.HasAddon(plugin.video.balandro)")
    except Exception:
        return False


_EXTERNAL_INTEGRATIONS_FILE = os.path.join(_PROFILE_PATH, 'external_integrations_state.json')

def are_external_integrations_disabled():
    if not os.path.exists(_EXTERNAL_INTEGRATIONS_FILE): return False
    try:
        with open(_EXTERNAL_INTEGRATIONS_FILE, 'r', encoding='utf-8') as o:
            return json.load(o).get('disabled', False)
    except Exception:
        return False

def set_external_integrations_disabled(state):
    with open(_EXTERNAL_INTEGRATIONS_FILE, 'w', encoding='utf-8') as o:
        json.dump({'disabled': state}, o)



_ACESTREAM_SERVER_FILE = os.path.join(_PROFILE_PATH, 'acestream_server_mode.json')

def get_acestream_server_mode():
    if not os.path.exists(_ACESTREAM_SERVER_FILE): return "publico"
    try:
        with open(_ACESTREAM_SERVER_FILE, 'r', encoding='utf-8') as o:
            return json.load(o).get('mode', 'publico')
    except Exception:
        return "publico"

def set_acestream_server_mode(mode):
    with open(_ACESTREAM_SERVER_FILE, 'w', encoding='utf-8') as o:
        json.dump({'mode': mode}, o)

def cycle_acestream_server_mode():
    current = get_acestream_server_mode()
    order = ["publico", "auto", "local"]
    idx = order.index(current) if current in order else 0
    new_mode = order[(idx + 1) % len(order)]
    set_acestream_server_mode(new_mode)
    return new_mode


_ACESTREAM_ENABLED_FILE = os.path.join(_PROFILE_PATH, 'acestream_enabled.json')

def is_acestream_enabled():
    if not os.path.exists(_ACESTREAM_ENABLED_FILE): return False
    try:
        with open(_ACESTREAM_ENABLED_FILE, 'r', encoding='utf-8') as o:
            return json.load(o).get('active', False) is True
    except Exception:
        return False

def set_acestream_enabled(state):
    with open(_ACESTREAM_ENABLED_FILE, 'w', encoding='utf-8') as o:
        json.dump({'active': bool(state)}, o)


_LEGAL_DISCLAIMER_FILE = os.path.join(_PROFILE_PATH, 'legal_state.json')

def is_legal_disclaimer_accepted():
    if not os.path.exists(_LEGAL_DISCLAIMER_FILE): return False
    try:
        with open(_LEGAL_DISCLAIMER_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('accepted', False)
    except Exception: return False


def set_legal_disclaimer_accepted(state):
    with open(_LEGAL_DISCLAIMER_FILE, 'w', encoding='utf-8') as o: json.dump({'accepted': state}, o)


_TRAKT_SETTINGS_FILE = os.path.join(_PROFILE_PATH, 'trakt_settings.json')
_ESPADAILY_TRAKT_CLIENT_ID = "df506cf48d65deed029739f6f97f71b06714bb8da1e820df25d932c983a2b3ae"
_ESPADAILY_TMDB_API_KEY = "273ffd2f428df3e0ef479eeb8d632541"

_DEFAULT_TRAKT_LIST_IDS = [
    "805405", "1282987", "2748259", "797798", "832943",
    "4737076", "4834057", "9429302", "851495", "1558961",
    "6544049", "3785062", "20579314", "11512456", "2142753",
    "2143363", "1211468", "11416887", "801239", "6652041",
    "20770365", "1326415", "1076107", "20492899", "20770267",
    "20772087", "21583416"
]

def get_trakt_settings():
    if not os.path.exists(_TRAKT_SETTINGS_FILE): return {"api_key": "", "lists": []}
    try:
        with open(_TRAKT_SETTINGS_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return {"api_key": "", "lists": []}

def save_trakt_settings(data):
    with open(_TRAKT_SETTINGS_FILE, 'w', encoding='utf-8') as f: json.dump(data, f)

def get_trakt_api_key():
    return get_trakt_settings().get("api_key", "") or _ESPADAILY_TRAKT_CLIENT_ID

def set_trakt_api_key(key):
    data = get_trakt_settings()
    data["api_key"] = key
    save_trakt_settings(data)

def get_trakt_lists():
    return get_trakt_settings().get("lists", [])

def add_trakt_list(list_id, name, user, item_count=0):
    data = get_trakt_settings()
    lists = data.get("lists", [])

    for l in lists:
        if l['id'] == list_id:

            l['name'] = name
            l['user'] = user
            l['item_count'] = item_count
            save_trakt_settings(data)
            return
    
    lists.append({"id": list_id, "name": name, "user": user, "item_count": item_count})
    data["lists"] = lists
    save_trakt_settings(data)

def seed_default_trakt_lists(api_key=''):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    removed_defaults = set(data.get("removed_defaults", []))
    existing_ids = {l['id'] for l in lists}
    new_ids = [lid for lid in _DEFAULT_TRAKT_LIST_IDS if lid not in existing_ids and lid not in removed_defaults]
    if not new_ids:
        return
    names = {lid: f"Lista Trakt #{lid}" for lid in new_ids}
    if api_key:
        try:
            import requests
            from concurrent.futures import ThreadPoolExecutor
            headers = {'trakt-api-key': api_key, 'trakt-api-version': '2', 'Content-Type': 'application/json'}
            def fetch_name(lid):
                try:
                    r = requests.get(f'https://api.trakt.tv/lists/{lid}', headers=headers, timeout=5)
                    if r.status_code == 200:
                        return lid, r.json().get('name', names[lid])
                except Exception:
                    pass
                return lid, names[lid]
            with ThreadPoolExecutor(max_workers=8) as ex:
                for lid, name in ex.map(fetch_name, new_ids):
                    names[lid] = name
        except Exception:
            pass
    for lid in new_ids:
        lists.append({"id": lid, "name": names[lid], "user": "official", "item_count": 0})
    data["lists"] = lists
    save_trakt_settings(data)

def remove_trakt_list(list_id):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    if list_id in _DEFAULT_TRAKT_LIST_IDS:
        removed = data.get("removed_defaults", [])
        if list_id not in removed:
            removed.append(list_id)
        data["removed_defaults"] = removed
    data["lists"] = [l for l in lists if l['id'] != list_id]
    save_trakt_settings(data)
