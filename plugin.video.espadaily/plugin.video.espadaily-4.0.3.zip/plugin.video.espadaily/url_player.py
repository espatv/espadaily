# -*- coding: utf-8 -*-
# EspaDaily — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
"""
Reproductor de URLs Externas para EspaDaily
============================================
Permite al usuario pegar una URL de vídeo y reproducirla en Kodi.

Detección inteligente:
  - Dailymotion (dailymotion.com / dai.ly)   -> dm_gujal
  - YouTube     (youtube.com / youtu.be)      -> plugin.video.youtube
  - Streams     (.m3u8 / .mp4 / .mpd / etc.)  -> reproducción directa
  - Otras webs                                -> SendToKodi / yt-dlp
"""
import sys
import os
import json
import time
import re
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

_ADDON_ID = "plugin.video.espadaily"
_profile_path = None
MAX_HISTORY = 20
MAX_BOOKMARKS = 50

_SN_ID   = "plugin.video.streamninja"
_SN_REPO = "repository.streamninja"
_SN_ZIP  = "https://fullstackcurso.github.io/estreamninja/repository.streamninja-1.0.0.zip"

_STREAM_EXTENSIONS = {
    ".m3u8", ".mp4", ".mkv", ".avi", ".ts", ".flv",
    ".mov", ".wmv", ".webm", ".mpd", ".m3u",
}

_ACESTREAM_ID_RE = re.compile(r"^[a-fA-F0-9]{40}$")
_ACESTREAM_URL_RE = re.compile(r"^acestream://[a-fA-F0-9]{40}$", re.IGNORECASE)

_GENERIC_HEADERS = {
    "user-agent", "accept", "accept-language", "accept-encoding",
    "sec-fetch-dest", "sec-fetch-mode", "sec-fetch-site",
    "sec-ch-ua", "sec-ch-ua-mobile", "sec-ch-ua-platform",
}


def is_acestream_id(text):
    if not text:
        return False
    return bool(_ACESTREAM_ID_RE.match(text.strip()))





def _get_profile():
    global _profile_path
    if _profile_path is None:
        _profile_path = xbmcvfs.translatePath(
            xbmcaddon.Addon().getAddonInfo("profile")
        )
        if not os.path.exists(_profile_path):
            os.makedirs(_profile_path)
    return _profile_path


def _history_path():
    return os.path.join(_get_profile(), "url_history.json")


def _bookmarks_path():
    return os.path.join(_get_profile(), "url_bookmarks.json")


def _load_json(path):
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return []


def _save_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
    except IOError:
        pass





def parse_url_with_headers(raw_url):
    """Separa URL y headers en formato pipe.

    Entrada: "http://example.com/video.m3u8|User-Agent=xxx&Referer=yyy"
    Salida:  ("http://example.com/video.m3u8", {"User-Agent": "xxx", ...})
    """
    if not raw_url:
        return "", {}
    raw_url = raw_url.strip()
    if "|" not in raw_url:
        return raw_url, {}

    parts = raw_url.split("|", 1)
    url = parts[0].strip()
    headers_str = parts[1].strip()
    if not headers_str:
        return url, {}

    headers = {}
    for pair in headers_str.split("&"):
        if "=" in pair:
            key, value = pair.split("=", 1)
            key = key.strip()
            value = value.strip()
            if len(value) >= 2 and value[0] in ('"', "'") and value[-1] == value[0]:
                value = value[1:-1]
            if key:
                headers[key] = urllib.parse.unquote(value)
    return url, headers


def is_direct_stream(url):
    """Determina si la URL apunta a un stream reproducible directamente."""
    try:
        parsed = urllib.parse.urlparse(url)
        _, ext = os.path.splitext(parsed.path.lower())
        return ext in _STREAM_EXTENSIONS
    except Exception:
        return False


def build_kodi_url(url, headers=None):
    """Reconstruye URL con headers en formato pipe de Kodi."""
    if not headers:
        return url
    parts = ["{0}={1}".format(k, v) for k, v in headers.items()]
    return url + "|" + "&".join(parts)





def detect_dailymotion_id(url):
    """Extrae el ID de un vídeo de Dailymotion o devuelve None."""
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or "").lower()
        if host.startswith("www."):
            host = host[4:]

        if host.endswith("dailymotion.com"):
            match = re.match(r"/video/([a-zA-Z0-9]+)", parsed.path)
            if match:
                return match.group(1)
            match = re.match(r"/embed/video/([a-zA-Z0-9]+)", parsed.path)
            if match:
                return match.group(1)
        elif host == "dai.ly":
            vid = parsed.path.strip("/")
            if vid:
                return vid.split("_")[0].split("?")[0]
    except Exception:
        pass
    return None


def detect_youtube_id(url):
    """Extrae el ID de un vídeo de YouTube o devuelve None."""
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or "").lower()
        if host.startswith("www."):
            host = host[4:]

        if host in ("youtube.com", "m.youtube.com"):
            if "/watch" in parsed.path:
                params = urllib.parse.parse_qs(parsed.query)
                vid_list = params.get("v", [])
                if vid_list:
                    return vid_list[0]
            elif "/shorts/" in parsed.path:
                match = re.match(r"/shorts/([a-zA-Z0-9_-]+)", parsed.path)
                if match:
                    return match.group(1)
        elif host == "youtu.be":
            vid = parsed.path.strip("/")
            if vid:
                return vid
    except Exception:
        pass
    return None


def detect_url_type(raw_url):
    """Clasifica una URL y devuelve (tipo, id_o_url).
    Tipos: 'acestream', 'torrent', 'dailymotion', 'youtube', 'direct_stream', 'web_page'
    """
    url, _ = parse_url_with_headers(raw_url)

    if _ACESTREAM_URL_RE.match(url):
        content_id = url[len("acestream://"):].lower()
        return "acestream", content_id

    if url.startswith("magnet:"):
        return "torrent", url
    try:
        path = urllib.parse.urlparse(url).path.lower()
        if path.endswith(".torrent"):
            return "torrent", url
    except Exception:
        pass

    dm_id = detect_dailymotion_id(url)
    if dm_id:
        return "dailymotion", dm_id

    yt_id = detect_youtube_id(url)
    if yt_id:
        return "youtube", yt_id

    if is_direct_stream(url):
        return "direct_stream", raw_url

    return "web_page", url





def _friendly_label(raw_url):
    """Genera un nombre legible a partir de la URL, obteniendo el titulo real si es posible."""
    import requests as _req
    url_type, value = detect_url_type(raw_url)
    if url_type == "dailymotion":
        try:
            r = _req.get(
                "https://api.dailymotion.com/video/{0}?fields=title".format(value),
                timeout=3,
            )
            title = r.json().get("title", "")
            if title:
                return title
        except Exception:
            pass
        return "Dailymotion: {0}".format(value)
    if url_type == "youtube":
        try:
            r = _req.get(
                "https://www.youtube.com/oembed?url={0}&format=json".format(
                    urllib.parse.quote(raw_url, safe="")
                ),
                timeout=3,
            )
            title = r.json().get("title", "")
            if title:
                return title
        except Exception:
            pass
        return "YouTube: {0}".format(value)
    if url_type == "acestream":
        short = value[:12] + "..." if len(value) > 12 else value
        return "Acestream: {0}".format(short)
    if url_type == "torrent":
        if value.startswith("magnet:"):
            return "Magnet torrent"
        try:
            name = os.path.basename(urllib.parse.urlparse(value).path) or value[:40]
        except Exception:
            name = value[:40]
        return "Torrent: {0}".format(name)
    try:
        parsed = urllib.parse.urlparse(raw_url.split("|")[0])
        host = parsed.hostname or ""
        path = parsed.path.rstrip("/")
        name = os.path.basename(path) if path else host
        if name and host:
            return "{0} ({1})".format(name, host)
        return host or raw_url[:60]
    except Exception:
        return raw_url[:60]


def _add_to_history(raw_url, label=None):
    history = _load_json(_history_path())
    history = [h for h in history if h.get("url") != raw_url]
    entry = {
        "url": raw_url,
        "label": label or raw_url,
        "date": time.strftime("%d/%m/%Y %H:%M"),
        "timestamp": int(time.time()),
    }
    history.insert(0, entry)
    history = history[:MAX_HISTORY]
    _save_json(_history_path(), history)


def _get_history():
    return _load_json(_history_path())


def _clear_history():
    _save_json(_history_path(), [])


def _remove_from_history(url):
    history = _get_history()
    history = [h for h in history if h.get("url") != url]
    _save_json(_history_path(), history)





def _get_bookmarks():
    return _load_json(_bookmarks_path())


def _add_bookmark(name, url):
    bookmarks = _get_bookmarks()
    if any(b.get("url") == url for b in bookmarks):
        return False
    bookmarks.append({
        "name": name,
        "url": url,
        "date": time.strftime("%d/%m/%Y %H:%M"),
    })
    bookmarks = bookmarks[:MAX_BOOKMARKS]
    _save_json(_bookmarks_path(), bookmarks)
    return True


def _remove_bookmark(url):
    bookmarks = _get_bookmarks()
    new_bookmarks = [b for b in bookmarks if b.get("url") != url]
    _save_json(_bookmarks_path(), new_bookmarks)
    return len(bookmarks) != len(new_bookmarks)


def _rename_bookmark(url, new_name):
    bookmarks = _get_bookmarks()
    changed = False
    for b in bookmarks:
        if b.get("url") == url:
            b["name"] = new_name
            changed = True
            break
    if changed:
        _save_json(_bookmarks_path(), bookmarks)
    return changed





def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def open_url_dialog():
    """Menú principal de Abrir URL."""
    h = int(sys.argv[1])

    sn_installed = xbmc.getCondVisibility("System.HasAddon({0})".format(_SN_ID))
    lbl_sn = "[COLOR royalblue][B]Abrir StreamNinja[/B][/COLOR]" if sn_installed \
             else "[COLOR orange][B]Instalar StreamNinja[/B][/COLOR]"
    plt_sn = "¡Activa el Modo Ninja! Desenvaina la potencia de StreamNinja para dominar cualquier enlace de vídeo con precisión y rapidez." if sn_installed \
             else "Instala el Modo Ninja: Desenvaina la potencia necesaria para dominar cualquier enlace de vídeo."
    _media = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    sn_icon = os.path.join(_media, 'sn_logo.jpg')
    li_sn = xbmcgui.ListItem(label=lbl_sn)
    li_sn.setArt({'icon': sn_icon, 'thumb': sn_icon})
    li_sn.setInfo("video", {"plot": plt_sn})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="url_player_ensure_sn"), listitem=li_sn, isFolder=False)

    li = xbmcgui.ListItem(
        label="[COLOR limegreen][B]Pegar URL de vídeo[/B][/COLOR]"
    )
    li.setArt({"icon": "DefaultAddSource.png"})
    li.setInfo("video", {
        "plot": (
            "Pega una URL de vídeo para reproducirla.\n\n"
            "URLs soportadas:\n"
            "  \u2022 Dailymotion: dailymotion.com/video/xxx\n"
            "  \u2022 YouTube: youtube.com/watch?v=xxx\n"
            "  \u2022 AceStream: acestream://id  o  ID de 40 caracteres hex\n"
            "  \u2022 Torrent: magnet:?xt=urn:btih:xxx  o  URL de fichero .torrent\n"
            "  \u2022 Stream directo: .m3u8, .mp4, .mkv, .mpd\n"
            "  \u2022 Con headers: URL|User-Agent=xxx&Referer=yyy\n"
            "  \u2022 Otras webs: resolución automática"
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_input"), listitem=li, isFolder=False
    )

    history = _get_history()
    if history:
        li = xbmcgui.ListItem(
            label="[COLOR cyan]Historial de URLs ({0})[/COLOR]".format(len(history))
        )
        li.setArt({"icon": os.path.join(_media, 'historial.png')})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_history"), listitem=li, isFolder=True
        )

    bookmarks = _get_bookmarks()
    if bookmarks:
        li = xbmcgui.ListItem(
            label="[COLOR khaki]Marcadores ({0})[/COLOR]".format(len(bookmarks))
        )
        li.setArt({"icon": "DefaultSets.png"})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_bookmarks"), listitem=li, isFolder=True
        )


    xbmcplugin.endOfDirectory(h)


def _resolve_and_play(raw_url):
    """Detecta tipo de URL y reproduce con el método adecuado."""
    url_type, value = detect_url_type(raw_url)

    if url_type == "acestream":
        has_plexus = xbmc.getCondVisibility("System.HasAddon(program.plexus)")
        has_horus = xbmc.getCondVisibility("System.HasAddon(script.module.horus)")
        if has_plexus:
            xbmcgui.Dialog().notification(
                "EspaDaily", "Abriendo en Plexus...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            ace_url = "plugin://program.plexus/?" + urllib.parse.urlencode({
                "url": "acestream://" + value, "mode": "1", "name": "Acestream"
            })
            xbmc.executebuiltin('PlayMedia("{0}")'.format(ace_url))
        elif has_horus:
            xbmcgui.Dialog().notification(
                "EspaDaily", "Abriendo en Horus...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            ace_url = "plugin://script.module.horus/?" + urllib.parse.urlencode({
                "action": "play", "id": value
            })
            xbmc.executebuiltin('PlayMedia("{0}")'.format(ace_url))
        else:
            xbmcgui.Dialog().ok(
                "EspaDaily",
                "Para reproducir enlaces AceStream necesitas uno de estos addons:\n\n"
                "  • Plexus (program.plexus)\n"
                "  • Horus (script.module.horus)\n\n"
                "Instálalo y vuelve a intentarlo.",
            )

    elif url_type == "torrent":
        has_elementum = xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)")
        has_quasar = xbmc.getCondVisibility("System.HasAddon(plugin.video.quasar)")
        if has_elementum:
            xbmcgui.Dialog().notification(
                "EspaDaily", "Abriendo en Elementum...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            elem_url = "plugin://plugin.video.elementum/play?" + urllib.parse.urlencode({"uri": value})
            xbmc.executebuiltin('PlayMedia("{0}")'.format(elem_url))
        elif has_quasar:
            xbmcgui.Dialog().notification(
                "EspaDaily", "Abriendo en Quasar...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            quasar_url = "plugin://plugin.video.quasar/play?" + urllib.parse.urlencode({"uri": value})
            xbmc.executebuiltin('PlayMedia("{0}")'.format(quasar_url))
        else:
            xbmcgui.Dialog().ok(
                "EspaDaily",
                "Para reproducir enlaces magnet o .torrent necesitas uno de estos addons:\n\n"
                "  • Elementum (plugin.video.elementum)\n"
                "  • Quasar (plugin.video.quasar)\n\n"
                "Instálalo y vuelve a intentarlo.",
            )

    elif url_type == "dailymotion":
        xbmcgui.Dialog().notification(
            "EspaDaily", "Dailymotion: " + value,
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        played = False

        if xbmc.getCondVisibility("System.Platform.Windows"):
            try:
                import subprocess
                proc = subprocess.run(
                    [
                        "python", "-m", "yt_dlp",
                        "--dump-json", "--no-download",
                        "--format", "best[ext=mp4]/best",
                        "--no-playlist",
                        "https://www.dailymotion.com/video/" + value,
                    ],
                    capture_output=True, text=True, timeout=30,
                    creationflags=0x08000000,
                )
                if proc.returncode == 0 and proc.stdout.strip():
                    info = json.loads(proc.stdout)
                    stream_url = info.get("url", "")
                    if stream_url:
                        li = xbmcgui.ListItem(path=stream_url)
                        li.setProperty("IsPlayable", "true")
                        li.setContentLookup(False)
                        xbmc.Player().play(stream_url, li)
                        played = True
            except Exception as e:
                xbmc.log(
                    "[EspaDaily/url_player] yt-dlp DM failed: " + str(e),
                    xbmc.LOGWARNING,
                )

        if not played:
            try:
                import dm_gujal
                result = dm_gujal.play_dm_extreme(value)
                if result and result[0]:
                    final_url, subs, mime = result
                    li = xbmcgui.ListItem(path=final_url)
                    if mime:
                        li.setMimeType(mime)
                    if subs and isinstance(subs, list):
                        li.setSubtitles(subs)
                    li.setProperty("IsPlayable", "true")
                    xbmc.Player().play(final_url, li)
                    played = True
            except Exception as e:
                xbmc.log(
                    "[EspaDaily/url_player] dm_gujal error: " + str(e),
                    xbmc.LOGWARNING,
                )

        if not played:
            xbmcgui.Dialog().ok(
                "EspaDaily",
                "No se pudo resolver el vídeo de Dailymotion.",
            )

    elif url_type == "youtube":
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            xbmcgui.Dialog().notification(
                "EspaDaily", "Abriendo en YouTube...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            yt_url = "plugin://plugin.video.youtube/play/?video_id=" + value
            xbmc.executebuiltin('PlayMedia("{0}")'.format(yt_url))
        else:
            xbmcgui.Dialog().ok(
                "EspaDaily",
                "El addon de YouTube no está instalado.\n\n"
                "Instálalo para reproducir vídeos de YouTube.",
            )

    elif url_type == "direct_stream":
        url, headers = parse_url_with_headers(raw_url)
        kodi_url = build_kodi_url(url, headers)
        li = xbmcgui.ListItem(path=kodi_url)
        if ".mpd" in url.lower():
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "mpd")
        elif ".m3u8" in url.lower():
            li.setMimeType("application/x-mpegURL")
        if headers:
            meaningful = {k: v for k, v in headers.items() if k.lower() not in _GENERIC_HEADERS}
            if meaningful:
                header_str = "&".join("{0}={1}".format(k, v) for k, v in meaningful.items())
                li.setProperty("inputstream.adaptive.stream_headers", header_str)
        xbmc.Player().play(kodi_url, li)

    elif url_type == "web_page":
        has_stk = xbmc.getCondVisibility(
            "System.HasAddon(plugin.video.sendtokodi)"
        )
        has_yt = xbmc.getCondVisibility(
            "System.HasAddon(plugin.video.youtube)"
        )
        if has_stk:
            xbmcgui.Dialog().notification(
                "EspaDaily", "Resolviendo con SendToKodi...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            stk_url = (
                "plugin://plugin.video.sendtokodi/?"
                + urllib.parse.urlencode({"url": value})
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(stk_url))
        elif has_yt:
            xbmcgui.Dialog().notification(
                "EspaDaily", "Resolviendo con YouTube...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            yt_url = (
                "plugin://plugin.video.youtube/uri2addon/?uri="
                + urllib.parse.quote(value)
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(yt_url))
        else:
            xbmcgui.Dialog().ok(
                "EspaDaily",
                "No se puede resolver esta URL.\n\n"
                "Instala uno de estos addons:\n"
                "  \u2022 plugin.video.sendtokodi (recomendado)\n"
                "  \u2022 plugin.video.youtube\n\n"
                "O pega directamente la URL del stream.",
            )


def url_input():
    """Teclado para pegar una URL y reproducirla."""
    kb = xbmc.Keyboard("", "Pegar URL (Dailymotion, YouTube, stream...)")
    kb.doModal()
    if not kb.isConfirmed():
        return

    raw = kb.getText().strip()
    if not raw:
        return

    if is_acestream_id(raw):
        raw = "acestream://" + raw.lower()

    valid_schemes = ("http://", "https://", "rtmp://", "rtsp://", "acestream://", "magnet:")
    if not raw.startswith(valid_schemes):
        xbmcgui.Dialog().ok(
            "EspaDaily",
            "La URL no parece v\u00e1lida.\n\n"
            "Debe empezar por http://, https://, acestream://,\nmagnet:, rtmp:// o rtsp://\n\n"
            "Tambien puedes pegar un ID AceStream de 40 caracteres hex.",
        )
        return

    _add_to_history(raw, _friendly_label(raw))

    url_type, _ = detect_url_type(raw)
    type_labels = {
        "acestream": "AceStream",
        "torrent": "Torrent (magnet/.torrent)",
        "dailymotion": "Dailymotion",
        "youtube": "YouTube",
        "direct_stream": "Stream directo",
        "web_page": "P\u00e1gina web",
    }
    detected = type_labels.get(url_type, "Desconocido")
    url_display = raw[:50] + "..." if len(raw) > 50 else raw

    opts = [
        "Reproducir ahora ({0})".format(detected),
        "Guardar como marcador y reproducir",
        "Solo guardar como marcador",
    ]
    sel = xbmcgui.Dialog().select(url_display, opts)

    if sel == 0:
        _resolve_and_play(raw)
    elif sel == 1:
        name_kb = xbmc.Keyboard("", "Nombre para el marcador")
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            _add_bookmark(name_kb.getText().strip(), raw)
        _resolve_and_play(raw)
    elif sel == 2:
        name_kb = xbmc.Keyboard("", "Nombre para el marcador")
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            if _add_bookmark(name_kb.getText().strip(), raw):
                xbmcgui.Dialog().notification(
                    "EspaDaily", "Marcador guardado",
                    xbmcgui.NOTIFICATION_INFO,
                )
            else:
                xbmcgui.Dialog().notification(
                    "EspaDaily", "Ya existe este marcador",
                    xbmcgui.NOTIFICATION_INFO,
                )


def url_history_menu():
    """Historial de URLs reproducidas."""
    h = int(sys.argv[1])
    history = _get_history()

    if not history:
        li = xbmcgui.ListItem(
            label="[COLOR gray]No hay URLs en el historial[/COLOR]"
        )
        li.setArt({"icon": "DefaultIconInfo.png"})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    li = xbmcgui.ListItem(
        label="[COLOR red][B]Borrar todo el historial de URLs[/B][/COLOR]"
    )
    li.setArt({"icon": "DefaultIconError.png"})
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_history_clear"), listitem=li, isFolder=False
    )

    for entry in history:
        raw_url = entry.get("url", "")
        label = entry.get("label", raw_url)
        date = entry.get("date", "")

        display = label[:80] + "..." if len(label) > 80 else label
        li = xbmcgui.ListItem(label=display)
        li.setArt({"icon": "DefaultVideo.png"})
        li.setInfo("video", {"plot": "URL: {0}\n\nFecha: {1}".format(raw_url, date)})
        li.setProperty("IsPlayable", "true")

        cm = [
            (
                "Guardar como marcador",
                "RunPlugin({0})".format(
                    _u(action="url_bookmark_save_from_history", url=raw_url)
                ),
            ),
            (
                "Eliminar del historial",
                "RunPlugin({0})".format(
                    _u(action="url_history_remove", url=raw_url)
                ),
            ),
        ]
        li.addContextMenuItems(cm)

        play_url = _u(action="url_play", url=raw_url)
        xbmcplugin.addDirectoryItem(
            handle=h, url=play_url, listitem=li, isFolder=False
        )

    xbmcplugin.endOfDirectory(h)


def url_bookmarks_menu():
    """Marcadores de URLs guardados."""
    h = int(sys.argv[1])
    bookmarks = _get_bookmarks()

    if not bookmarks:
        li = xbmcgui.ListItem(
            label="[COLOR gray]No hay marcadores guardados[/COLOR]"
        )
        li.setArt({"icon": "DefaultIconInfo.png"})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for bm in bookmarks:
        url = bm.get("url", "")
        name = bm.get("name", url)
        date = bm.get("date", "")

        li = xbmcgui.ListItem(label=name)
        li.setArt({"icon": "DefaultVideo.png"})
        li.setInfo("video", {"plot": "URL: {0}\n\nGuardado: {1}".format(url, date)})
        li.setProperty("IsPlayable", "true")

        cm = [
            (
                "Renombrar",
                "RunPlugin({0})".format(_u(action="url_bookmark_rename", url=url)),
            ),
            (
                "Eliminar marcador",
                "RunPlugin({0})".format(_u(action="url_bookmark_delete", url=url)),
            ),
        ]
        li.addContextMenuItems(cm)

        play_url = _u(action="url_play", url=url)
        xbmcplugin.addDirectoryItem(
            handle=h, url=play_url, listitem=li, isFolder=False
        )

    xbmcplugin.endOfDirectory(h)





def bookmark_save_from_history(url):
    if not url:
        return
    kb = xbmc.Keyboard("", "Nombre para el marcador")
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _add_bookmark(kb.getText().strip(), url):
            xbmcgui.Dialog().notification(
                "EspaDaily", "Marcador guardado", xbmcgui.NOTIFICATION_INFO
            )
        else:
            xbmcgui.Dialog().notification(
                "EspaDaily", "Ya existe este marcador", xbmcgui.NOTIFICATION_INFO
            )


def bookmark_rename(url):
    if not url:
        return
    bookmarks = _get_bookmarks()
    current_name = ""
    for b in bookmarks:
        if b.get("url") == url:
            current_name = b.get("name", "")
            break

    kb = xbmc.Keyboard(current_name, "Nuevo nombre")
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _rename_bookmark(url, kb.getText().strip()):
            xbmc.executebuiltin("Container.Refresh")


def bookmark_delete(url):
    if not url:
        return
    if _remove_bookmark(url):
        xbmcgui.Dialog().notification(
            "EspaDaily", "Marcador eliminado", xbmcgui.NOTIFICATION_INFO
        )
        xbmc.executebuiltin("Container.Refresh")


def history_remove(url):
    if not url:
        return
    _remove_from_history(url)
    xbmc.executebuiltin("Container.Refresh")


def history_clear():
    if xbmcgui.Dialog().yesno("EspaDaily", "¿Borrar todo el historial de URLs?"):
        _clear_history()
        xbmc.executebuiltin("Container.Refresh")


def play_url_action(raw_url):
    """Reproduce una URL registrándola en el historial."""
    if not raw_url:
        return
    _add_to_history(raw_url, _friendly_label(raw_url))
    _resolve_and_play(raw_url)


# StreamNinja — instalación y apertura

def _sn_download_and_install_repo(dp):
    """Descarga el repositorio de StreamNinja, lo extrae e inicia la instalación."""
    import zipfile as _zf
    import requests as _req
    import json as _json

    zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "sn_repo.zip")
    try:
        r = _req.get(_SN_ZIP, stream=True, timeout=30)
        if r.status_code != 200:
            raise IOError("Error HTTP {0} al descargar el repositorio.".format(r.status_code))

        total_size = int(r.headers.get("content-length", 0))
        downloaded = 0
        content = bytearray()
        for chunk in r.iter_content(chunk_size=65536):
            if dp.iscanceled():
                raise InterruptedError("Cancelado por el usuario.")
            if chunk:
                content.extend(chunk)
                downloaded += len(chunk)
                if total_size > 0:
                    dp.update(10 + int((downloaded * 80) / total_size), "Descargando repositorio...")

        raw_b = bytes(content)
        if not raw_b.startswith(b"PK\x03\x04"):
            raise ValueError("El archivo descargado no es un ZIP válido.")

        dp.update(90, "Extrayendo...")
        with open(zip_path, "wb") as f:
            f.write(raw_b)

        dp.update(92, "Instalando en Kodi (VFS)...")
        with _zf.ZipFile(zip_path, "r") as zf:
            for member in zf.infolist():
                if member.is_dir():
                    continue
                vfs_dest = "special://home/addons/{0}".format(member.filename)
                parent_dir = "special://home/addons/" + "/".join(member.filename.split("/")[:-1])
                if not xbmcvfs.exists(parent_dir):
                    xbmcvfs.mkdirs(parent_dir)
                data = zf.read(member)
                v_file = xbmcvfs.File(vfs_dest, "wb")
                success = v_file.write(data)
                v_file.close()
                if success is False and len(data) > 0:
                    raise IOError("VFS devolvió False al escribir {0}".format(vfs_dest))

        dp.update(95, "Actualizando sistema de addons...")
        xbmc.executebuiltin("UpdateLocalAddons()")
        monitor = xbmc.Monitor()
        monitor.waitForAbort(2.0)

        dp.update(97, "Habilitando repositorio...")
        rpc_payload = _json.dumps({
            "jsonrpc": "2.0", "method": "Addons.SetAddonEnabled",
            "params": {"addonid": _SN_REPO, "enabled": True}, "id": 1
        })
        for _ in range(5):
            response = xbmc.executeJSONRPC(rpc_payload)
            if '"error"' not in response:
                break
            monitor.waitForAbort(1.0)

        monitor.waitForAbort(1.5)
        dp.update(99, "Solicitando instalación del addon...")
        xbmc.executebuiltin("InstallAddon({0})".format(_SN_ID))

        installed = False
        for _ in range(6):
            if monitor.waitForAbort(0.5):
                break
            if xbmc.getCondVisibility("System.HasAddon({0})".format(_SN_ID)):
                installed = True
                break

        dp.close()
        if installed:
            xbmcgui.Dialog().ok("EspaDaily", "StreamNinja se ha instalado con éxito.\n\nVuelve a pulsar para reproducir.")
        else:
            xbmcgui.Dialog().ok(
                "EspaDaily - Instalación Pendiente",
                "El repositorio se ha instalado correctamente.\n\n"
                "Acepta cualquier ventana emergente de Kodi para finalizar.\n\n"
                "Si no aparece nada, instálalo desde:\n"
                "[B]Addons → Instalar desde repositorio → StreamNinja[/B]"
            )
        return True

    except Exception as e:
        dp.close()
        msg = str(e)
        if "Cancelado" in msg:
            xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_WARNING)
        else:
            xbmc.log("[EspaDaily] Error instalando StreamNinja: {0}".format(e), xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Error", "No se pudo instalar StreamNinja:\n{0}".format(e))
        return False
    finally:
        if os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass


def streamninja_open_or_install():
    """Abre StreamNinja si está instalado, o inicia el proceso de instalación."""
    if xbmc.getCondVisibility("System.HasAddon({0})".format(_SN_ID)):
        xbmc.executebuiltin("RunAddon({0})".format(_SN_ID))
        return

    if xbmc.getCondVisibility("System.HasAddon({0})".format(_SN_REPO)):
        if xbmcgui.Dialog().yesno(
            "StreamNinja",
            "Addon no instalado pero tienes su repositorio.\n¿Instalarlo ahora?"
        ):
            xbmc.executebuiltin("InstallAddon({0})".format(_SN_ID))
            xbmcgui.Dialog().ok("EspaDaily", "Se ha solicitado la instalación.\nAcepta las ventanas de Kodi y vuelve a pulsar el botón.")
        return

    if not xbmcgui.Dialog().yesno(
        "Instalar StreamNinja",
        "StreamNinja no está instalado.\n¿Descargar e instalar el repositorio oficial?"
    ):
        return

    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", "Descargando StreamNinja...")
    dp.update(5, "Iniciando descarga...")
    _sn_download_and_install_repo(dp)


def streamninja_check_or_install():
    """Comprueba si StreamNinja está instalado e instala si es necesario.
    Retorna True si está disponible, False si no."""
    if xbmc.getCondVisibility("System.HasAddon({0})".format(_SN_ID)):
        return True

    if xbmc.getCondVisibility("System.HasAddon({0})".format(_SN_REPO)):
        if xbmcgui.Dialog().yesno(
            "StreamNinja Requerido",
            "StreamNinja no está instalado pero tienes su repositorio.\n¿Instalarlo ahora?"
        ):
            xbmc.executebuiltin("InstallAddon({0})".format(_SN_ID))
            xbmcgui.Dialog().ok("EspaDaily", "Se ha solicitado la instalación.\nAcepta las ventanas de Kodi y vuelve a intentarlo.")
        return False

    if not xbmcgui.Dialog().yesno(
        "StreamNinja Requerido",
        "Para abrir este contenido se necesita StreamNinja.\n¿Descargar e instalar automáticamente?"
    ):
        return False

    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", "Preparando instalación de StreamNinja...")
    dp.update(10, "Configurando conexión...")
    _sn_download_and_install_repo(dp)
    return False


def url_player_ensure_streamninja():
    """Llamada exportada para el dispatcher. Abre o instala StreamNinja."""
    streamninja_open_or_install()
