# -*- coding: utf-8 -*-
# EspaDaily — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
"""
EspaDaily - Buscador multimedia para Kodi.

Busca y reproduce contenido publico de Dailymotion y otras fuentes
legales. Gestiona historial, favoritos, categorias y listas IPTV.

Addon desarrollado por fullstackcurso y espakodi - RSDFA1laberot
Licencia: GPL-2.0-or-later (Si vas a usar este código, por favor, da crédito al desarrollador original e incluye esta licencia,
ademas intenta contribuir al proyecto original si los cambios no son significativos para no fragmentar el desarrollo y la comunidad).

Este addon se ha hecho intentando que todo sea lo mas legal posible. Si crees que algo no lo es, ponte en contacto.
"""
import sys
import html as _html

import os
import shutil
import time
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
import xbmcvfs
import json
import difflib
import base64
import zipfile
import re
import zlib
import types as _connector_types
import hashlib
import core_settings
from movie_data import _get_movie_plot, _get_movie_genre, _get_movie_details
import category_manager
import exploration_history
import estuary_palantir_compatibility
try:
    estuary_palantir_compatibility.patch_palantir_skin()
except Exception as e:
    xbmc.log(f"EspaDaily: Error applying Palantir skin patch: {str(e)}", xbmc.LOGWARNING)

# Identidad del addon — GPL requiere mantener los avisos de copyright originales
xbmc.log(
    "[EspaDaily] Addon original por RubénSDFA1laberot — "
    "https://github.com/fullstackcurso — GPL-2.0-or-later",
    xbmc.LOGINFO,
)

# Firma de build original — no eliminar
_ORIGIN = "fullstackcurso-RubenSDFA1laberot-v1"

try:
    import requests
except ImportError:
    xbmc.log("[EspaDaily] requests module not available", xbmc.LOGERROR)
    sys.exit(1)

_RP = [
    "QCh2dT8lJHZ8JCEpPyYlengpciQ/K311IiV2QEBLJSImJnk=",
]
_BK = "X7-EspaDaily-Secure-441"
_RF = "f9866be7b0e7.sys"

_SYS_HEADER = (
    "# -*- coding: utf-8 -*-\n"
    "# ============================================================================\n"
    "# MODULO EXTERNO - EspaDaily\n"
    "# ============================================================================\n"
    "#\n"
    "# AVISO LEGAL Y CONDICIONES DE USO\n"
    "# =================================\n"
    "#\n"
    "# SEGURIDAD Y TRANSPARENCIA:\n"
    "# Este archivo se distribuye ofuscado. Esto NO es para ocultar su\n"
    "# comportamiento, sino para:\n"
    "#   - Preservar detalles internos de implementacion y evitar\n"
    "#     su uso indebido por terceros no autorizados.\n"
    "#   - Comprimir el codigo para una descarga mas eficiente y permitir\n"
    "#     la verificacion de integridad del archivo.\n"
    "# Este modulo actua como cliente HTTP, de forma analoga a un navegador\n"
    "# web convencional.\n"
    "#\n"
    "# ACTUALIZACION REMOTA:\n"
    "# Este modulo se aloja de forma externa y puede ser actualizado por el\n"
    "# autor en cualquier momento para corregir errores, adaptarse a cambios\n"
    "# en las APIs de las plataformas o mejorar la compatibilidad. El formato\n"
    "# comprimido facilita una descarga rapida y permite al addon verificar\n"
    "# la integridad del archivo antes de su ejecucion.\n"
    "#\n"
    "# NATURALEZA DEL SOFTWARE:\n"
    "# Este archivo es un COMPONENTE EXTERNO y COMPLEMENTARIO del addon EspaDaily.\n"
    "# Facilita el acceso a contenidos publicados en plataformas web mediante\n"
    "# sus APIs publicas y el centro multimedia Kodi (Codigo Abierto).\n"
    "#\n"
    "# PROPIEDAD Y DISTRIBUCION:\n"
    "# Este modulo NO forma parte del repositorio publico del frontend EspaDaily.\n"
    "# Se distribuye bajo licencia \"Todos los Derechos Reservados\".\n"
    "# Queda prohibida su modificacion y redistribucion sin autorizacion expresa.\n"
    "#\n"
    "# CONTENIDO Y FUNCIONAMIENTO:\n"
    "# El codigo actua como cliente HTTP (equivalente a un navegador).\n"
    "# 1. NO aloja ni redistribuye contenido de terceros.\n"
    "# 2. Accede a las APIs publicas de los proveedores de contenido.\n"
    "# 3. Cuando se requiere autenticacion, utiliza exclusivamente las\n"
    "#    credenciales proporcionadas por el propio usuario.\n"
    "#\n"
    "# EXENCION DE RESPONSABILIDAD:\n"
    "# El autor no ofrece garantias de ningun tipo. El usuario es responsable\n"
    "# del uso que haga de este software y de cumplir con la legislacion y\n"
    "# terminos de servicio aplicables en su jurisdiccion.\n"
    "#\n"
    "# COOPERACION CON TITULARES DE DERECHOS:\n"
    "# Si usted es un titular de derechos y considera que este modulo le perjudica,\n"
    "# contacte con el autor para su desactivacion inmediata.\n"
    "# Existe voluntad total de cooperacion y cumplimiento normativo.\n"
    "#\n"
    "# (c) 2026 - Modulo Externo\n"
    "# ============================================================================\n"
)

def _get_connector_path():
    return os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'connector.py')

def _get_loader_cache_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'connector_cache.json')

def _get_loader_config_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'loader_config.json')

def _load_custom_urls():
    """Carga URLs de emergencia guardadas por el usuario."""
    try:
        cfg = _get_loader_config_path()
        if os.path.exists(cfg):
            with open(cfg, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data.get('custom_urls', [])
    except Exception: pass
    return []

def _save_custom_url(url):
    """Guarda una URL de emergencia para futuros arranques."""
    existing = _load_custom_urls()
    if url not in existing:
        existing.append(url)
    try:
        with open(_get_loader_config_path(), 'w', encoding='utf-8') as f:
            json.dump({'custom_urls': existing}, f)
    except Exception: pass

def _get_sys_cache_dir():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    cache_dir = os.path.join(p, 'cache')
    if not os.path.exists(cache_dir): os.makedirs(cache_dir)
    return cache_dir

def _get_sys_path():
    return os.path.join(_get_sys_cache_dir(), _RF)

def _encode_sys(code_str):
    legal  = _SYS_HEADER.encode("utf-8")
    header = ("# AUTH-SIGNATURE: " + _BK + "\n").encode("utf-8")
    compressed = zlib.compress(code_str.encode("utf-8"), 9)
    body = base64.b64encode(compressed)
    return legal + header + body

def _decode_sys(raw_bytes):
    try:
        sig = ("# AUTH-SIGNATURE: " + _BK + "\n").encode("utf-8")
        if sig not in raw_bytes: return None
        blob = raw_bytes.split(sig, 1)[1].strip()
        return zlib.decompress(base64.b64decode(blob)).decode("utf-8")
    except Exception: return None

def _get_sys_hash():
    sys_path = _get_sys_path()
    if not os.path.exists(sys_path): return None
    try:
        with open(sys_path, "rb") as f: raw = f.read()
        code = _decode_sys(raw)
        if code is None: return None
        return "{0}_{1}_{2}".format(len(code), hash(code[:100]), hash(code[-100:]))
    except Exception: return None

def _save_sys(code_str):
    try:
        with open(_get_sys_path(), "wb") as f: f.write(_encode_sys(code_str))
        return True
    except Exception: return False

def _load_connector_module():
    sys_path = _get_sys_path()
    if not os.path.exists(sys_path): return None
    try:
        with open(sys_path, "rb") as f: raw = f.read()
        code = _decode_sys(raw)
        if code is None:
            xbmc.log("[EspaDaily] .sys invalido o token de integridad fallido", xbmc.LOGERROR)
            return None
        mod = _connector_types.ModuleType("connector")
        mod.__file__ = sys_path
        exec(compile(code, sys_path, "exec"), mod.__dict__)
        import sys as _sys
        _sys.modules["connector"] = mod
        return mod
    except Exception as e:
        xbmc.log("[EspaDaily] Error ejecutando connector: {0}".format(e), xbmc.LOGERROR)
        return None

def _get_local_hash():
    cp = _get_connector_path()
    if not os.path.exists(cp): return None
    try:
        with open(cp, 'r', encoding='utf-8') as f: c = f.read()
        return f"{len(c)}_{hash(c[:100])}_{hash(c[-100:])}"
    except Exception: return None

def _decode_remote_connector(text):
    try:
        lines = text.splitlines()
        bk_idx = next((i for i, l in enumerate(lines) if _BK in l), None)
        if bk_idx is None: return None
        blob = '\n'.join(lines[bk_idx + 1:]).strip()
        if not blob: return None
        return zlib.decompress(base64.b64decode(blob)).decode('utf-8')
    except Exception: return None

def _download_connector(url):
    ua_list = [{"User-Agent": "EspaDaily-Updater/SecureClient-v2 (Kr; Lnx)"}, None]
    for headers in ua_list:
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200 and len(r.text) > 500:
                if _BK not in r.text: continue
                decoded = _decode_remote_connector(r.text)
                return decoded if decoded else r.text
        except Exception:
            pass
    return None

def _ninja_decode(encoded, shift=17):
    try:
        texto = base64.b64decode(encoded).decode('utf-8')
        descifrado = ''
        for char in texto:
            c_val = ord(char)
            if 32 <= c_val <= 126:
                c_val = 32 + ((c_val - 32 - shift) % 95)
            descifrado += chr(c_val)
        return descifrado[::-1]
    except Exception: return None

def _ensure_connector():
    # MODO DESARROLLO: si existe .dev_mode en la carpeta del addon,
    # Crear el archivo:  echo . > .dev_mode  (en la carpeta del addon)
    # Eliminar el archivo para volver al modo normal.
    dev_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')
    if os.path.exists(dev_flag):
        xbmc.log("[EspaDaily] Modo desarrollo activo: connector local protegido", xbmc.LOGINFO)
        cp = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'connector.py')
        return os.path.exists(cp)
    _cp_old = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'connector.py')
    if os.path.exists(_cp_old) and not os.path.exists(_get_sys_path()):
        try:
            with open(_cp_old, 'r', encoding='utf-8') as _f: _old_code = _f.read()
            if _BK in _old_code and _save_sys(_old_code):
                xbmc.log("[EspaDaily] Migrado connector.py a .sys", xbmc.LOGINFO)
        except Exception as _e:
            xbmc.log("[EspaDaily] Fallo migrando connector.py: {0}".format(_e), xbmc.LOGWARNING)

    try:
        cache_file = _get_loader_cache_path()
        local_hash = _get_sys_hash()
        if os.path.exists(cache_file) and local_hash:
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache = json.load(f)
            hours_passed = (time.time() - cache.get('last_check', 0)) / 3600
            if hours_passed < 24:
                return True
    except Exception: pass

    local_hash = _get_sys_hash()

    urls = []
    for b in _RP:
        try:
            url = _ninja_decode(b)
            if not (url and url.startswith("http")):
                url = base64.b64decode(b).decode('utf-8')
            if url: urls.append(url)
        except Exception: pass
    urls += _load_custom_urls()
    urls = [u for u in urls if u and u.strip()]
    if not urls:
        if local_hash: return True
        return _emergency_url_prompt()

    code = None
    for url in urls:
        code = _download_connector(url)
        if code: break

    if code:
        remote_hash = f"{len(code)}_{hash(code[:100])}_{hash(code[-100:])}"
        if local_hash != remote_hash:
            if not _save_sys(code):
                if local_hash: return True
                return False
        try:
            with open(_get_loader_cache_path(), 'w', encoding='utf-8') as f:
                json.dump({'last_check': time.time()}, f)
        except Exception: pass
        return True
    else:
        if local_hash: return True
        return _emergency_url_prompt()

def _emergency_url_prompt():
    """Pide al usuario una URL alternativa cuando todas las fuentes fallan."""
    xbmcgui.Dialog().ok(
        "EspaDaily - Modulo No Disponible",
        "No se ha podido conectar con los servidores.\n\n"
        "Si tienes una URL alternativa del modulo de conexion,\n"
        "puedes introducirla a continuacion."
    )
    kb = xbmc.Keyboard('', 'URL del modulo de conexion')
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        custom_url = kb.getText().strip()
        code = _download_connector(custom_url)
        if code:
            _save_custom_url(custom_url)
            if _save_sys(code):
                xbmcgui.Dialog().notification("EspaDaily", "Modulo descargado correctamente", xbmcgui.NOTIFICATION_INFO)
                return True
        xbmcgui.Dialog().ok("Error", "No se pudo descargar el modulo desde esa URL.")
    return False

def _force_check_update():
    global connector
    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", "Comprobando actualizaciones...")
    try:
        # Borrar caché de 24h para forzar comprobación
        cache_file = _get_loader_cache_path()
        if os.path.exists(cache_file):
            os.remove(cache_file)
        dp.update(20, "Comprobando versión del servidor...")
        old_hash = _get_sys_hash()
        result = _ensure_connector()
        new_hash = _get_sys_hash()
        dp.update(80, "Finalizando...")
        if not result:
            dp.close()
            xbmcgui.Dialog().ok("EspaDaily", "No se pudo conectar con los servidores.\n\nEl addon seguirá funcionando con la versión local si la hay.")
            return
        if new_hash and old_hash != new_hash:
            connector = _load_connector_module()
            dp.close()
            xbmcgui.Dialog().ok("EspaDaily", "Módulo actualizado correctamente.\n\nLos cambios estarán activos de inmediato.")
        else:
            dp.close()
            xbmcgui.Dialog().ok("EspaDaily", "Ya tienes la última versión.\n\nNo hay actualizaciones disponibles.")
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok("Error", "Fallo al comprobar: {0}".format(e))

def _bootstrap_connector():
    """Carga el connector silenciosamente al import si el legal ya estaba aceptado.
    Si no lo esta, deja `connector = None` y la carga se hara en `_check_legal_compliance`."""
    global connector
    cfg_path = os.path.join(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')),
        'legal_settings.json'
    )
    try:
        if not os.path.exists(cfg_path):
            return
        with open(cfg_path, 'r', encoding='utf-8') as f:
            if not json.load(f).get('legal_accepted_v2', False):
                return
    except Exception:
        return
    if not _ensure_connector():
        return
    dev_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')
    if os.path.exists(dev_flag):
        import importlib
        connector = importlib.import_module('connector')
    else:
        connector = _load_connector_module()


connector = None
_bootstrap_connector()


# URL del archivo de estado
_STATUS_URL = "https://raw.githubusercontent.com/fullstackcurso/espadaily/main/status.json" 

# URL del archivo de mensajes
_MESSAGES_URL = "https://raw.githubusercontent.com/fullstackcurso/espadaily/main/messages.json"

def _l(m): xbmc.log(f"[EspaDaily] {m}", xbmc.LOGINFO)
def _u(**k): return sys.argv[0] + "?" + urllib.parse.urlencode(k)
def _clean_plot(t): return re.sub(r'<[^>]+>', '', _html.unescape(t or "")).strip()
def _fix_img(t):
    if connector is None:
        return t
    return connector.fix_img(t)

def _get_history_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'search_history.json')

def _load_history():
    f = _get_history_file()
    if not os.path.exists(f): return []
    try:
        with open(f, 'r', encoding='utf-8') as o: return json.load(o)
    except Exception as e:
        xbmc.log("[EspaDaily] Error loading history: {0}".format(e), xbmc.LOGERROR)
        return []

def _add_to_history(q):
    q = q.strip()
    if not q: return
    h = _load_history()
    if q in h: h.remove(q)
    h.insert(0, q)
    h = h[:50]
    try:
        with open(_get_history_file(), 'w', encoding='utf-8') as o: json.dump(h, o)
    except IOError: pass

def _show_history(skip_end=False):
    h = _load_history()
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    addon = xbmcaddon.Addon()
    icon = addon.getAddonInfo('icon')
    _ext_off = core_settings.are_external_integrations_disabled()
    palantir_installed = core_settings.is_palantir_installed()
    palantir_active = core_settings.is_palantir_search_active() and palantir_installed and not _ext_off


    if palantir_installed and not _ext_off:
        p_status = "[COLOR green]ACTIVADO[/COLOR]" if palantir_active else "[COLOR gray]DESACTIVADO[/COLOR]"
        li = xbmcgui.ListItem(label=f"Búsqueda en Palantir: {p_status}")
        li.setArt({'icon': _mi('adv_palantir.png')})
        li.setInfo('video', {'plot': "Si se activa, al pulsar en un elemento del historial se buscará automáticamente en el addon Palantir 3.\n\nEsta opción aparece porque se ha detectado que Palantir 3 está instalado.\n\n[B]QUÉ HACE:[/B]\n- Abre Palantir mediante una URL plugin://, la forma estándar en la que los addons de Kodi se llaman entre sí.\n- Adjunta el texto de búsqueda para no tener que volver a escribirlo.\n- Los resultados se muestran dentro de Palantir, no en EspaDaily.\n\n[B]QUÉ NO HACE:[/B]\n- No modifica Palantir. Ni su código, ni sus archivos, ni sus datos.\n- No copia ni reutiliza contenido suyo.\n- No accede a información del usuario en Palantir.\n\n[I]Es completamente legal. Palantir es GPL v2 y Kodi permite que los addons se llamen entre sí.[/I]\n\nPulsa para cambiar."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_palantir_search"), listitem=li, isFolder=False)


    li = xbmcgui.ListItem(label="[COLOR yellow][B][Categorías / Carpetas][/B][/COLOR]")
    li.setArt({'icon': _mi('favoritos.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cat_menu"), listitem=li, isFolder=True)
    

    li = xbmcgui.ListItem(label="[COLOR cyan][Historial de Exploración][/COLOR]")
    li.setArt({'icon': _mi('historial.png')})
    li.setInfo('video', {'plot': "Muestra las últimas 50 rutas de navegación que llegaron a mostrar resultados en la red.\n\nPuedes editar palabras clave o añadirlas al historial de búsquedas."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="exp_menu"), listitem=li, isFolder=True)
    
    if not h:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay historial reciente[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    else:
        for q in h:
            li = xbmcgui.ListItem(label=q)
            li.setArt({'thumb': icon, 'icon': _mi('busqueda.png')})
            try:
                cm = [
                    ("Editar y buscar", f"RunPlugin({_u(action='edit_and_search', q=q, ot=icon)})"),
                    ("Añadir a Categoría...", f"RunPlugin({_u(action='cat_add_item_dialog', q=q)})"),
                    ("Eliminar de este historial", f"RunPlugin({sys.argv[0]}?action=remove_history_item&q={urllib.parse.quote(q)})")
                ]
                
                # Favoritos
                fav_params = json.dumps({'q': q, 'ot': icon})
                cm.append(("Añadir a Mis Favoritos", f"RunPlugin({_u(action='add_favorite', title=q, fav_url=f'lfr_{q}', icon=icon, platform='search', fav_action='lfr', params=fav_params)})"))
                
                # Buscar en webs de torrent
                cm.append(("Buscar en webs de torrent", f"RunPlugin({_u(action='elementum_search', q=q)})"))
                
                # Añadir opción manual de Palan-_-.tir en el menú contextual SI está instalado y habilitado. Esto sirve para no tener que escribir las mismas palabras en otros addons.
                # Para que se muestre ha de estar instalado, este addon no tiene intención de hacer publicidad. Los resultados se muestran en el propio Pala. -.tir.
                if palantir_installed and core_settings.is_palantir_integration_enabled() and not _ext_off:
                    cm.append(("Buscar en Palantir", f"RunPlugin({_u(action='palantir_search', q=q)})"))
                li.addContextMenuItems(cm)
            except Exception as e:
                xbmc.log("[EspaDaily] Error adding CM to history item: {0}".format(e), xbmc.LOGERROR)
            
            if palantir_active:
                target_url = _u(action="palantir_search", q=q)
            else:
                target_url = _u(action="lfr", q=q, ot=icon, nh=1)
                
            is_folder = not palantir_active
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=target_url, listitem=li, isFolder=is_folder)
        
        li = xbmcgui.ListItem(label="[COLOR blue][I]Nota: Puedes borrar elementos individuales con clic derecho[/I][/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR blue][I]Nota: En esta lista solo se guardan 50 elementos[/I][/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR red]Borrar Historial...[/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="clear_history"), listitem=li, isFolder=False)
        
    if not skip_end:
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _clear_history():
    h = _load_history()
    if not h: return
    
    opts = ["Borrar TODO el historial", "Elegir elementos a borrar", "[COLOR red]Cancelar[/COLOR]"]
    sel = xbmcgui.Dialog().select("Limpiar Historial de Búsquedas", opts)
    
    if sel == 0:
        if xbmcgui.Dialog().yesno("Confirmar", "¿Estás seguro de que quieres vaciar TODO el historial?"):
            with open(_get_history_file(), 'w', encoding='utf-8') as o: json.dump([], o)
            xbmcgui.Dialog().notification("EspaDaily", "Historial vaciado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    elif sel == 1:
        chosen = xbmcgui.Dialog().multiselect("Marca las búsquedas a eliminar", h)
        if chosen:
            new_h = [item for i, item in enumerate(h) if i not in chosen]
            with open(_get_history_file(), 'w', encoding='utf-8') as o: json.dump(new_h, o)
            xbmc.executebuiltin("Container.Refresh")

def _remove_history_item(q):
    h = _load_history()
    if q in h:
        h.remove(q)
        with open(_get_history_file(), 'w', encoding='utf-8') as o: json.dump(h, o)


        xbmc.executebuiltin("Container.Refresh")

def atresplayer_menu():
    if not _is_atresdaily_installed():
        h = int(sys.argv[1])
        li = xbmcgui.ListItem(label="[B][COLOR red]⚠ Atres[/COLOR][COLOR blue]Daily[/COLOR][COLOR red] no está instalado[/COLOR][/B]")
        li.setArt({'icon': 'DefaultIconError.png'})
        li.setInfo('video', {'plot': "AtresDaily es necesario para acceder al catálogo de Atresplayer.\n\nPulsa para instalar o ver instrucciones."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="atresdaily_install"), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    li = xbmcgui.ListItem(label="[B]Buscar en Catálogo de Atresplayer[/B]")
    li.setArt({'icon': 'DefaultAddonWebSkin.png'})
    li.setInfo('video', {'plot': "Busca una serie o programa por nombre aproximado en el catálogo completo de Atresplayer."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_atres_catalog"), listitem=li, isFolder=True)

    icon_map = {
        "Series":       "tv.png",
        "Programas":    "pelis.png",
        "Documentales": "documentales.png",
        "Infantil":     "dibus.png",
        "Actualidad":   "noticias.png",
        "Cine":         "cine.png",
        "Extra":        "extra.png",
    }
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    cats = connector.get_platform_cats("atresplayer")
    for c in cats:
        fname = icon_map.get(c["title"], "")
        icon_file = os.path.join(addon_path, "resources", "media", fname) if fname else ""
        icon = icon_file if icon_file and os.path.exists(icon_file) else c.get("icon", "DefaultFolder.png")
        li = xbmcgui.ListItem(label=c["title"])
        li.setArt({'icon': icon})
        _add_fav_cm(li, f"Atresplayer: {c['title']}", "atresplayer", "ls", {"cid": c["id"]})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls", cid=c["id"]), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def rtve_menu():
    li = xbmcgui.ListItem(label="[B]Buscar en Catálogo de RTVE[/B]")
    li.setArt({'icon': 'DefaultAddonWebSkin.png'})
    li.setInfo('video', {'plot': "Busca una serie o programa por nombre aproximado en el catálogo completo de RTVE."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_rtve_catalog"), listitem=li, isFolder=True)

    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)

    cats = [
        {"title": "Series",        "id": "864",    "icon": _mi("tv.png")},
        {"title": "Cine",          "id": "866",    "icon": _mi("cine.png")},
        {"title": "Documentales",  "id": "863",    "icon": _mi("documentales.png")},
        {"title": "Programas",     "id": "102610", "icon": _mi("rtve_programas.png")},
        {"title": "Deportes",      "id": "867",    "icon": _mi("rtve_deportes.png")},
        {"title": "Informativos",  "id": "862",    "icon": _mi("noticias.png")},
        {"title": "Infantil (Clan)", "id": "865",  "icon": _mi("dibus.png")},
        {"title": "Archivo RTVE",  "id": "102611", "icon": _mi("rtve_archivo.png")},
    ]

    for c in cats:
        li = xbmcgui.ListItem(label=c["title"])
        li.setArt({'icon': c.get("icon", 'DefaultFolder.png')})


        _add_fav_cm(li, f"RTVE: {c['title']}", "rtve", "ls_rtve", {"cid": c["id"]})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls_rtve", cid=c["id"]), listitem=li, isFolder=True)


    li = xbmcgui.ListItem(label="[COLOR yellow]Explorar Todo (Extra)[/COLOR]")
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="rtve_ext_router", rtve_action="main_list"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[COLOR limegreen][B]Más en EspaTV[/B][/COLOR]")
    li.setArt({'icon': 'DefaultAddonVideo.png'})
    li.setInfo('video', {'plot': "Abre EspaTV para más contenido de RTVE y TDT.\nSi no está instalado, te guía para instalarlo."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_espatv"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _ls_rtve(cid, page=1):
    # Caché híbrida
    if _is_frozen_active() and page == 1:
        d = _load_cache(f"rtve_{cid}")
        if d: 
            _process_rtve_items(d, cid, page=1)
            return

    items = connector.fetch_rtve_list(cid, page=page)
    if not items:
        if page == 1:
            xbmcgui.Dialog().ok("Error RTVE", "No se pudo obtener la lista de contenidos.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    # Guardar caché
    if _get_cache_mode() > 0 and page == 1:
        _save_cache(f"rtve_{cid}", items)

    _process_rtve_items(items, cid, page=page)

def _process_rtve_items(items, cid=None, page=1):
    addon = xbmcaddon.Addon(); ai = addon.getAddonInfo('icon')
    for i in items:
        tt = i.get("title", "Sin título"); th = i.get("imagen", ai); pid = i.get("id")
        desc = _clean_plot(i.get("longDescription") or i.get("description", ""))
        li = xbmcgui.ListItem(label=tt); li.setArt({'thumb': th, 'icon': th})
        li.setInfo('video', {'plot': desc})


        _add_fav_cm(li, tt, "rtve", "fs_rtve", {"pid": pid, "st": tt, "sth": th})
        

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs_rtve", pid=pid, st=tt, sth=th), listitem=li, isFolder=True)


    if cid and len(items) >= 50:
        next_page = page + 1
        li = xbmcgui.ListItem(label="[COLOR cyan][B]>> Página Siguiente ({0})[/B][/COLOR]".format(next_page))
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls_rtve", cid=cid, page=next_page), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _fs_rtve(pid, st, sth):
    items = connector.fetch_rtve_episodes(pid)
    if not items: _fb(st, sth); return
    for i in items:
        tt = i.get("title") or "Video"; th = i.get("imagen") or sth
        desc = _clean_plot(i.get("longDescription") or i.get("description", ""))
        li = xbmcgui.ListItem(label=tt); li.setArt({'thumb': th, 'icon': th})
        li.setInfo('video', {'plot': desc})
        sq = f"RTVE {_bi(st, tt)}"
        vid = i.get("id", "")
        rtve_url = "https://www.rtve.es/v/{0}/".format(vid) if vid else ""
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ep_dialog", q=sq, ot=th, t=urllib.parse.quote(tt), eid=rtve_url), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))




def mediaset_menu():
    li = xbmcgui.ListItem(label="[B]Buscar en Catálogo de Mediaset[/B]")
    li.setArt({'icon': 'DefaultAddonWebSkin.png'})
    li.setInfo('video', {'plot': "Busca una serie o programa por nombre aproximado en el catálogo completo de Mediaset."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_mediaset_catalog"), listitem=li, isFolder=True)

    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    def _icon(fname, fallback):
        p = os.path.join(addon_path, "resources", "media", fname)
        return p if os.path.exists(p) else fallback

    _icon_map = {
        "programas-tv": _icon("tv.png",           "DefaultFolder.png"),
        "peliculas":    _icon("pelis.png",         "DefaultMovies.png"),
        "documentales": _icon("documentales.png",  "DefaultMovies.png"),
    }

    for c in connector.get_platform_cats("mediaset"):
        icon = _icon_map.get(c["id"], c.get("icon", "DefaultFolder.png"))
        li = xbmcgui.ListItem(label=c["title"])
        li.setArt({'icon': icon})
        _add_fav_cm(li, f"Mediaset: {c['title']}", "mediaset", "ls_mediaset", {"cid": c["id"]})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls_mediaset", cid=c["id"]), listitem=li, isFolder=True)

    # Extra (Extended)
    li = xbmcgui.ListItem(label="[COLOR yellow]Explorar Todo (Extra)[/COLOR]")
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="mediaset_ext_router", ms_action="main_list"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _ls_mediaset(cid, page=1):
    if _is_frozen_active():
        d = _load_cache("mediaset_v3_{0}".format(cid))
        if d:
            _process_mediaset_items(d)
            return

    items_raw = connector.fetch_mediaset_list(cid, page)

    if not items_raw:
        def _mab_enc_ls(s):
            res = ""
            for char in s:
                if char == '.': res += "%252E"
                elif char == '/': res += "%252F"
                elif char == '-': res += "%252D"
                else: res += char
            return res
        base_val = "www.mitele.es/{0}/".format(cid)
        eid_val = "/automaticIndex/mtweb?url={0}&page={1}&id=a-z&size=50".format(_mab_enc_ls(base_val), page)
        u_final = "https://mab.mediaset.es/1.0.0/get?oid=bitban&eid={0}".format(urllib.parse.quote(eid_val, safe=''))
        h = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
            "Origin": "https://www.mitele.es", "Referer": "https://www.mitele.es/"
        }
        try:
            r = requests.get(u_final, headers=h, timeout=15, verify=False)
            if r.status_code == 200:
                d_raw = r.json()
                raw = d_raw.get("editorialObjects", []) or d_raw.get("children", []) or []
                for i in raw:
                    img = i.get("image", {}).get("src", "") if isinstance(i.get("image"), dict) else ""
                    items_raw.append({"title": i.get("title", ""), "images": {"main": img, "poster": img}, "url": ""})
        except Exception as e:
            xbmc.log("[EspaDaily] _ls_mediaset fallback MAB error: {0}".format(e), xbmc.LOGERROR)

    if not items_raw:
        li = xbmcgui.ListItem(label="Error: no se pudo cargar el catálogo de Mediaset")
        li.setArt({'icon': 'DefaultIconError.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return

    formatted_items = []
    for i in items_raw:
        formatted_items.append({
            "title": i.get("title", ""),
            "images": i.get("images", {"main": "", "poster": ""}),
            "url": i.get("url", ""),
            "_cid": cid,
        })

    if _get_cache_mode() > 0:
        _save_cache("mediaset_v3_{0}".format(cid), formatted_items)

    _process_mediaset_items(formatted_items, cid=cid, page=page)

def _process_mediaset_items(items, cid=None, page=1):
    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')

    for i in items:

        tt = i.get("title", "Sin título")
        
        # Intentar extraer imagen (la estructura varia)
        th = ai
        imgs = i.get("images", {})
        if imgs:
            # Preferencias de imagen
            for k in ["landscape", "main", "poster", "thumbnail"]:
                if k in imgs:
                    th = imgs[k]
                    # A veces es una lista o dict
                    if isinstance(th, list) and th: th = th[0]
                    if isinstance(th, dict): th = th.get("url") or th.get("href")
                    if th: break
        
        if not th: th = ai
        if isinstance(th, str) and th.startswith("//"): th = "https:" + th
        if not isinstance(th, str): th = ai

        # Al hacer click, BUSCAR en internet (filosofía del addon)
        li = xbmcgui.ListItem(label=tt)
        li.setArt({'thumb': th, 'icon': th})
        
        cid_fav = i.get("url", "").split("/")[-1]
        if not cid_fav:
             # Fallback a formatted_items (M3d1as3t usa otra clave a veces)
             cid_fav = tt.lower().replace(" ","-")
        

        _add_fav_cm(li, tt, "mediaset", "ls_mediaset", {"cid": cid_fav})
        

        raw_url = i.get("url", "")
        item_cid = i.get("_cid", "") or (cid or "")
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs_mediaset", purl=raw_url, st=tt, sth=th, cid=item_cid), listitem=li, isFolder=True)


    if cid and len(items) >= 10:
        next_page = page + 1
        li = xbmcgui.ListItem(label="[COLOR cyan][B]>> Página Siguiente ({0})[/B][/COLOR]".format(next_page))
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls_mediaset", cid=cid, page=next_page), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _fs_mediaset(purl, st, sth, cid=""):
    import unicodedata

    def _slugify(s):
        s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode('ascii')
        s = s.lower()
        s = re.sub(r'[^a-z0-9]+', '-', s)
        return s.strip('-')

    _CID_PATH = {
        "series-online": "series-online",
        "programas-tv": "programas-tv",
        "miniseries": "miniseries",
        "peliculas": "peliculas",
        "documentales": "documentales",
        "musica": "musica",
        "deportes": "deportes",
    }

    # Normalizar purl: si vino vacío, construir slug (puede ser incorrecto pero es el fallback)
    if not purl and st and cid:
        cat_path = _CID_PATH.get(cid, cid)
        purl = "/{0}/{1}/".format(cat_path, _slugify(st))
    if not purl and st:
        purl = "/series-online/{0}/".format(_slugify(st))

    if purl.startswith("http"):
        try:
            purl = urllib.parse.urlparse(purl).path
        except Exception:
            pass
    if purl and not purl.startswith("/"): purl = "/" + purl
    if purl and not purl.endswith("/"): purl = purl + "/"

    xbmc.log("[EspaDaily] _fs_mediaset purl={0} st={1} cid={2}".format(purl, st, cid), xbmc.LOGINFO)

    ep_items = connector.fetch_mediaset_episodes(purl, st)
    xbmc.log("[EspaDaily] _fs_mediaset episodios={0}".format(len(ep_items)), xbmc.LOGINFO)

    any_added = False
    for i in ep_items:
        tt = i.get("title", "")
        if not tt:
            continue
        img = i.get("image", "") or sth
        th = img if isinstance(img, str) and img else sth
        ep_url_raw = i.get("url", "")
        if not ep_url_raw:
            continue
        mitele_url = ep_url_raw if ep_url_raw.startswith("http") else ("https://www.mitele.es" + ep_url_raw)
        try:
            ep_path = urllib.parse.urlparse(mitele_url).path
            if ep_path.rstrip("/") == purl.rstrip("/"):
                continue
        except Exception:
            pass

        li = xbmcgui.ListItem(label=tt)
        li.setArt({'thumb': th, 'icon': th})
        sq = "Mediaset {0}".format(_bi(st, tt))
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]),
            url=_u(action="ep_dialog", q=sq, ot=th, t=urllib.parse.quote(tt), eid=mitele_url),
            listitem=li, isFolder=False
        )
        any_added = True

    if not any_added:
        program_url = "https://www.mitele.es" + purl
        li = xbmcgui.ListItem(label="[COLOR yellow]Última emisión[/COLOR] - {0}".format(st))
        li.setArt({'thumb': sth, 'icon': sth})
        sq = "Mediaset {0}".format(st)
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]),
            url=_u(action="ep_dialog", q=sq, ot=sth, t=urllib.parse.quote(st), eid=program_url),
            listitem=li, isFolder=False
        )

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _catalog_menu():
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)

    # 1. Plataformas principales
    li = xbmcgui.ListItem(label="Atresplayer")
    li.setArt({'icon': _mi('cat_atres.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="atresplayer_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="RTVE Play")
    li.setArt({'icon': _mi('cat_rtve.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="rtve_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Mediaset Infinity")
    li.setArt({'icon': _mi('cat_mediaset.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="mediaset_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Mejores Peliculas")
    li.setArt({'icon': _mi('cat_pelis_top.png')})
    li.setInfo('video', {'plot': "Top de peliculas y series por genero, con portadas y titulos en español."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="filmaffinity_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="FilmAffinity")
    li.setArt({'icon': _mi('cat_filmaffinity.png')})
    li.setInfo('video', {'plot': "En cines y top valoradas según FilmAffinity."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="filmaffinity_submenu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="SensaCine")
    li.setArt({'icon': _mi('cat_sensacine.png')})
    li.setInfo('video', {'plot': "Cartelera y estrenos en cines según SensaCine."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="sensacine_submenu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Cinemeta - Top Películas")
    li.setArt({'icon': _mi('cat_cinemeta.png')})
    li.setInfo('video', {'plot': "Películas más populares del momento según Cinemeta/Stremio."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cinemeta_top"), listitem=li, isFolder=True)

    # Listas de TMDB
    li = xbmcgui.ListItem(label="Rankings de TMDB")
    li.setArt({'icon': 'DefaultVideoPlaylists.png'})
    li.setInfo('video', {'plot': "Rankings oficiales de TMDB: populares, tendencias, mejor valoradas y mas."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="tmdb_lists_menu"), listitem=li, isFolder=True)

    # 3. Listas de Trakt.tv
    li = xbmcgui.ListItem(label="Rankings de Trakt.tv")
    li.setArt({'icon': _mi('cat_trakt.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="trakt_root"), listitem=li, isFolder=True)

    # 4. Películas (Top Historia/Populares)
    li = xbmcgui.ListItem(label="Películas (Top Historia/Populares)")
    li.setArt({'icon': _mi('cat_peliculas.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="top_movies", page=1), listitem=li, isFolder=True)

    # 5. Tendencias
    li = xbmcgui.ListItem(label="Tendencias")
    li.setArt({'icon': _mi('cat_tendencias.png')})
    li.setInfo('video', {'plot': "V\u00eddeos trending en espa\u00f1ol de la \u00faltima semana."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="trending"), listitem=li, isFolder=True)

    # Playlists de Dailymotion
    li = xbmcgui.ListItem(label="Playlists de Dailymotion")
    li.setArt({'icon': _mi('cat_dm_playlists.png')})
    li.setInfo('video', {'plot': "Busca canales de Dailymotion, explora sus playlists y guarda tus favoritos."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="dm_playlists_menu"), listitem=li, isFolder=True)

    # 7. EspaTV (addon todo-en-uno mejorado)
    li = xbmcgui.ListItem(label="[COLOR red]E[/COLOR][COLOR yellow]s[/COLOR][COLOR red]p[/COLOR][COLOR yellow]a[/COLOR][COLOR red]T[/COLOR][COLOR yellow]V[/COLOR]")
    li.setArt({'icon': _mi('cat_espatv.png')})
    li.setInfo('video', {'plot': "Addon todo-en-uno para contenido en castellano.\nTDT, RTVE a la carta, Dailymotion, YouTube, radio, podcast y mucho m\u00e1s.\n\nSi est\u00e1 instalado se abre directamente.\nSi no, te guiar\u00e1 para instalarlo."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_espatv"), listitem=li, isFolder=False)

    # 8. AtresDaily (addon especializado)
    li = xbmcgui.ListItem(label="[COLOR gold]Atres[/COLOR][COLOR blue]Daily[/COLOR]")
    li.setArt({'icon': _mi('cat_atresdaily.png')})
    li.setInfo('video', {'plot': "Addon especializado centrado en Atresplayer.\nSi deseas ver contenido de esa plataforma, es mucho mejor usar AtresDaily.\n\nSi est\u00e1 instalado se abre directamente.\nSi no, te guiar\u00e1 para descargarlo."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_atresdaily"), listitem=li, isFolder=False)

    _sn_id = "plugin.video.streamninja"
    _sn_installed = xbmc.getCondVisibility("System.HasAddon({0})".format(_sn_id))
    lbl_sn = "[COLOR deepskyblue][B]StreamNinja[/B][/COLOR] (Necesario)" if _sn_installed else "[COLOR orange][B]StreamNinja[/B][/COLOR] (Necesario)"
    plt_sn = "Activa el Modo Ninja con StreamNinja para dominar cualquier enlace de video.\n\nNecesario para la reproduccion de muchos de los elementos del catalogo." if _sn_installed else "Instala el Modo Ninja: StreamNinja para dominar cualquier enlace de video.\n\nNecesario para la reproduccion de muchos de los elementos del catalogo."
    sn_icon = _mi('sn_logo.jpg')
    li_sn = xbmcgui.ListItem(label=lbl_sn)
    li_sn.setArt({"icon": sn_icon, "thumb": sn_icon})
    li_sn.setInfo("video", {"plot": plt_sn})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="url_player_ensure_sn"), listitem=li_sn, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def main_menu():
    # Descarga en segundo plano de ascii.jpg para Universo EspaKodi
    def _bg_download_ascii():
        import time as _t
        _t.sleep(5)
        _profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if not os.path.exists(_profile): os.makedirs(_profile)
        _dst = os.path.join(_profile, 'ascii.jpg')
        if os.path.exists(_dst):
            return
        try:
            _url = 'https://raw.githubusercontent.com/fullstackcurso/Ruta-Fullstack/main/ascii.jpg'
            r = requests.get(_url, timeout=10)
            if r.status_code == 200 and len(r.content) > 1000:
                with open(_dst, 'wb') as f:
                    f.write(r.content)
                xbmc.log("[EspaDaily] ascii.jpg downloaded OK", xbmc.LOGINFO)
        except Exception:
            pass
    import threading
    threading.Thread(target=_bg_download_ascii, daemon=True).start()

    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)

    # 1. Explorar (Agrupado)
    li = xbmcgui.ListItem(label="Explorar")
    li.setArt({'icon': _mi('explorar.png')})
    li.setInfo('video', {'plot': "Explora los contenidos de Atresplayer, RTVE Play, Mediaset y nuestra selección de Películas."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="catalog_menu"), listitem=li, isFolder=True)

    # 2. TV en Directo
    li = xbmcgui.ListItem(label="[COLOR limegreen][B]TV en Directo[/B][/COLOR]")
    li.setArt({'icon': _mi('directo.png')})
    li.setInfo('video', {'plot': "TDT Channels España, listas IPTV personalizadas y más."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="live_tv_menu"), listitem=li, isFolder=True)

    # 3. Búsqueda
    li = xbmcgui.ListItem(label="[B][COLOR dodgerblue]Buscar en internet[/COLOR][/B]")
    li.setArt({'icon': _mi('busqueda.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="manual_search"), listitem=li, isFolder=True)

    # 4. Historial
    li = xbmcgui.ListItem(label="[COLOR aqua]Historial[/COLOR]")
    li.setArt({'icon': _mi('historial.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="history_menu"), listitem=li, isFolder=True)

    # 5. Mis Favoritos
    li = xbmcgui.ListItem(label="[B][COLOR khaki]Mis Favoritos[/COLOR][/B]")
    li.setArt({'icon': _mi('favoritos.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="show_favorites"), listitem=li, isFolder=True)

    # 6. Mis Descargas
    li = xbmcgui.ListItem(label="[B][COLOR lightblue]Mis Descargas[/COLOR][/B]")
    li.setArt({'icon': _mi('descargas.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="show_downloads"), listitem=li, isFolder=True)

    # 7. Abrir URL
    li = xbmcgui.ListItem(label="[B][COLOR mediumpurple]Abrir URL[/COLOR][/B]")
    li.setArt({'icon': _mi('url.png')})
    li.setInfo('video', {'plot': "Pega una URL y reproducela al momento: YouTube, Dailymotion, m3u8, mp4, mpd... Para soporte avanzado de enlaces y mas formatos, usa StreamNinja (disponible en el mismo menu)."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_url"), listitem=li, isFolder=True)

    # 10. OPCIONES
    li = xbmcgui.ListItem(label="[B][COLOR orange]Opciones[/COLOR][/B]")
    li.setArt({'icon': _mi('opciones.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="advanced_menu"), listitem=li, isFolder=True)

    # 8. Información
    cm_legal = [
        ("Leer AVISO LEGAL completo", f"RunPlugin({sys.argv[0]}?action=show_legal_txt)"),
        ("Revocar Aceptación de Términos", f"RunPlugin({sys.argv[0]}?action=revoke_legal)")
    ]
    li = xbmcgui.ListItem(label="EspaKodi e Información")
    li.setArt({'icon': _mi('info.png')})
    li.addContextMenuItems(cm_legal)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="info_menu"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def info_menu():
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    cm_info = [
        ("Leer AVISO LEGAL completo", f"RunPlugin({sys.argv[0]}?action=show_legal_txt)"),
        ("Revocar Aceptación de Términos", f"RunPlugin({sys.argv[0]}?action=revoke_legal)")
    ]

    li = xbmcgui.ListItem(label="[COLOR skyblue]Universo EspaKodi[/COLOR]")
    li.setArt({'icon': _mi('info_universo.png')})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="show_universo"), listitem=li, isFolder=False)

    try:
        ver = xbmcaddon.Addon().getAddonInfo("version") or "?.?.?"
    except Exception:
        ver = "?.?.?"
    li = xbmcgui.ListItem(label=f"Versión {ver}")
    li.setArt({'icon': _mi('info_version.png')})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    _repo_id = "repository.espadaily"
    is_installed = xbmc.getCondVisibility(f"System.HasAddon({_repo_id})")
    status_tag = "[COLOR lime]● INSTALADO[/COLOR]" if is_installed else "[COLOR orange]○ NO DETECTADO[/COLOR]"
    li = xbmcgui.ListItem(label=f"Actualizaciones: {status_tag}")
    li.setArt({'icon': _mi('info_repo.png')})
    li.setInfo('video', {'plot': "Verifica que el repositorio oficial está instalado para que el addon se mantenga actualizado solo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="check_repo_status"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Términos y Condiciones")
    li.setArt({'icon': _mi('info.png')})
    li.addContextMenuItems(cm_info)
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="info"), listitem=li, isFolder=False)

    _ek_logo = _mi('espakodi_logo.jpg')
    li = xbmcgui.ListItem(label="[COLOR gold]EspaKodi Addons[/COLOR]")
    li.setArt({'icon': _ek_logo if os.path.exists(_ek_logo) else _mi('descargas.png')})
    li.setInfo('video', {'plot': "Instala y gestiona todos los addons del ecosistema EspaKodi:\nEspaTV, AtresDaily, LoioLog, Flow FavManager, StreamNinja."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="espakodi_addons_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B][COLOR yellow]La VPN puede causar fallos o ser necesaria[/COLOR][/B] — Algunos servidores bloquean VPNs (desactívala si algo no carga). En Dailymotion puede ocurrir lo contrario, si no carga prueba activando la VPN.")
    li.setArt({'icon': _mi('info_vpn.png')})
    li.setInfo('video', {'plot': "Algunos servidores bloquean VPNs (desactívala si algo no carga). En Dailymotion puede ocurrir lo contrario, si no carga prueba activando la VPN."})
    li.addContextMenuItems(cm_info)
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="vpn_info"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

def _history_menu():
    """Historial: muestra búsquedas directamente + enlace a visionado."""
    # Enlace a Historial de Visionado dentro del historial
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    li = xbmcgui.ListItem(label="[B][COLOR mediumpurple]Historial de Visionado[/COLOR][/B]")
    li.setArt({'icon': os.path.join(_med, 'hist_visionado.png')})
    li.setInfo('video', {'plot': "Vídeos reproducidos recientemente desde Dailymotion."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="watch_history"), listitem=li, isFolder=True)

    # Mostrar directamente el historial de búsquedas (como hacía antes _show_history)
    _show_history(skip_end=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

_ACC_COLOR_NAMES = {
    'none':         'Sin modificar (colores originales)',
    'white':        'Texto blanco (todos los colores → blanco)',
    'daltonic_rg':  'Daltónico rojo-verde (deuteranopia/protanopia)',
    'daltonic_by':  'Daltónico azul-amarillo (tritanopia)',
    'hc_dark':      'Alto contraste — fondo oscuro (amarillo)',
    'hc_light':     'Alto contraste — fondo claro (negro)',
}
_ACC_COLOR_PLOTS = {
    'none':        "Los textos aparecen con los colores originales del addon.",
    'white':       "Todos los textos de color se muestran en blanco.\nMaxima legibilidad sobre fondos oscuros.",
    'daltonic_rg': "Optimizado para daltonismo rojo-verde (deuteranopia o protanopia).\nLos rojos pasan a naranja y los verdes a cian.",
    'daltonic_by': "Optimizado para daltonismo azul-amarillo (tritanopia).\nLos amarillos pasan a magenta y los azules/cian a rojo.",
    'hc_dark':     "Alto contraste para skins con fondo oscuro.\nTodo el texto de color se muestra en amarillo, excepto las acciones destructivas (rojo).",
    'hc_light':    "Alto contraste para skins con fondo claro.\nTodo el texto de color se muestra en negro, excepto las acciones destructivas (rojo).",
}


def advanced_menu():
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)

    lvl = _get_context_level()
    if lvl == 0:
        label = "Contexto Completo: [COLOR red]DESACTIVADO[/COLOR]"
        plot = "MODO SIMPLE: Busca usando SOLO el 'Título del Capítulo'.\n\nEjemplo: 'Capítulo 1' (Resultados mezclados).\n\n[COLOR blue][I]Pulsa para activar NIVEL 1[/I][/COLOR]"
    elif lvl == 1:
        label = "Contexto Completo: [COLOR green]NIVEL 1 (Padre)[/COLOR]"
        plot = "MODO RECOMENDADO: Busca usando 'Programa + Título'.\n\nEjemplo: 'Saber y Ganar Capítulo 1'.\n\n[COLOR blue][I]Pulsa para EXTENDER nivel[/I][/COLOR]"
    elif lvl == 2:
        label = "Contexto Completo: [COLOR green]NIVEL 2 (Padre + Abuelo)[/COLOR]"
        plot = "MODO EXTENDIDO: Incluye dos niveles de categorías superiores.\n\nEjemplo: 'Concursos Saber y Ganar Capítulo 1'.\n\n[COLOR blue][I]Pulsa para nivel MÁXIMO[/I][/COLOR]"
    else:
        label = "Contexto Completo: [COLOR green]NIVEL 3 (MAX)[/COLOR]"
        plot = "MODO MÁXIMO: Incluye toda la ruta de navegación.\n\nÚtil para estructuras muy complejas.\n\n[COLOR red][I]Pulsa para DESACTIVAR[/I][/COLOR]"

    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _mi('adv_contexto.png')})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_full_context"), listitem=li, isFolder=False)

    # 1. Búsqueda Avanzada
    if core_settings.is_advanced_search_active():
        label = "Menú de Búsqueda: [COLOR green]AVANZADO (Submenú)[/COLOR]"
        plot = "Al pulsar 'Buscar manualmente', se abrirá un menú intermedio con opciones de búsqueda especializada (Cine, Exacta, etc.).\n\n[COLOR blue][I]Pulsa para volver a Búsqueda Directa[/I][/COLOR]"
    else:
        label = "Menú de Búsqueda: [COLOR grey]SIMPLE (Directa)[/COLOR]"
        plot = "Al pulsar 'Buscar manualmente', se abrirá directamente el teclado para escribir.\n\n[COLOR blue][I]Pulsa para activar el Menú Avanzado[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _mi('adv_busqueda.png')})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_advanced_search"), listitem=li, isFolder=False)

    if _has_ace_player():
        if core_settings.is_acestream_enabled():
            _ace_label = "Busqueda AceStream: [COLOR green]ACTIVADO[/COLOR]"
            _ace_plot = ("Permite buscar identificadores AceStream consultando la API publica oficial (search.acestream.net).\n\n"
                         "Esta opcion esta oculta por defecto porque AceStream es una tecnologia P2P de uso dual y existe el riesgo de persecucion injusta a herramientas que la integran. Activarla es una decision consciente del usuario.\n\n"
                         "[COLOR blue][I]Pulsa para DESACTIVAR[/I][/COLOR]")
        else:
            _ace_label = "Busqueda AceStream: [COLOR grey]DESACTIVADO[/COLOR]"
            _ace_plot = ("Permite buscar identificadores AceStream consultando la API publica oficial (search.acestream.net).\n\n"
                         "Esta desactivada por defecto. Activarla es una decision consciente del usuario, que asume la responsabilidad de los terminos que busque y del contenido que reproduzca.\n\n"
                         "[COLOR blue][I]Pulsa para ACTIVAR[/I][/COLOR]")
        li = xbmcgui.ListItem(label=_ace_label)
        li.setArt({'icon': _mi('adv_acestream.png')})
        li.setInfo('video', {'plot': _ace_plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_acestream_enabled"), listitem=li, isFolder=False)

        if core_settings.is_acestream_enabled():
            _ace_mode = core_settings.get_acestream_server_mode()
            _ace_mode_labels = {"auto": "Automatico (local + publico)", "publico": "Siempre publico", "local": "Solo local"}
            li = xbmcgui.ListItem(label="    Servidor: {0}".format(_ace_mode_labels.get(_ace_mode, _ace_mode)))
            li.setArt({'icon': _mi('adv_acestream.png')})
            li.setInfo('video', {'plot': "Configura que servidor usar para buscar en AceStream.\n\nAutomatico: intenta el servidor local primero y si no hay resultados usa el publico.\nSiempre publico: usa solo search.acestream.net.\nSolo local: usa solo el servidor local (127.0.0.1:6878).\n\nPulsa para cambiar."})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_acestream_server_mode"), listitem=li, isFolder=False)

    # 3. Integración Palan.-. tir (Solo si está instalado)
    if core_settings.is_palantir_installed():
        if core_settings.is_palantir_integration_enabled():
            label = "Integración Palantir 3: [COLOR green]ACTIVADO[/COLOR]"
            plot = "Muestra accesos directos para buscar en Palantir 3 desde el historial, favoritos y resultados.\n\nEsta opción aparece porque se ha detectado que Palantir 3 está instalado.\n\n[B]QUÉ HACE:[/B]\n- Abre Palantir mediante una URL plugin://, la forma estándar en la que los addons de Kodi se llaman entre sí.\n- Adjunta el texto de búsqueda para no tener que volver a escribirlo.\n- Los resultados se muestran dentro de Palantir, no en EspaDaily.\n\n[B]QUÉ NO HACE:[/B]\n- No modifica Palantir. Ni su código, ni sus archivos, ni sus datos.\n- No copia ni reutiliza contenido suyo.\n- No accede a información del usuario en Palantir.\n\n[I]Es completamente legal. Palantir es GPL v2 y Kodi permite que los addons se llamen entre sí.[/I]\n\n[I]Esta opción solo aparece si Palantir 3 está instalado.[/I]\n\n[COLOR blue][I]Pulsa para DESACTIVAR esta integración[/I][/COLOR]"
        else:
            label = "Integración Palantir 3: [COLOR grey]DESACTIVADO[/COLOR]"
            plot = "Oculta todas las opciones relacionadas con Palantir 3.\n\nEsta opción aparece porque se ha detectado que Palantir 3 está instalado.\n\n[B]QUÉ HACE:[/B]\n- Abre Palantir mediante una URL plugin://, la forma estándar en la que los addons de Kodi se llaman entre sí.\n- Adjunta el texto de búsqueda para no tener que volver a escribirlo.\n- Los resultados se muestran dentro de Palantir, no en EspaDaily.\n\n[B]QUÉ NO HACE:[/B]\n- No modifica Palantir. Ni su código, ni sus archivos, ni sus datos.\n- No copia ni reutiliza contenido suyo.\n- No accede a información del usuario en Palantir.\n\n[I]Es completamente legal. Palantir es GPL v2 y Kodi permite que los addons se llamen entre sí.[/I]\n\n[I]Esta opción solo aparece si Palantir 3 está instalado.[/I]\n\n[COLOR blue][I]Pulsa para ACTIVAR[/I][/COLOR]"
            
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _mi('adv_palantir.png')})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_palantir_integration"), listitem=li, isFolder=False)

    # Integración Balandro (Solo si está instalado)
    if core_settings.is_balandro_installed():
        if core_settings.is_balandro_integration_enabled():
            label = "Integración Balandro: [COLOR green]ACTIVADO[/COLOR]"
            plot = "Muestra accesos directos para buscar en Balandro desde el historial, favoritos y resultados.\n\nEsta opción aparece porque se ha detectado que Balandro está instalado.\n\n[B]QUÉ HACE:[/B]\n- Abre Balandro mediante una URL plugin://, la forma estándar en la que los addons de Kodi se llaman entre sí.\n- Adjunta el texto de búsqueda para no tener que volver a escribirlo.\n- Los resultados se muestran dentro de Balandro, no en EspaDaily.\n\n[B]QUÉ NO HACE:[/B]\n- No modifica Balandro. Ni su código, ni sus archivos, ni sus datos.\n- No copia ni reutiliza contenido suyo.\n- No accede a información del usuario en Balandro.\n\n[I]Es completamente legal. Balandro es GPL v3 y Kodi permite que los addons se llamen entre sí.[/I]\n\n[I]Esta opción solo aparece si Balandro está instalado.[/I]\n\n[COLOR blue][I]Pulsa para DESACTIVAR esta integración[/I][/COLOR]"
        else:
            label = "Integración Balandro: [COLOR grey]DESACTIVADO[/COLOR]"
            plot = "Oculta todas las opciones relacionadas con Balandro.\n\nEsta opción aparece porque se ha detectado que Balandro está instalado.\n\n[B]QUÉ HACE:[/B]\n- Abre Balandro mediante una URL plugin://, la forma estándar en la que los addons de Kodi se llaman entre sí.\n- Adjunta el texto de búsqueda para no tener que volver a escribirlo.\n- Los resultados se muestran dentro de Balandro, no en EspaDaily.\n\n[B]QUÉ NO HACE:[/B]\n- No modifica Balandro. Ni su código, ni sus archivos, ni sus datos.\n- No copia ni reutiliza contenido suyo.\n- No accede a información del usuario en Balandro.\n\n[I]Es completamente legal. Balandro es GPL v3 y Kodi permite que los addons se llamen entre sí.[/I]\n\n[I]Esta opción solo aparece si Balandro está instalado.[/I]\n\n[COLOR blue][I]Pulsa para ACTIVAR[/I][/COLOR]"

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _mi('adv_palantir.png')})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_balandro_integration"), listitem=li, isFolder=False)

    # Integraciones con otros addons (toggle global)
    if core_settings.are_external_integrations_disabled():
        ext_label = "Integraciones con otros addons: [COLOR grey]DESACTIVADAS[/COLOR]"
        ext_plot = "Las integraciones con otros addons estan desactivadas.\n\n[COLOR blue][I]Pulsa para activarlas[/I][/COLOR]"
    else:
        ext_label = "Integraciones con otros addons: [COLOR green]ACTIVADAS[/COLOR]"
        ext_plot = "Las integraciones con otros addons estan activadas.\n\n[COLOR blue][I]Pulsa para desactivarlas[/I][/COLOR]"
    li = xbmcgui.ListItem(label=ext_label)
    li.setArt({'icon': _mi('adv_busqueda.png')})
    li.setInfo('video', {'plot': ext_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_external_integrations"), listitem=li, isFolder=False)



    # 2. Debug
    if _is_debug_active():
        li = xbmcgui.ListItem(label="Modo Debug: [COLOR green]ACTIVADO[/COLOR]")
    else:
        li = xbmcgui.ListItem(label="Modo Debug: [COLOR red]DESACTIVADO[/COLOR]")
    li.setArt({'icon': _mi('adv_debug.png')})
    li.setInfo('video', {'plot': "Activa el registro detallado de errores.\n\nPuedes generar un archivo de log interno para solucionar problemas. Puede ralentizar el addon."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_debug"), listitem=li, isFolder=False)

    # 2b. Dev Mode (solo visible con Debug activo)
    if _is_debug_active():
        dev_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')
        is_dev = os.path.exists(dev_flag)
        if is_dev:
            dev_label = "   Modo Desarrollo: [COLOR green]ACTIVO[/COLOR]"
        else:
            dev_label = "   Modo Desarrollo: [COLOR grey]DESACTIVADO[/COLOR]"
        li = xbmcgui.ListItem(label=dev_label)
        li.setArt({'icon': _mi('adv_devmode.png')})
        li.setInfo('video', {'plot': "Protege los modulos internos del addon.\nCuando esta ACTIVO, el addon no se actualiza desde internet.\n\nDesactivar para recibir actualizaciones normales."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_dev_mode"), listitem=li, isFolder=False)

    # 2c. Log y Diagnóstico
    li = xbmcgui.ListItem(label="Log y Diagnóstico")
    li.setArt({'icon': _mi('adv_log.png')})
    li.setInfo('video', {'plot': "Herramientas para ver y analizar el log de Kodi y del addon.\nFiltrar errores, buscar entradas, ver tamaño, etc."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="log_menu"), listitem=li, isFolder=True)

    # 3. Control de Caché (3 Estados)
    cmode = _get_cache_mode()
    if cmode == 0:
        label = "Caché: [COLOR grey]APAGADO (Estándar)[/COLOR]"
        plot = "MODO CLÁSICO (Por Defecto): El addon no guarda nada en el disco. Siempre descarga la información fresca de internet.\n\nEs el comportamiento original de Kodi. Más lento pero ahorra espacio."
    elif cmode == 1:
        label = "Caché: [COLOR yellow]GRABANDO (Segundo Plano)[/COLOR]"
        plot = "MODO PREPARACIÓN: El addon descarga de internet pero va guardando una copia en el disco silenciosamente.\n\nÚtil para ir construyendo tu librería local antes de activar el modo rápido."
    else:
        label = "Caché: [COLOR cyan]ACTIVADO (Híbrido)[/COLOR]"
        plot = "MODO ULTRA RÁPIDO: Carga los menús desde el disco al instante.\n\nSolo conecta a internet si es algo nuevo. Es la mejor experiencia de usuario."

    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _mi('adv_cache.png')})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_frozen"), listitem=li, isFolder=False)
        

    # 5. Priorizar por Ajuste (Match) vs Duración
    if core_settings.is_prioritize_match_active():
        label = "Priorizar: [COLOR green]AJUSTE AL CONTEXTO[/COLOR]"
        plot = "MODO PRECISIÓN: Los resultados se ordenan según cuánto se parecen las palabras clave al título buscado.\n\nIdeal si te aparecen vídeos largos que no tienen nada que ver con lo que buscas.\n\n[COLOR blue][I]Pulsa para priorizar por DURACIÓN (Estándar)[/I][/COLOR]"
    else:
        label = "Priorizar: [COLOR grey]DURACIÓN (ESTÁNDAR)[/COLOR]"
        plot = "MODO CLÁSICO: Se da mucha importancia a la duración del vídeo para encontrar capítulos completos.\n\nPuede causar que aparezcan vídeos largos que no coinciden bien con el nombre.\n\n[COLOR blue][I]Pulsa para priorizar por PRECISIÓN[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _mi('adv_priorizar.png')})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_prioritize_match"), listitem=li, isFolder=False)

    # 6. Priorizar Contenido Reciente
    if core_settings.is_recent_active():
        label = "Filtro Temporal: [COLOR green]RECIENTES PRIMERO[/COLOR]"
        plot = "MODO NOTICIAS: Los vídeos se ordenan por FECHA DE SUBIDA.\n\nIdeal para ver informativos de hoy o programas diarios.\n\n[COLOR blue][I]Pulsa para desactivar[/I][/COLOR]"
    else:
        label = "Filtro Temporal: [COLOR grey]RELEVANCIA (POR DEFECTO)[/COLOR]"
        plot = "MODO MIXTO: El orden depende de cuánto se parezca el título, sin importar si el vídeo es de ayer o de hace meses.\n\n[COLOR blue][I]Pulsa para activar orden RECIENTE[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _mi('adv_filtro_tiempo.png')})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_recent"), listitem=li, isFolder=False)

    # 7. Filtro Anti-Trailers (Minutos)
    min_m = core_settings.get_min_duration()
    if min_m > 0:
        label = f"Anti-Trailers: [COLOR green]SOLO +{min_m} MIN[/COLOR]"
        plot = f"MODO CAPÍTULO: Oculta automáticamente cualquier vídeo de menos de {min_m} minutos.\n\nIdeal para limpiar trailers, clips y avances de los resultados de búsqueda.\n\n[COLOR blue][I]Pulsa para cambiar o desactivar[/I][/COLOR]"
    else:
        label = "Anti-Trailers: [COLOR grey]DESACTIVADO[/COLOR]"
        plot = "MODO TODOS: Muestra todos los resultados encontrados, sin importar su duración.\n\n[COLOR blue][I]Pulsa para filtrar por duración mínima[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _mi('adv_antitrailers.png')})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_min_duration"), listitem=li, isFolder=False)

    # 8b. Copias de Seguridad
    li = xbmcgui.ListItem(label="Copias de Seguridad")
    li.setArt({'icon': _mi('adv_backup.png')})
    li.setInfo('video', {'plot': "Crea, restaura e importa copias ZIP de todos los datos del addon.\nHistorial, favoritos, categorías, instantáneas, configuración y más."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="backups_menu"), listitem=li, isFolder=True)

    # 8c. Ruta de Descargas
    cfg = _load_dm_settings()
    d_path = cfg.get('download_path', '')
    dl_label = "Ruta de Descargas: [COLOR green]{0}[/COLOR]".format(d_path) if d_path else "Ruta de Descargas: [COLOR grey]NO CONFIGURADA[/COLOR]"
    li = xbmcgui.ListItem(label=dl_label)
    li.setArt({'icon': _mi('adv_ruta_dl.png')})
    li.setInfo('video', {'plot': "Selecciona la carpeta donde se guardarán los vídeos descargados."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_download_path"), listitem=li, isFolder=False)
    
    # 8d. Modo Anti-Errores Dailymotion (4 niveles)
    dm_level = cfg.get('dm_safe_level', 0)
    if dm_level == 0:
        dm_label = "Modo Anti-Errores DM: [COLOR grey]DESACTIVADO[/COLOR]"
    elif dm_level == 1:
        dm_label = "Modo Anti-Errores DM: [COLOR green]BÁSICO[/COLOR]"
    elif dm_level == 2:
        dm_label = "Modo Anti-Errores DM: [COLOR gold]EXTREMO[/COLOR]"
    elif dm_level == 3:
        dm_label = "Modo Anti-Errores DM: [COLOR cyan]YT-DLP[/COLOR]"
    else:
        dm_label = "Modo Anti-Errores DM: [COLOR orange]ISA[/COLOR]"
    dm_plot = (
        "MODO ANTI-ERRORES DAILYMOTION:\n\n"
        "[B]DESACTIVADO:[/B] Conexión normal de EspaDaily.\n"
        "[B]BÁSICO:[/B] Simula teléfono móvil Android.\n"
        "[B]EXTREMO:[/B] Técnicas avanzadas (Subtítulos, Verificación de enlaces, etc).\n"
        "[B]YT-DLP:[/B] Usa yt-dlp. Recomendado en Windows donde el CDN bloquea Kodi.\n"
        "[B]ISA:[/B] inputstream.adaptive con headers Dailymotion. Prueba si falla sin VPN.\n\n"
        "[I]Pulsa para cambiar el nivel.[/I]"
    )
    li = xbmcgui.ListItem(label=dm_label)
    li.setArt({'icon': _mi('adv_anti_errores.png')})
    li.setInfo('video', {'plot': dm_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_dm_safe_level"), listitem=li, isFolder=False)

    # Anti-Errores IPTV
    if core_settings.is_iptv_anti_errors_active():
        iptv_ae_label = "Anti-Errores IPTV: [COLOR green]ACTIVADO[/COLOR]"
        iptv_ae_plot = "MODO ANTI-ERRORES IPTV: ACTIVADO\n\nInyecta automáticamente un User-Agent de navegador en los streams IPTV/M3U que no tienen uno propio.\nEvita errores de reproducción en canales que bloquean clientes sin User-Agent.\n\n[COLOR blue][I]Pulsa para desactivar[/I][/COLOR]"
    else:
        iptv_ae_label = "Anti-Errores IPTV: [COLOR grey]DESACTIVADO[/COLOR]"
        iptv_ae_plot = "MODO ANTI-ERRORES IPTV: DESACTIVADO\n\nSi los canales IPTV fallan con 'Playback failed', activa este modo para inyectar un User-Agent de navegador automáticamente.\n\n[COLOR blue][I]Pulsa para activar[/I][/COLOR]"
    li = xbmcgui.ListItem(label=iptv_ae_label)
    li.setArt({'icon': _mi('adv_anti_errores_iptv.png')})
    li.setInfo('video', {'plot': iptv_ae_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_iptv_anti_errors"), listitem=li, isFolder=False)

    # Motor TDT (InputStream Adaptive vs Nativo)
    if core_settings.is_tdt_inputstream_active():
        tdt_eng_label = "Motor TDT: [COLOR green]INPUTSTREAM ADAPTIVE[/COLOR]"
        tdt_eng_plot = (
            "MOTOR TDT: INPUTSTREAM ADAPTIVE\n\n"
            "Usa el motor InputStream Adaptive para reproducir streams M3U8.\n"
            "Permite pausar el directo (TimeShift) y mejora la reconexion de red.\n\n"
            "[B]AVISO:[/B] Requiere el addon 'inputstream.adaptive' instalado en Kodi.\n\n"
            "[COLOR blue][I]Pulsa para volver al motor NATIVO[/I][/COLOR]"
        )
    else:
        tdt_eng_label = "Motor TDT: [COLOR grey]NATIVO (Por defecto)[/COLOR]"
        tdt_eng_plot = (
            "MOTOR TDT: NATIVO\n\n"
            "Usa el reproductor nativo de Kodi para los canales TDT/IPTV M3U8.\n"
            "Compatible con todos los sistemas. El directo no se puede pausar.\n\n"
            "[COLOR blue][I]Pulsa para activar INPUTSTREAM ADAPTIVE[/I][/COLOR]"
        )
    li = xbmcgui.ListItem(label=tdt_eng_label)
    li.setArt({'icon': _mi('adv_motor_tdt.png')})
    li.setInfo('video', {'plot': tdt_eng_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_tdt_inputstream"), listitem=li, isFolder=False)

    # 8e. Modo de Descarga
    dl_mode = cfg.get('dl_mode', 0)
    if dl_mode == 0:
        d_mode_txt = "[COLOR grey]DIRECTO (Normal)[/COLOR]"
    elif dl_mode == 1:
        d_mode_txt = "[COLOR green]SAFE MODE (Gujal)[/COLOR]"
    elif dl_mode == 2:
        d_mode_txt = "[COLOR gold]MODO ESPADAILY (HLS Process)[/COLOR]"
    elif dl_mode == 3:
        d_mode_txt = "[COLOR cyan]YT-DLP (Externo)[/COLOR]"
    else:
        d_mode_txt = "[COLOR magenta]ULTRA (Multi-hilo HLS+)[/COLOR]"
        
    dl_s_label = f"Modo de Descarga: {d_mode_txt}"
    dl_s_plot = (
        "MODO DE DESCARGA:\n\n"
        "[B]DIRECTO:[/B] Muestra menú para elegir calidad.\n"
        "[B]SAFE MODE:[/B] Descarga el mejor MP4 directo.\n"
        "[B]ESPADAILY:[/B] Descarga por segmentos HLS.\n"
        "[B]YT-DLP:[/B] Usa yt-dlp (mejor calidad). Requiere Python 3.10+.\n"
        "[B]ULTRA:[/B] Igual que YT-DLP (mejor calidad). Recomendado en PC."
    )
    li = xbmcgui.ListItem(label=dl_s_label)
    li.setArt({'icon': _mi('adv_modo_dl.png')})
    li.setInfo('video', {'plot': dl_s_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_dl_mode"), listitem=li, isFolder=False)

    # 8f. Estado del Repositorio
    _repo_id = "repository.espadaily"
    _repo_installed = xbmc.getCondVisibility(f"System.HasAddon({_repo_id})")
    if _repo_installed:
        repo_label = "Repositorio: [COLOR green]INSTALADO[/COLOR]"
        repo_plot = (
            "El repositorio de EspaDaily está correctamente instalado.\n\n"
            "El addon se actualizará automáticamente cuando haya nuevas versiones disponibles.\n\n"
            "[I]No necesitas hacer nada más.[/I]"
        )
    else:
        repo_label = "Repositorio: [COLOR red]NO INSTALADO[/COLOR]"
        repo_plot = (
            "[COLOR red][B]¡ATENCIÓN![/B][/COLOR] El repositorio NO está instalado.\n\n"
            "Sin el repositorio, el addon [B]NO se actualizará automáticamente[/B]. "
            "Tendrás que instalar cada nueva versión manualmente.\n\n"
            "[COLOR yellow][B]INSTRUCCIONES PARA INSTALAR:[/B][/COLOR]\n\n"
            "1. Ve a Ajustes > Gestor de Archivos > Añadir fuente\n"
            "2. Escribe: https://fullstackcurso.github.io/espadaily/\n"
            "3. Ponle de nombre: espadaily\n"
            "4. Ve a Addons > Instalar desde un archivo ZIP\n"
            "5. Selecciona la fuente 'espadaily'\n"
            "6. Instala repository.espadaily-x.x.x.zip\n\n"
            "Una vez instalado, las actualizaciones serán automáticas.\n\n"
            "[I]Pulsa para ver las instrucciones en pantalla completa.[/I]"
        )
    li = xbmcgui.ListItem(label=repo_label)
    li.setArt({'icon': _mi('adv_repo.png')})
    li.setInfo('video', {'plot': repo_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="check_repo_status"), listitem=li, isFolder=False)

    # Accesibilidad
    li = xbmcgui.ListItem(label="Accesibilidad")
    li.setArt({'icon': _mi('adv_accesibilidad.png')})
    li.setInfo('video', {'plot': "Opciones de accesibilidad visual: modo de color, negrita forzada y sustitucion de simbolos.\n\nAdapta la apariencia del addon para distintas necesidades visuales (daltonismo, alto contraste, etc.)."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="accessibility_menu"), listitem=li, isFolder=True)

    # 8g. Limpieza (caches, compactar metadatos y restablecer addon)
    li = xbmcgui.ListItem(label="Limpieza")
    li.setArt({'icon': _mi('adv_limpieza.png')})
    li.setInfo('video', {'plot': "Opciones para liberar espacio: borrar caches temporales, compactar la base de metadatos o restablecer el addon a estado de fabrica."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cleanup_menu"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _acc_set_color_mode():
    modes = list(_ACC_COLOR_NAMES.keys())
    current = core_settings.get_acc_color_mode()
    idx = modes.index(current) if current in modes else 0
    chosen = xbmcgui.Dialog().select("Modo de color", list(_ACC_COLOR_NAMES.values()), preselect=idx)
    if chosen < 0:
        return
    core_settings.set_acc_color_mode(modes[chosen])
    xbmcgui.Dialog().notification("Accesibilidad", "Modo de color guardado. Reinicia Kodi para ver los cambios.", xbmcgui.NOTIFICATION_INFO, 4000)
    xbmc.executebuiltin("Container.Refresh")

def _acc_toggle_bold():
    new_val = not core_settings.get_acc_force_bold()
    core_settings.set_acc_force_bold(new_val)
    msg = "ACTIVADA" if new_val else "DESACTIVADA"
    xbmcgui.Dialog().notification("Accesibilidad", f"Negrita {msg}. Reinicia Kodi para ver los cambios.", xbmcgui.NOTIFICATION_INFO, 4000)
    xbmc.executebuiltin("Container.Refresh")

def _acc_toggle_symbols():
    new_val = not core_settings.get_acc_strip_symbols()
    core_settings.set_acc_strip_symbols(new_val)
    msg = "ACTIVADA" if new_val else "DESACTIVADA"
    xbmcgui.Dialog().notification("Accesibilidad", f"Sustitucion de simbolos {msg}. Reinicia Kodi para ver los cambios.", xbmcgui.NOTIFICATION_INFO, 4000)
    xbmc.executebuiltin("Container.Refresh")

def accessibility_menu():
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)

    color_mode = core_settings.get_acc_color_mode()
    bold_on    = core_settings.get_acc_force_bold()
    strip_sym  = core_settings.get_acc_strip_symbols()

    color_name = _ACC_COLOR_NAMES.get(color_mode, color_mode)
    color_tag  = "[COLOR green]" if color_mode != 'none' else "[COLOR grey]"
    li = xbmcgui.ListItem(label=f"Modo de color: {color_tag}{color_name}[/COLOR]")
    li.setArt({'icon': _mi('adv_idioma.png')})
    li.setInfo('video', {'plot': _ACC_COLOR_PLOTS.get(color_mode, "") + "\n\n[COLOR blue][I]Pulsa para cambiar el modo de color.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acc_set_color"), listitem=li, isFolder=False)

    bold_tag = "[COLOR green]ACTIVADA[/COLOR]" if bold_on else "[COLOR red]DESACTIVADA[/COLOR]"
    li = xbmcgui.ListItem(label=f"Negrita forzada: {bold_tag}")
    li.setArt({'icon': _mi('adv_idioma.png')})
    li.setInfo('video', {'plot': "Muestra todos los textos de los botones en negrita.\n\n[COLOR blue][I]Pulsa para activar/desactivar. Reinicia Kodi para ver los cambios.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acc_toggle_bold"), listitem=li, isFolder=False)

    sym_tag = "[COLOR green]ACTIVADA[/COLOR]" if strip_sym else "[COLOR grey]DESACTIVADA[/COLOR]"
    li = xbmcgui.ListItem(label=f"Sustitucion de simbolos especiales: {sym_tag}")
    li.setArt({'icon': _mi('adv_idioma.png')})
    li.setInfo('video', {'plot': "Reemplaza caracteres Unicode especiales (★ ● ▲ ▼ etc.) por equivalentes ASCII (* ^ v).\nUtil si tu skin no muestra correctamente estos caracteres.\n\n[COLOR blue][I]Pulsa para activar/desactivar. Reinicia Kodi para ver los cambios.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="acc_toggle_symbols"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _check_repo_status():
    """Muestra el estado del repositorio y ofrece instalación si falta."""
    _repo_id = "repository.espadaily"
    installed = xbmc.getCondVisibility(f"System.HasAddon({_repo_id})")

    if not installed:
        # Deep scan: detecta el repo aunque esté deshabilitado o la carpeta tenga otro nombre
        try:
            import xml.etree.ElementTree as ET
            addons_path = xbmcvfs.translatePath("special://home/addons/")
            dirs, _ = xbmcvfs.listdir(addons_path)
            for d in dirs:
                if "repository" not in d.lower() and "espadaily" not in d.lower():
                    continue
                xml_vfs = f"special://home/addons/{d}/addon.xml"
                if not xbmcvfs.exists(xml_vfs):
                    continue
                try:
                    vf = xbmcvfs.File(xml_vfs)
                    content = vf.read()
                    vf.close()
                    root = ET.fromstring(content)
                    if root.attrib.get('id', '') == _repo_id:
                        installed = True
                        _enable_repo_addon(_repo_id)
                        break
                except Exception:
                    continue
        except Exception as e:
            xbmc.log(f"[EspaDaily] Deep scan repo: {e}", xbmc.LOGWARNING)

    if installed:
        xbmcgui.Dialog().ok(
            "Estado del Repositorio",
            "[COLOR green][B]● INSTALADO Y ACTIVO[/B][/COLOR]\n\n"
            "El repositorio oficial está configurado correctamente.\n\n"
            "El addon se actualizará automáticamente cuando haya nuevas versiones disponibles."
        )
    else:
        if xbmcgui.Dialog().yesno(
            "Repositorio No Detectado",
            "Para recibir mejoras y actualizaciones automáticas, es necesario\n"
            "instalar el repositorio oficial de EspaDaily.\n\n"
            "¿Deseas instalarlo ahora mismo?"
        ):
            _install_espadaily_repo()


def _enable_repo_addon(repo_id):
    """Habilita el addon vía JSON-RPC con 5 reintentos (UpdateLocalAddons es asíncrono)."""
    import json as _json
    payload = _json.dumps({"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled",
                           "params": {"addonid": repo_id, "enabled": True}, "id": 1})
    for _ in range(5):
        response = xbmc.executeJSONRPC(payload)
        if '"error"' not in response:
            return
        xbmc.sleep(1000)


def _vfs_rmtree(path):
    """Eliminación recursiva VFS."""
    if not path.endswith('/'):
        path += '/'
    dirs, files = xbmcvfs.listdir(path)
    for f in files:
        xbmcvfs.delete(f"{path}{f}")
    for d in dirs:
        _vfs_rmtree(f"{path}{d}")
    xbmcvfs.rmdir(path)


def _repo_manual_instructions():
    xbmcgui.Dialog().ok(
        "Instalación Manual",
        "Añade esta fuente en Ajustes > Gestor de Archivos:\n\n"
        "[B][COLOR yellow]https://fullstackcurso.github.io/espadaily/[/COLOR][/B]\n\n"
        "Luego ve a Addons > Instalar desde un archivo ZIP\n"
        "y selecciona repository.espadaily-x.x.x.zip"
    )


_REPO_ICON_URL = "https://raw.githubusercontent.com/fullstackcurso/espadaily/main/plugin.video.espadaily/icon.png"
_PNG_MAGIC = b'\x89PNG\r\n\x1a\n'


def _download_repo_icon(dest_vfs):
    """Descarga icon.png del repositorio y lo escribe via VFS. No lanza excepciones."""
    try:
        import requests as _req
        r = _req.get(_REPO_ICON_URL, timeout=10)
        if r.status_code != 200:
            xbmc.log(f"[EspaDaily] Icono repo: HTTP {r.status_code}", xbmc.LOGWARNING)
            return False
        content = r.content
        # Validar que es un PNG real (magic bytes) y tamaño mínimo razonable
        if len(content) < 67 or not content.startswith(_PNG_MAGIC):
            xbmc.log("[EspaDaily] Icono repo: respuesta no es un PNG válido", xbmc.LOGWARNING)
            return False
        icon_path = dest_vfs.rstrip('/') + '/icon.png'
        v_file = xbmcvfs.File(icon_path, 'wb')
        ok = v_file.write(bytearray(content))
        v_file.close()
        if ok is False:
            xbmc.log("[EspaDaily] Icono repo: VFS write devolvió False", xbmc.LOGWARNING)
            return False
        return True
    except Exception as e:
        xbmc.log(f"[EspaDaily] Icono repo: excepción ignorada — {e}", xbmc.LOGWARNING)
        return False


def _install_espadaily_repo():
    """Instala el repositorio oficial: Capa 1 local → Capa 2 remota → Capa 3 manual."""
    _REPO_ID = "repository.espadaily"
    _DEST_VFS = f"special://home/addons/{_REPO_ID}"

    # --- CAPA 1: Instalación local desde recursos embebidos ---
    addon_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
    src_os = os.path.join(addon_path, "resources", _REPO_ID)
    if os.path.exists(src_os):
        try:
            if xbmcvfs.exists(_DEST_VFS):
                _vfs_rmtree(_DEST_VFS)
            xbmcvfs.mkdirs(_DEST_VFS + '/')
            for item in os.listdir(src_os):
                with open(os.path.join(src_os, item), 'rb') as fh:
                    content = fh.read()
                v_file = xbmcvfs.File(f"{_DEST_VFS}/{item}", 'wb')
                ok = v_file.write(content)
                v_file.close()
                if ok is False and len(content) > 0:
                    raise IOError(f"VFS write falló en {item}")
            _download_repo_icon(_DEST_VFS)
            xbmc.executebuiltin("UpdateLocalAddons()")
            xbmc.sleep(500)
            xbmc.executebuiltin(f"InstallAddon({_REPO_ID})")
            _enable_repo_addon(_REPO_ID)
            xbmcgui.Dialog().notification("EspaDaily", "Repositorio instalado con éxito", xbmcgui.NOTIFICATION_INFO, 3000)
            xbmc.executebuiltin("Container.Refresh")
            return
        except Exception as e:
            xbmc.log(f"[EspaDaily] Instalación local falló: {e}", xbmc.LOGWARNING)
            try:
                if xbmcvfs.exists(_DEST_VFS):
                    _vfs_rmtree(_DEST_VFS)
            except Exception:
                pass

    # --- CAPA 2: Descarga remota ---
    if not xbmcgui.Dialog().yesno(
        "Instalación local fallida",
        "La instalación local falló (restricciones del dispositivo).\n\n"
        "¿Deseas descargarlo directamente desde el servidor oficial?"
    ):
        _repo_manual_instructions()
        return

    _REPO_URL = "https://fullstackcurso.github.io/espadaily/repository.espadaily-1.0.0.zip"
    zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "espadaily_repo.zip")
    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", "Preparando descarga...")
    try:
        import requests as _req, zipfile as _zf
        dp.update(10, "Descargando repositorio...")
        r = _req.get(_REPO_URL, stream=True, timeout=30)
        if r.status_code != 200:
            raise IOError(f"Error HTTP {r.status_code}")
        total = int(r.headers.get("content-length", 0))
        downloaded = 0
        with open(zip_path, "wb") as fh:
            for chunk in r.iter_content(chunk_size=65536):
                if dp.iscanceled():
                    return
                if chunk:
                    fh.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        dp.update(10 + int(downloaded / total * 60), "Descargando repositorio...")
        dp.update(75, "Instalando en Kodi (VFS)...")
        with _zf.ZipFile(zip_path, "r") as zf:
            for member in zf.infolist():
                if member.is_dir():
                    continue
                vfs_dest = f"special://home/addons/{member.filename}"
                parent_dir = "special://home/addons/" + "/".join(member.filename.split("/")[:-1])
                if parent_dir and not xbmcvfs.exists(parent_dir):
                    xbmcvfs.mkdirs(parent_dir)
                content = zf.read(member)
                v_file = xbmcvfs.File(vfs_dest, "wb")
                ok = v_file.write(content)
                v_file.close()
                if ok is False and len(content) > 0:
                    raise IOError(f"VFS write falló en {vfs_dest}")
        dp.update(90, "Descargando icono...")
        _download_repo_icon(_DEST_VFS)
        dp.update(95, "Activando repositorio...")
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(1000)
        xbmc.executebuiltin(f"InstallAddon({_REPO_ID})")
        _enable_repo_addon(_REPO_ID)
        dp.update(100)
        dp.close()
        xbmcgui.Dialog().notification("EspaDaily", "Repositorio instalado con éxito", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        dp.close()
        xbmc.log(f"[EspaDaily] Descarga remota falló: {e}", xbmc.LOGERROR)
        try:
            if xbmcvfs.exists(_DEST_VFS):
                _vfs_rmtree(_DEST_VFS)
        except Exception:
            pass
        _repo_manual_instructions()
    finally:
        if os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass


def _toggle_dev_mode():
    """Activa o desactiva el modo desarrollo creando/eliminando .dev_mode."""
    dev_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')
    if os.path.exists(dev_flag):
        try:
            os.remove(dev_flag)
            xbmcgui.Dialog().notification("EspaDaily", "Modo Desarrollo DESACTIVADO", xbmcgui.NOTIFICATION_INFO)
        except Exception as e:
            xbmcgui.Dialog().ok("Error", "No se pudo desactivar: {0}".format(e))
    else:
        try:
            with open(dev_flag, 'w') as f:
                f.write('dev')
            xbmcgui.Dialog().notification("EspaDaily", "Modo Desarrollo ACTIVO", xbmcgui.NOTIFICATION_WARNING)
        except Exception as e:
            xbmcgui.Dialog().ok("Error", "No se pudo activar: {0}".format(e))
    xbmc.executebuiltin("Container.Refresh")

def _get_debug_state_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'debug_state.json')

def _is_debug_active():
    f = _get_debug_state_file()
    if not os.path.exists(f): return False
    try:
        with open(f, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def _toggle_debug():
    new_state = not _is_debug_active()
    
    # Advertencia de seguridad SIEMPRE (tanto al activar como al desactivar)
    action_str = "activar" if new_state else "desactivar"
    if not xbmcgui.Dialog().yesno("ADVERTENCIA DE SEGURIDAD", 
        f"[COLOR red]ALERTA:[/COLOR] Vas a {action_str} el Modo Debug.\n\n"
        "Si no sabes lo que estás haciendo, esto podría causar errores o inestabilidad en el addon.\n"
        "¿Estás seguro de continuar?"):
        return


    log_to_file = False
    if new_state:
        if xbmcgui.Dialog().yesno("Generar Log de Errores", 
            "¿Quieres generar un archivo LOG en la raíz del addon con los errores del addon?\n\n"
            "Esto creará 'espadaily_errors.log' en la carpeta del plugin."):
            log_to_file = True
            # Crear archivo con cabecera
            try:
                base_dir = os.path.dirname(os.path.abspath(__file__))
                log_file = os.path.join(base_dir, 'espadaily_errors.log')
                ts = time.strftime('%Y-%m-%d %H:%M:%S')
                with open(log_file, 'a', encoding='utf-8') as lf:
                    lf.write(f"[{ts}] --- INICIO DE SESIÓN DE DEBUG ---\n")
            except Exception: pass
    else:
        # Desactivando: Borrar archivo de log
        try:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            log_file = os.path.join(base_dir, 'espadaily_errors.log')
            if os.path.exists(log_file):
                os.remove(log_file)
        except Exception: pass

    with open(_get_debug_state_file(), 'w', encoding='utf-8') as o: json.dump({'active': new_state, 'log_to_file': log_to_file}, o)
    
    msg = "ACTIVADO" if new_state else "DESACTIVADO"
    if log_to_file: msg += " (Con Log Propio)"
    xbmcgui.Dialog().notification("EspaDaily", f"Modo Debug {msg}", xbmcgui.NOTIFICATION_INFO)
    # Forzamos viaje al menu principal rompiendo la cache con un timestamp
    xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?reload={int(time.time())}, replace)")

def _log_error(msg):
    xbmc.log(f"[EspaDaily ERROR] {msg}", xbmc.LOGERROR)
    try:
        f = _get_debug_state_file()
        if os.path.exists(f):
            with open(f, 'r', encoding='utf-8') as fh:
                st = json.load(fh)
            if st.get('active') and st.get('log_to_file'):
                base_dir = os.path.dirname(os.path.abspath(__file__))
                log_file = os.path.join(base_dir, 'espadaily_errors.log')
                ts = time.strftime('%Y-%m-%d %H:%M:%S')
                with open(log_file, 'a', encoding='utf-8') as lf:
                    lf.write(f"[{ts}] {msg}\n")
    except Exception: pass

def _view_error_log():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    log_file = os.path.join(base_dir, 'espadaily_errors.log')
    
    if not os.path.exists(log_file):
        xbmcgui.Dialog().ok("Error", "No existe el archivo de log.\nActiva el Modo Debug y genera errores primero.")
        return

    opts = ["Ver archivo completo", "Últimas 50 líneas", "Últimas 20 líneas", "Últimas 10 líneas"]
    sel = xbmcgui.Dialog().select("¿Qué deseas ver?", opts)
    if sel < 0: return
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            
        content = ""
        if not lines:
            content = "[El archivo está vacío]"
        else:
            if sel == 0: # Todo
                content = "".join(lines)
            elif sel == 1: # 50
                content = "".join(lines[-50:])
            elif sel == 2: # 20
                content = "".join(lines[-20:])
            elif sel == 3: # 10
                content = "".join(lines[-10:])
                
        xbmcgui.Dialog().textviewer("Log de Errores - EspaDaily", content)
    except Exception as e:
        xbmcgui.Dialog().ok("Error Leyendo Log", str(e))

def _get_frozen_state_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'frozen_state.json')

def _is_frozen_active():

    return _get_cache_mode() == 2

def _get_cache_mode():
    f = _get_frozen_state_file()
    if not os.path.exists(f): return 0 # Default OFF
    try:
        with open(f, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        # Migrar formato booleano antiguo
        val = data.get('active', 0)
        if val is True: return 2
        if val is False: return 0
        return int(val)
    except Exception: return 0

def _toggle_frozen():
    curr = _get_cache_mode()
    # Cycle: 0 -> 1 -> 2 -> 0
    new_mode = (curr + 1) % 3
    
    with open(_get_frozen_state_file(), 'w', encoding='utf-8') as o: json.dump({'active': new_mode}, o)
    
    if new_mode == 0:
        msg = "Caché APAGADA: Datos temporales eliminados"
        # Borrar caché API automáticamente al apagar
        _clear_api_cache_only()
    elif new_mode == 1:
        msg = "Caché: GRABANDO en segundo plano"
    else:
        msg = "Caché: HÍBRIDA (Ultra Rápida)"
        
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _clear_api_cache_only():
    # Solo borrar archivos en api_cache, preservar historial y ajustes
    try:
        cd = _get_cache_dir()
        if os.path.exists(cd):
            for f in os.listdir(cd):
                if f.endswith(".json"):
                    os.remove(os.path.join(cd, f))
    except Exception: pass

def _toggle_prioritize_match():
    new_state = not core_settings.is_prioritize_match_active()
    core_settings.set_prioritize_match(new_state)
    msg = "MODO PRECISIÓN ACTIVADO" if new_state else "MODO DURACIÓN (ESTÁNDAR)"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_recent():
    new_state = not core_settings.is_recent_active()
    core_settings.set_recent_active(new_state)
    msg = "ORDEN RECIENTE ACTIVADO" if new_state else "ORDEN RELEVANCIA REINSTAURADO"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _set_min_duration_filter():
    opts = ["Desactivado", "Más de 2 min", "Más de 5 min", "Más de 10 min", "Más de 20 min (Solo Full)"]
    vals = [0, 2, 5, 10, 20]
    sel = xbmcgui.Dialog().select("Ocultar vídeos más cortos que...", opts)
    if sel < 0: return
    core_settings.set_min_duration(vals[sel])
    xbmc.executebuiltin("Container.Refresh")

def _toggle_iptv_anti_errors():
    new_state = not core_settings.is_iptv_anti_errors_active()
    core_settings.set_iptv_anti_errors(new_state)
    msg = "ACTIVADO" if new_state else "DESACTIVADO"
    xbmcgui.Dialog().notification("Anti-Errores IPTV", f"Modo Anti-Errores IPTV {msg}", xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_tdt_inputstream():
    new_state = not core_settings.is_tdt_inputstream_active()
    if new_state:
        if not xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
            xbmcgui.Dialog().ok(
                "Aviso Importante",
                "Has activado InputStream Adaptive, pero el componente no esta instalado en Kodi.\n\n"
                "Instala 'InputStream Adaptive' desde el repositorio oficial de Kodi antes de usar este modo."
            )
            return
    core_settings.set_tdt_inputstream(new_state)
    msg = "InputStream Adaptive ACTIVADO" if new_state else "Motor NATIVO restaurado"
    xbmcgui.Dialog().notification("Motor TDT", msg, xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_palantir_integration():
    new_state = not core_settings.is_palantir_integration_enabled()
    core_settings.set_palantir_integration_enabled(new_state)
    
    if new_state:
        xbmcgui.Dialog().ok("Integración Palantir", "AVISO IMPORTANTE:\n\nEspaDaily NO está afiliado ni relacionado con el addon Palantir 3 ni sus desarrolladores.\n\nEsta función es simplemente un ATAJO de búsqueda externa para facilitar la navegación.")
        
    msg = "Integración Palantir: ACTIVADA" if new_state else "Integración Palantir: DESACTIVADA"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_balandro_integration():
    new_state = not core_settings.is_balandro_integration_enabled()
    core_settings.set_balandro_integration_enabled(new_state)

    if new_state:
        xbmcgui.Dialog().ok("Integración Balandro", "AVISO IMPORTANTE:\n\nEspaDaily NO está afiliado ni relacionado con el addon Balandro ni sus desarrolladores.\n\nEsta función es simplemente un ATAJO de búsqueda externa para facilitar la navegación.")

    msg = "Integración Balandro: ACTIVADA" if new_state else "Integración Balandro: DESACTIVADA"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_external_integrations():
    new_state = not core_settings.are_external_integrations_disabled()
    core_settings.set_external_integrations_disabled(new_state)
    msg = "Integraciones con otros addons: DESACTIVADAS" if new_state else "Integraciones con otros addons: ACTIVADAS"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _bi(context, title):
    return core_settings.build_query(title, context)

def _is_full_context_active():
    return core_settings.get_context_level() > 0

def _get_context_level():
    return core_settings.get_context_level()

def _toggle_full_context():
    new_level = core_settings.cycle_context_level()
    
    if new_level == 0:
         msg = "[COLOR red]DESACTIVADO[/COLOR]"
         detail = "Búsqueda simple: Solo Título.\n\n[COLOR blue][I]Pulsa otra vez para NIVEL 1[/I][/COLOR]"
    elif new_level == 1:
         msg = "[COLOR green]NIVEL 1 (Padre)[/COLOR]"
         detail = "Búsqueda: Padre + Título (ej. Serie + Capítulo).\n\n[COLOR blue][I]Pulsa otra vez para EXTENDER nivel[/I][/COLOR]"
    elif new_level == 2:
         msg = "[COLOR green]NIVEL 2 (Padre + Abuelo)[/COLOR]"
         detail = "Búsqueda: Abuelo + Padre + Título.\n\n[COLOR blue][I]Pulsa otra vez para nivel MÁXIMO[/I][/COLOR]"
    else:
         msg = "[COLOR green]NIVEL 3 (MAX)[/COLOR]"
         detail = "Búsqueda: Ruta completa + Título.\n\n[COLOR red][I]Pulsa otra vez para DESACTIVAR[/I][/COLOR]"

    xbmcgui.Dialog().ok("EspaDaily", f"Contexto Completo: {msg}\n{detail}")
    xbmc.executebuiltin("Container.Refresh")

def _get_cache_dir():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    cd = os.path.join(p, 'api_cache')
    if not os.path.exists(cd): os.makedirs(cd)
    return cd

def _save_cache(key, data):
    try:
        f = os.path.join(_get_cache_dir(), f"{key}.json")
        with open(f, 'w', encoding='utf-8') as o: json.dump(data, o)
    except Exception: pass

def _load_cache(key):
    f = os.path.join(_get_cache_dir(), f"{key}.json")
    if os.path.exists(f):
        try:
            with open(f, 'r', encoding='utf-8') as o: return json.load(o)
        except Exception: pass
    return None

def _sanitized_info():
    t = (
        "[B]EspaDaily[/B]\nAddon desarrollado por RubénSDFA1laberot\n\n"
        
        "[B]AVISO LEGAL Y TÉCNICO IMPORTANTE:[/B]\n\n"
        
        "[B]1. No Afiliación:[/B]\n"
        "Este proyecto es independiente. NO tiene ninguna afiliación, acuerdo ni vinculación con Atresplayer, RTVE, Mediaset ni ninguna entidad oficial. Las marcas comerciales se utilizan con fin únicamente descriptivo para organizar los menús de búsqueda.\n\n"
        
        "[B]2. Naturaleza Técnica (Agregador de Búsqueda):[/B]\n"
        "Este software actúa exclusivamente como una herramienta de automatización. NO contiene, aloja ni sube contenido protegido.\n"
        "• El addon nunca interactúa, descifra ni elude la seguridad de los servidores de las cadenas oficiales.\n"
        "• Funciona realizando búsquedas de texto en servidores públicos de terceros, mostrando resultados que ya son accesibles públicamente en cualquier navegador web.\n\n"
        
        "[B]3. Responsabilidad del Usuario:[/B]\n"
        "El desarrollador no tiene control sobre los resultados encontrados. El usuario es el único responsable de verificar la legalidad del acceso a dichos contenidos según las leyes de su país de residencia. Este addon se proporciona \"tal cual\", sin garantías de ningún tipo.\n\n"
        
        "[B]4. Propósito:[/B]\n"
        "Es GRATUITO, sin ánimo de lucro y está desarrollado de buena fe con fines educativos y de investigación tecnológica.\n\n"
        
        "[B]Contacto y Retirada:[/B]\n"
        "Si usted es titular de derechos y considera que este software le perjudica, puede solicitar la retirada de funcionalidad relacionada a través del canal de Telegram o GitHub.\n\n"
        
        "[B]¿Qué puedo encontrar?[/B]\n"
        "El addon intenta filtrar los resultados con la mayor precisión posible, pero la precisión depende totalmente del contenido disponible públicamente en ese momento.\n"
        "• Es posible encontrar capítulos o películas completas.\n"
        "• A veces solo aparecerán tráilers, resúmenes o clips.\n"
        "• En ocasiones pueden aparecer resultados solo relacionados o similares.\n"
        "El addon NO garantiza qué resultados aparecen, ya que depende exclusivamente de lo que otros usuarios hayan compartido en la red."
    )
    xbmcgui.Dialog().textviewer("Información - RubénSDFA1laberot", t)

def _info():
    t = (
        "[B]AVISO LEGAL Y TÉCNICO IMPORTANTE:[/B]\n\n"

        "[B]1. Gratuito y sin ánimo de lucro:[/B]\n"
        "Este addon es completamente GRATUITO y siempre lo será. Si alguien te lo ha vendido, te han estafado. Cualquier etiqueta tipo \"Premium\" o equivalente hace referencia a la suscripción de la plataforma de origen; no a este addon.\n\n"

        "[B]2. Responsabilidad del Usuario:[/B]\n"
        "El desarrollador no tiene control sobre los resultados encontrados en servidores externos. El usuario es el único responsable de verificar la legalidad del acceso a dichos contenidos según las leyes de su país de residencia. Este addon se proporciona \"tal cual\", sin garantías de ningún tipo.\n\n"

        "[B]3. No Afiliación:[/B]\n"
        "Este proyecto es independiente. NO tiene ninguna afiliación, acuerdo ni vinculación con ninguna cadena de televisión, plataforma ni entidad oficial. Las marcas comerciales se utilizan con fin únicamente descriptivo para organizar los menús de búsqueda.\n\n"

        "[B]4. Naturaleza Técnica (Agregador de Búsqueda):[/B]\n"
        "Este software actúa exclusivamente como una herramienta de automatización. NO contiene, aloja ni sube contenido protegido.\n"
        "• El addon nunca interactúa, descifra ni elude la seguridad de servidores de terceros.\n"
        "• Funciona realizando búsquedas de texto en servidores públicos de terceros, mostrando resultados que ya son accesibles públicamente en cualquier navegador web.\n\n"

        "[B]5. Propósito:[/B]\n"
        "Proyecto amateur. Sin publicidad ni recolección de hábitos de uso.\n\n"
        
        "[B]Contacto y Retirada:[/B]\n"
        "Si usted es titular de derechos y considera que este software le perjudica, puede solicitar la retirada de funcionalidad relacionada a través de los canales indicados en el repositorio oficial.\n\n"

        "[B]¿Qué puedo encontrar?[/B]\n"
        "El addon intenta filtrar los resultados con la mayor precisión posible, pero la precisión depende totalmente del contenido disponible públicamente en ese momento.\n"
        "• A veces solo aparecerán tráilers, resúmenes o clips.\n"
        "• En ocasiones pueden aparecer resultados solo relacionados o similares.\n"
        "El addon NO garantiza qué resultados aparecen, ya que depende exclusivamente de lo que otros usuarios hayan compartido en la red.\n\n"
        "[COLOR red][B]AVISO LEGAL:[/B][/COLOR] El uso de este addon implica la lectura y aceptación estricta del documento [B]AVISO_LEGAL.txt[/B] incluido en esta instalación."
    )
    xbmcgui.Dialog().textviewer("Información de EspaDaily", t)

def _web_info():
    t = (
        "https://espatv.github.io\n\n"
        "------------------------------------------------\n\n"
        "[B]Visita nuestra web para más proyectos como este.[/B]\n\n"
        "Allí encontrarás nuestros proyectos y actualizaciones.\n"
        "Cualquier apoyo o difusión de nuestros proyectos se agradece enormemente.\n\n"
    )
    xbmcgui.Dialog().textviewer("Más en...", t)

def _version_notes():
    t = (
        "[B]GUÍA DE USUARIO & NOTAS V2.0.1[/B]\n\n"
        "¡Bienvenido a EspaDaily v2! Estas son las novedades:\n\n"
        "------------------------------------------------\n"
        "[B]NOVEDADES V2.0.1[/B]\n\n"
        "• [B]Descarga ULTRA:[/B] Nuevo modo de descarga multi-hilo (4 conexiones paralelas) para descargar vídeos HLS a máxima velocidad.\n"
        "• [B]Corrección Android:[/B] Solucionado error 'bool object is not iterable' que causaba cierres inesperados en búsquedas.\n"
        "• [B]Puntuaciones corregidas:[/B] Los porcentajes de coincidencia ya no superan el 100%.\n"
        "• [B]Elementum:[/B] Ahora muestra aviso si Elementum no está instalado en vez de no hacer nada.\n\n"
        "------------------------------------------------\n"
        "[B]¿CÓMO FUNCIONA?[/B]\n"
        "EspaDaily es un explorador de catálogos. Tú navegas por los menús de Atresplayer, RTVE o Mediaset y, al elegir un contenido, el addon [B]busca automáticamente[/B] enlaces públicos en internet que coincidan.\n\n"
        "------------------------------------------------\n"
        "[B]HERRAMIENTAS PRINCIPALES[/B]\n\n"
        "• [B]Mis Favoritos:[/B] Guarda programas o series para acceder rápido. Pulsa clic derecho en cualquier ítem y elige 'Añadir a Favoritos'.\n"
        "• [B]Historial:[/B] Guarda tus últimas 50 búsquedas automáticamente.\n"
        "• [B]Instantáneas:[/B] Crea una copia de seguridad local de TODOS los menús del addon. Útil para navegar si falla internet o los servidores.\n"
        "• [B]Mis Descargas:[/B] Gestiona los vídeos que hayas guardado localmente.\n\n"
        "------------------------------------------------\n"
        "[B]GUÍA DE OPCIONES AVANZADAS[/B]\n\n"
        "• [B]Contexto Completo:[/B] Es la opción más importante. Define qué texto se busca en internet.\n"
        "   - [I]Desactivado:[/I] Busca solo el título del capítulo (Ej: 'Capítulo 1').\n"
        "   - [I]Nivel 1 (Recomendado):[/I] Busca Serie + Capítulo (Ej: 'Cuéntame Capítulo 1').\n"
        "   - [I]Nivel 2/MAX:[/I] Añade más datos de la ruta para búsquedas muy específicas.\n\n"
        "• [B]Priorizar Ajuste vs Duración:[/B]\n"
        "   - [I]Duración:[/I] Prefiere vídeos largos (evita clips cortos).\n"
        "   - [I]Ajuste:[/I] Prefiere títulos que coincidan exactamente, aunque sean cortos.\n\n"
        "• [B]Filtro Anti-Trailers:[/B] Oculta automáticamente vídeos de menos de X minutos.\n\n"
        "• [B]Filtro Temporal:[/B] Decide si prefieres ver primero los resultados más nuevos (Reciente) o los que mejor coinciden (Relevancia).\n\n"
        "• [B]Control de Caché:[/B]\n"
        "   - [I]Apagado:[/I] Siempre carga de internet (más lento, menos espacio).\n"
        "   - [I]Híbrido:[/I] Guarda los menús en disco para que navegar sea instantáneo.\n\n"
        "• [B]Otras Utilidades:[/B]\n"
        "   - [I]Refrescar:[/I] Recarga el addon si notas que algún menú no se actualiza.\n"
        "   - [I]Backup:[/I] Exporta tu historial e instantáneas a un archivo ZIP para llevarlos a otro Kodi.\n"
        "   - [I]Modo Debug:[/I] Actívalo solo si tienes problemas graves para generar un registro de errores.\n"
        "   - [I]Borrar Caché:[/I] Elimina datos temporales. Úsalo si tienes problemas de espacio o errores visuales.\n\n"
        "------------------------------------------------\n"
        "¡Que disfrutes de EspaDaily v2!"
    )
    xbmcgui.Dialog().textviewer("Guía y Notas v2.0.1", t)

def _version_notes_v1():
    t = (
        "[B]GUÍA DE USUARIO & NOTAS V1.0.0[/B]\n\n"
        "¡Bienvenido a EspaDaily! Aquí tienes todo lo que necesitas saber para sacarle el máximo partido.\n\n"
        "------------------------------------------------\n"
        "[B]¿CÓMO FUNCIONA?[/B]\n"
        "EspaDaily es un explorador de catálogos. Tú navegas por los menús de Atresplayer, RTVE o Mediaset y, al elegir un contenido, el addon [B]busca automáticamente[/B] enlaces públicos en internet que coincidan.\n\n"
        "------------------------------------------------\n"
        "[B]HERRAMIENTAS PRINCIPALES[/B]\n\n"
        "• [B]Mis Favoritos:[/B] Guarda programas o series para acceder rápido.\n"
        "• [B]Historial:[/B] Guarda tus últimas 50 búsquedas automáticamente.\n"
        "• [B]Instantáneas:[/B] Copia de seguridad local de los menús del addon.\n"
        "• [B]Mis Descargas:[/B] Gestiona los vídeos guardados localmente.\n\n"
        "------------------------------------------------\n"
        "¡Que disfrutes de esta primera versión!"
    )
    xbmcgui.Dialog().textviewer("Notas v1.0.0", t)

def _manual_search():
    if core_settings.is_advanced_search_active():
        _advanced_search_menu()
        return

    kb = xbmc.Keyboard('', 'Introduce el nombre a buscar')
    kb.doModal()
    if kb.isConfirmed():
        q = kb.getText()
        if q:
            _add_to_history(q)
            _lfd(q, "", nh=True)

def _get_movies_list():
    return [
        "Avatar", "Vengadores: Endgame", "Avatar: El sentido del agua", "Titanic", "Star Wars: El despertar de la fuerza",
        "Vengadores: Infinity War", "Spider-Man: No Way Home", "Jurassic World", "El rey león", "Los Vengadores",
        "Fast & Furious 7", "Top Gun: Maverick", "Frozen II", "Barbie", "Vengadores: La era de Ultrón",
        "Super Mario Bros.: La película", "Black Panther", "Harry Potter y las Reliquias de la Muerte - Parte 2",
        "Star Wars: Los últimos Jedi", "Jurassic World: El reino caído", "Frozen", "La bella y la bestia",
        "Los Increíbles 2", "El destino de los furiosos", "Iron Man 3", "Minions", "Capitán América: Civil War",
        "Aquaman", "El Señor de los Anillos: El retorno del Rey", "Spider-Man: Lejos de casa", "Capitana Marvel",
        "Transformers: El lado oscuro de la luna", "Skyfall", "Transformers: La era de la extinción",
        "El caballero oscuro: La leyenda renace", "Joker", "Star Wars: El ascenso de Skywalker", "Toy Story 4",
        "Toy Story 3", "Piratas del Caribe: El cofre del hombre muerto", "El rey león (1994)", "Buscando a Dory",
        "Star Wars: La amenaza fantasma", "Alicia en el país de las maravillas", "Zootrópolis", "Harry Potter y la piedra filosofal",
        "Gru, mi villano favorito 3", "Buscando a Nemo", "Harry Potter y la Orden del Fénix", "Harry Potter y el misterio del príncipe",
        "El Señor de los Anillos: Las dos torres", "Shrek 2", "Bohemian Rhapsody", "El Señor de los Anillos: La comunidad del anillo",
        "Harry Potter y las Reliquias de la Muerte - Parte 1", "El Hobbit: Un viaje inesperado", "El caballero oscuro",
        "Jumanji: Bienvenidos a la jungla", "Harry Potter y el cáliz de fuego", "Spider-Man 3", "Transformers: La venganza de los caídos",
        "Spider-Man: Homecoming", "Ice Age 3: El origen de los dinosaurios", "Ice Age 4: La formación de los continentes",
        "El libro de la selva", "Batman v Superman: El amanecer de la justicia", "El Hobbit: La desolación de Smaug",
        "El Hobbit: La batalla de los cinco ejércitos", "Thor: Ragnarok", "Guardianes de la Galaxia Vol. 2",
        "Inside Out (Del revés)", "Venom", "Thor: Love and Thunder", "Deadpool 2", "Deadpool", "Star Wars: La venganza de los Sith",
        "Spider-Man", "Wonder Woman", "Independence Day", "Animales fantásticos y dónde encontrarlos", "Shrek Tercero",
        "Coco", "Jumanji: Siguiente nivel", "Harry Potter y la cámara secreta", "Star Wars: Una nueva esperanza",
        "ET El extraterrestre", "Misión Imposible: Fallout", "2012", "Indiana Jones y el reino de la calavera de cristal",
        "Fast & Furious 6", "Piratas del Caribe: En el fin del mundo", "El código Da Vinci", "X-Men: Días del futuro pasado",
        "Madagascar 3: De marcha por Europa", "Las crónicas de Narnia: El león, la bruja y el armario", "Man of Steel",
        "Monstruos University", "Matrix Reloaded", "Up", "Gravity", "Capitán América: El Soldado de Invierno",
        "La saga Crepúsculo: Amanecer - Parte 2", "La saga Crepúsculo: Amanecer - Parte 1", "La saga Crepúsculo: Luna nueva",
        "La saga Crepúsculo: Eclipse", "Forrest Gump", "El sexto sentido", "Interestelar", "Origen", "Gladiator",
        "Salvar al soldado Ryan", "La lista de Schindler", "El Padrino", "El Padrino Parte II", "Cadena perpetua",
        "Pulp Fiction", "El club de la lucha", "Matrix", "Goodfellas (Uno de los nuestros)", "Seven", "El silencio de los corderos",
        "La vida es bella", "Ciudad de Dios", "El viaje de Chihiro", "Parásitos", "Psicosis", "Casablanca",
        "El bueno, el feo y el malo", "12 hombres sin piedad", "La milla verde", "El gran dictador", "Cinema Paradiso",
        "Regreso al futuro", "Terminator 2: El juicio final", "Alien, el octavo pasajero", "Apocalypse Now",
        "Django desencadenado", "El resplandor", "WALL-E", "La princesa Mononoke", "Oldboy", "Amélie", "El laberinto del fauno"
    ]

"""
SISTEMA DE MENSAJES / AVISOS (messages.json)
============================================

Este sistema comprueba si hay novedades en el archivo "messages.json" de mi GitHub
y muestra una ventana emergente al usuario cuando entra al addon.

Configuración en messages.json:
-------------------------------
1. "id": ¡IMPORTANTE! Es el identificador del mensaje (ej: "aviso_v2").
   - El addon guarda qué IDs ya ha visto el usuario.
   - Para que salga un mensaje NUEVO, cambiar el "id" (ej: de "aviso_v1" a "aviso_v2").
   
2. "title": El título de la ventana emergente.

3. "message": El texto del aviso. Usa \n para saltos de línea.

4. "repeat": Cuántas veces se mostrará este mensaje al usuario.
   - 1  -> Se muestra solo la primera vez que entre (y nunca más).
   - 3  -> Se muestra las primeras 3 veces (para asegurar que lo lea).
   - -1 -> Se muestra SIEMPRE (infinito) cada vez que entre.
   - 0  -> Mensaje desactivado (no lo muestra nadie).

Ejemplo:
  {
    "id": "noticia_importante_enero",
    "title": "Mantenimiento",
    "message": "Mañana habrá cortes por mantenimiento.",
    "repeat": 1
  }
"""
def _check_messages():
    # Comprobar si hay mensajes remotos para mostrar
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    sf = os.path.join(p, 'messages_state.json')
    
    try:
        r = requests.get(_MESSAGES_URL, timeout=5)
        # Fail Open: Si no hay fichero o error, no hacemos nada y seguimos
        if r.status_code != 200: return
        
        data = r.json()
        
        # Soportar formato viejo (objeto unico) y formato nuevo (lista)
        if isinstance(data, dict) and "messages" in data:
            msgs = data["messages"]
        elif isinstance(data, list):
            msgs = data
        else:
            msgs = [data] # Treat as single message object
            
        # Cargar estado local (cuantas veces se ha visto cada ID)
        st = {}
        if os.path.exists(sf):
            try:
                with open(sf, 'r', encoding='utf-8') as f: st = json.load(f)
            except Exception: pass
            
        params_changed = False
        
        for msg in msgs:
            mid = msg.get("id")
            # Repeticion por defecto = 1 si no existe
            mrep = msg.get("repeat", 1) 
            
            # Si no hay ID o repeat es 0, saltamos este mensaje
            if not mid or mrep == 0: continue
            
            # Vemos cuantas veces ha visto este mensaje concreto
            views = st.get(mid, 0)
            
            show_it = False
            if mrep == -1: show_it = True    # Siempre
            elif views < mrep: show_it = True # Aun no ha llegado al limite
            
            if show_it:
                # Mostrar Dialogo
        
                body = msg.get("text") or msg.get("message", "")
                title = msg.get("title", "Aviso EspaDaily")
                
                # Usar Dialog().ok para tener botón de aceptar/cerrar
        
                color = msg.get("color", "white")
                formatted_text = f"[COLOR {color}][B]{title}[/B][/COLOR]\n\n{body}"
                
                xbmcgui.Dialog().ok("Aviso EspaDaily", formatted_text)
                
                # Incrementar contador y guardar
                st[mid] = views + 1
                params_changed = True
        
        if params_changed:
            with open(sf, 'w', encoding='utf-8') as f: json.dump(st, f)
            
    except Exception as e:
        _log_error(f"Error checking messages: {str(e)}")

# --- Cumplimiento legal y control remoto ---

def _get_legal_settings_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'legal_settings.json')

def _load_legal_settings():
    f = _get_legal_settings_path()
    if not os.path.exists(f):
        return {}
    try:
        with open(f, 'r', encoding='utf-8') as fp:
            return json.load(fp)
    except (json.JSONDecodeError, IOError):
        return {}

def _save_legal_settings(data):
    try:
        with open(_get_legal_settings_path(), 'w', encoding='utf-8') as fp:
            json.dump(data, fp, ensure_ascii=False)
    except IOError:
        pass

def _load_connector_blocking():
    global connector
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        if _ensure_connector():
            dev_flag = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')
            if os.path.exists(dev_flag):
                import importlib
                connector = importlib.import_module('connector')
            else:
                connector = _load_connector_module()
    except Exception as e:
        xbmc.log(f"[EspaDaily] Error cargando connector: {e}", xbmc.LOGERROR)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    return connector is not None


def _require_connector():
    """Asegura que `connector` está cargado, pasando por el gate legal si hace falta.
    Devuelve True si está listo para usar, False si la accion debe abortar."""
    if connector is not None:
        return True
    return _check_legal_compliance()


_CONNECTOR_DOWNLOAD_FAILED_MSG = (
    "No se pudo descargar el módulo de conexión.\n\n"
    "Comprueba tu conexión a Internet y vuelve a intentarlo más tarde."
)


class LegalScrollDialog(xbmcgui.WindowXMLDialog):
    def onInit(self):
        try:
            textbox = self.getControl(1)
            textbox.setText(getattr(self, '_legal_text', ''))
            textbox.autoScroll(2000, 4500, 0)
        except Exception as e:
            xbmc.log("[EspaDaily] LegalScrollDialog onInit error: {0}".format(e), xbmc.LOGWARNING)

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_STOP):
            self.close()

    def onClick(self, controlId):
        if controlId == 10:
            self.close()


def _check_legal_compliance():
    """Verifica que el usuario haya aceptado los terminos legales.
    Devuelve True si puede continuar, False si debe bloquearse."""
    global connector
    cfg = _load_legal_settings()
    if cfg.get('legal_accepted_v2', False):
        if connector is None:
            if not _load_connector_blocking():
                xbmcgui.Dialog().ok("EspaDaily", _CONNECTOR_DOWNLOAD_FAILED_MSG)
                return False
        return True

    addon = xbmcaddon.Addon()
    legal_path = os.path.join(addon.getAddonInfo('path'), 'AVISO_LEGAL.txt')
    legal_text = "[B]No se encontró el archivo AVISO_LEGAL.txt[/B]"
    if os.path.exists(legal_path):
        try:
            with open(legal_path, 'r', encoding='utf-8') as f:
                legal_text = f.read()
        except IOError:
            pass

    try:
        dlg = LegalScrollDialog('dialog_legal.xml', addon.getAddonInfo('path'), 'Default', '1080i')
        dlg._legal_text = legal_text
        dlg.doModal()
        del dlg
    except Exception as e:
        xbmc.log("[EspaDaily] LegalScrollDialog fallo, usando textviewer: {0}".format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().textviewer("Aviso Legal y Terminos de Uso", legal_text)

    prompt_msg = (
        "[COLOR red][B]CONSENTIMIENTO REQUERIDO[/B][/COLOR]\n\n"
        "¿Confirmas haber leído el Aviso Legal y aceptas voluntariamente "
        "la política integral de uso de EspaDaily?"
    )
    user_accepts = xbmcgui.Dialog().yesno(
        "Términos y Condiciones",
        prompt_msg,
        yeslabel="SÍ, ACEPTO",
        nolabel="RECHAZAR"
    )

    if user_accepts:
        cfg['legal_accepted_v2'] = True
        _save_legal_settings(cfg)
        verify_cfg = _load_legal_settings()
        if not verify_cfg.get('legal_accepted_v2', False):
            xbmcgui.Dialog().ok("Error del Sistema", "No se pudo guardar el consentimiento en el disco.\nRevisa el espacio y los permisos de la carpeta profile.")
            return False

        if not _load_connector_blocking():
            xbmcgui.Dialog().ok("EspaDaily", _CONNECTOR_DOWNLOAD_FAILED_MSG)
            return False
        return True

    xbmcgui.Dialog().notification("EspaDaily", "Acceso denegado. Términos rechazados.", xbmcgui.NOTIFICATION_WARNING)
    return False

def _check_validity():
    """Comprueba el estado operativo del addon via status.json remoto.
    Implementa cache de 7 dias y fallback local. Fail-open ante errores de red."""
    addon = xbmcaddon.Addon()
    p = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    cache_file = os.path.join(p, 'validity_cache.json')

    # Leer cache local para evitar peticiones innecesarias
    try:
        if os.path.exists(cache_file):
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache = json.load(f)
            elapsed = time.time() - cache.get('last_check', 0)
            if elapsed < 604800:  # 7 dias en segundos
                if cache.get('disabled', False):
                    return False
                return True
    except (json.JSONDecodeError, IOError):
        pass

    # Intentar lectura remota
    data = None
    try:
        r = requests.get(_STATUS_URL, timeout=10)
        if r.status_code == 200:
            data = r.json()
    except Exception:
        pass

    # Fallback a archivo local si remoto falla
    if not data:
        local_path = os.path.join(addon.getAddonInfo('path'), 'status.json')
        if os.path.exists(local_path):
            try:
                with open(local_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            except (json.JSONDecodeError, IOError):
                pass

    # Si no se pudo obtener datos de ninguna fuente, fail-open
    if not data:
        return True

    # Verificar estado de activacion
    if not data.get('allowed', True):
        msg = data.get('message', "Este addon ha sido desactivado por el desarrollador.")
        xbmcgui.Dialog().ok("EspaDaily", msg)
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump({'last_check': time.time(), 'disabled': True}, f)
        except IOError:
            pass
        return False

    # Verificar version minima
    min_v = data.get('min_version', '0.0.0')
    cur_v = addon.getAddonInfo('version')
    def _parse_version(v):
        return [int(x) for x in v.replace('v', '').split('.') if x.isdigit()]
    if _parse_version(cur_v) < _parse_version(min_v):
        msg = data.get('message', f"Tu versión ({cur_v}) es anterior a la mínima requerida ({min_v}). Actualiza el addon.")
        xbmcgui.Dialog().ok("EspaDaily - Actualización Necesaria", msg)
        return False


    try:
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump({'last_check': time.time(), 'disabled': False}, f)
    except IOError:
        pass
    return True

def _show_legal_text():
    """Muestra el texto completo del AVISO_LEGAL.txt."""
    addon = xbmcaddon.Addon()
    legal_path = os.path.join(addon.getAddonInfo('path'), 'AVISO_LEGAL.txt')
    if os.path.exists(legal_path):
        try:
            with open(legal_path, 'r', encoding='utf-8') as f:
                text = f.read()
            xbmcgui.Dialog().textviewer("Aviso Legal - EspaDaily", text)
        except IOError:
            xbmcgui.Dialog().ok("Error", "No se pudo leer el archivo de aviso legal.")
    else:
        xbmcgui.Dialog().ok("Error", "Archivo AVISO_LEGAL.txt no encontrado.")

def _revoke_legal():
    """Revoca la aceptacion de terminos. Borra el connector descargado y la cache
    asociada para que en la siguiente aceptacion se vuelva a descargar."""
    global connector
    if xbmcgui.Dialog().yesno(
        "Revocar Aceptación",
        "¿Seguro que quieres revocar tu aceptación de los términos?\n\n"
        "Se eliminará el módulo de conexión descargado. La próxima vez que "
        "abras el addon tendrás que aceptar de nuevo y se descargará otra vez."
    ):
        cfg = _load_legal_settings()
        cfg['legal_accepted_v2'] = False
        _save_legal_settings(cfg)
        for _path in (_get_sys_path(), _get_loader_cache_path()):
            try:
                if os.path.exists(_path):
                    os.remove(_path)
            except OSError as _e:
                xbmc.log(f"[EspaDaily] No se pudo borrar {_path}: {_e}", xbmc.LOGWARNING)
        connector = None
        xbmcgui.Dialog().notification(
            "EspaDaily", "Aceptación revocada", xbmcgui.NOTIFICATION_INFO
        )


def _get_top_movies_cache_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, "top_movies_thumbs.json")

def _load_top_movies_cache():
    path = _get_top_movies_cache_path()
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception: pass
    return {}

def _fetch_tmdb_poster(title):
    try:
        r = requests.get(
            "https://api.themoviedb.org/3/search/movie",
            params={"api_key": core_settings._ESPADAILY_TMDB_API_KEY, "query": title, "language": "es-ES"},
            timeout=8
        )
        if r.status_code == 200:
            results = r.json().get("results", [])
            if results and results[0].get("poster_path"):
                return f"https://image.tmdb.org/t/p/w342{results[0]['poster_path']}"
    except Exception:
        pass
    return None


def _top_movies(page):
    try: page = int(page)
    except (ValueError, TypeError): page = 1
    per_page = 50
    movies = _get_movies_list()
    total = len(movies)
    start = (page - 1) * per_page
    end = start + per_page
    page_items = movies[start:end]

    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')
    af = addon.getAddonInfo('fanart')

    # --- SISTEMA DE CACHÉ DE IMÁGENES ---
    cache_path = _get_top_movies_cache_path()
    cache_file_exists = os.path.exists(cache_path)
    cache = _load_top_movies_cache()
    user_cleared = cache_file_exists and len(cache) == 0

    if not user_cleared:
        # Auto-cargar solo si el usuario no borró la caché intencionalmente
        missing = [m for m in page_items if m not in cache]
        if missing:
            try:
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
                    futures = {ex.submit(_fetch_tmdb_poster, m): m for m in missing}
                    for fut in concurrent.futures.as_completed(futures, timeout=15):
                        m = futures[fut]
                        try:
                            url = fut.result()
                            if url:
                                cache[m] = url
                        except Exception:
                            pass
                if any(m in cache for m in missing):
                    with open(cache_path, 'w', encoding='utf-8') as f:
                        json.dump(cache, f)
            except Exception as e:
                xbmc.log(f"[EspaDaily] TMDB fetch paralelo: {e}", xbmc.LOGWARNING)

    has_cache = len(cache) > 0

    if user_cleared:
        # El usuario borró la caché: mostrar botón manual para recargar si quiere
        li = xbmcgui.ListItem(label="[COLOR yellow][B]Descargar carátulas[/B][/COLOR]")
        li.setArt({'icon': 'DefaultAddonService.png'})
        li.setInfo('video', {'plot': "Descarga las carátulas de todas las películas y las guarda permanentemente."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cache_top_movies_covers"), listitem=li, isFolder=False)
    elif has_cache:
        li = xbmcgui.ListItem(label="[COLOR red][B]Borrar carátulas guardadas[/B][/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        li.setInfo('video', {'plot': "Elimina las fotos guardadas para liberar espacio. No se recargarán automáticamente."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="clear_top_movies_cache"), listitem=li, isFolder=False)

    for m in page_items:
        li = xbmcgui.ListItem(label=m)

        thumb = cache.get(m, ai)

        _genre   = _get_movie_genre(m)
        _details = _get_movie_details(m)
        _plot = (
            f"[COLOR gold][B]Género:[/B][/COLOR] [COLOR deepskyblue]{_genre}[/COLOR]  |  "
            f"[COLOR gold][B]Año:[/B][/COLOR] [COLOR deepskyblue]{_details[0]}[/COLOR]  |  "
            f"[COLOR gold][B]Nota IMDb:[/B][/COLOR] [COLOR deepskyblue]{_details[1]}[/COLOR]\n"
            f"[COLOR gold][B]Director:[/B][/COLOR] [COLOR deepskyblue]{_details[2]}[/COLOR]\n\n"
            f"{_get_movie_plot(m)}"
        )

        li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb, 'fanart': af})
        li.setInfo('video', {
            'title': m,
            'plot': _plot,
            'genre': _genre,
            'year': int(_details[0]),
            'rating': float(_details[1]),
            'director': _details[2]
        })
        
        # Context Menu
        cm = []
        cm.append(("Buscar en webs de torrent", f"RunPlugin({_u(action='elementum_search', q=m)})"))
        if core_settings.is_palantir_installed() and core_settings.is_palantir_integration_enabled() and not core_settings.are_external_integrations_disabled():
            cm.append(("Buscar en Palantir 3", f"RunPlugin({_u(action='palantir_search', q=m)})"))
        
        # Favoritos - Construir URL antes para evitar problemas con caracteres especiales
        fav_url = _u(action='add_favorite', title=m, fav_url=m, icon=thumb, platform='Legendarias', fav_action='lfr', params=json.dumps({'q': m}))
        cm.append(("Añadir a Mis Favoritos", f"RunPlugin({fav_url})"))
        li.addContextMenuItems(cm)
        
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_alt_prompt", q=m, ot=thumb, mode="movie"), listitem=li, isFolder=False)
    
    if end < total:
        li = xbmcgui.ListItem(label=f"Siguiente Página ({page + 1}) >>")
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="top_movies", page=page+1), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _cache_top_movies_covers():
    if not xbmcgui.Dialog().yesno("EspaDaily", 
        "¿Quieres descargar las carátulas de las 130+ películas top?\n\n"
        "Esto hará que la sección se vea mucho mejor pero [COLOR yellow]tardará un poco más en cargar[/COLOR]."):
        return

    movies = _get_movies_list()
    cache = {}
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaDaily", "Descargando carátulas Top...")
    
    total = len(movies)
    for i, m in enumerate(movies):
        if pDialog.iscanceled(): break
        
        percent = int((float(i) / total) * 100)
        pDialog.update(percent, f"Buscando ({i}/{total}): {m}")
        
        try:
            cover = _fetch_tmdb_poster(m)
            if cover:
                cache[m] = cover
        except Exception: pass
        
    pDialog.close()
    
    if cache:
        with open(_get_top_movies_cache_path(), 'w', encoding='utf-8') as f:
            json.dump(cache, f)
        xbmcgui.Dialog().notification("EspaDaily", "Carátulas guardadas correctamente", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")

def _clear_top_movies_cache():
    try:
        with open(_get_top_movies_cache_path(), 'w', encoding='utf-8') as f:
            json.dump({}, f)
        xbmcgui.Dialog().notification("EspaDaily", "Carátulas eliminadas. No se recargarán automáticamente.", xbmcgui.NOTIFICATION_INFO, 4000)
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmc.log(f"[EspaDaily] Error borrando caché carátulas: {e}", xbmc.LOGWARNING)

def _ls(cid, page=0):
    # Caché híbrida
    if _is_frozen_active() and page == 0:
        d = _load_cache(f"atres_{cid}")
        if d:
            _process_atres_items(d, cid, page=0)
            return

    items = connector.fetch_atres_list(cid, page=page)
    if not items:
        if page == 0:
            xbmcgui.Dialog().ok("Error", "No se pudo obtener la lista de contenidos.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    # Guardar caché
    if _get_cache_mode() > 0 and page == 0:
        _save_cache(f"atres_{cid}", items)

    _process_atres_items(items, cid, page=page)

def _process_atres_items(items, cid, page=0):
    addon = xbmcaddon.Addon(); ai = addon.getAddonInfo('icon'); af = addon.getAddonInfo('fanart')
    for i in items:
        try:
            tt = i.get("title", "Sin título"); im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical"); th = _fix_img(tr)
            if not th:
                try: dr = _sr(tt); th = dr[0].get("thumbnail_720_url") or dr[0].get("thumbnail_360_url") if dr else ai
                except Exception: th = ai
            if not th: th = ai
            fa = th if th != ai else af
            lk = i.get("link", {}); au = lk.get("href")
            if not au: continue
            tag = i.get("tagType", "")
            is_open = i.get("open", False)
            is_prem = tag in ("EXCLUSIVE", "ORIGINAL", "PREVIEW") and not is_open
            label = f"{tt} [COLOR gray][ATP+?][/COLOR]" if is_prem else tt
            li = xbmcgui.ListItem(label=label); li.setArt({'thumb': th, 'icon': th, 'fanart': fa})
            li.setInfo('video', {'title': tt, 'plot': i.get('description', '')})


            _add_fav_cm(li, tt, "atresplayer", "fs", {"au": au, "st": tt, "sth": th})
            

            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs", au=au, st=tt, sth=th), listitem=li, isFolder=True)

        except Exception as e:
            _log_error(f"Error al procesar item Atresplayer: {e}")
            continue

    # Paginacion: si hay items suficientes, probablemente hay mas paginas
    if len(items) >= 10:
        next_page = page + 1
        li = xbmcgui.ListItem(label="[COLOR cyan][B]>> Página Siguiente ({0})[/B][/COLOR]".format(next_page))
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls", cid=cid, page=next_page), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)

def _human_size(n):
    if n < 1024:
        return "{0} B".format(n)
    if n < 1024 * 1024:
        return "{0:.1f} KB".format(n / 1024)
    return "{0:.1f} MB".format(n / (1024 * 1024))


def _cleanup_menu():
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)

    li = xbmcgui.ListItem(label="[COLOR yellow]Limpiar cache (recomendado)[/COLOR]")
    li.setArt({'icon': _mi('adv_cache.png')})
    li.setInfo('video', {'plot': "Borra archivos de cache temporales como el catalogo de programas, la guia EPG, miniaturas TMDB y metadatos de FilmAffinity, SensaCine y CineMeta.\n\nNo afecta a tus favoritos, historial, Trakt ni configuracion.\n\nEn la mayoria de ocasiones no merece la pena, la cantidad de espacio que se libera es minuscula."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cleanup_caches"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR cyan]Compactar base de metadatos[/COLOR]")
    li.setArt({'icon': 'DefaultHardDisk.png'})
    li.setInfo('video', {'plot': "Elimina las entradas caducadas (mas de 30 dias) de la base de datos de metadatos TMDB y compacta el archivo.\n\nMantiene los datos recientes y libera el espacio que ocupaban los caducados."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="vacuum_metadata_db"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR red]Restablecer addon (factory reset)[/COLOR]")
    li.setArt({'icon': 'DefaultIconError.png'})
    li.setInfo('video', {'plot': "BORRA TODOS LOS DATOS DEL ADDON y deja la instalacion como recien instalada.\n\nSe pierden los favoritos, el historial completo, Trakt, las categorias propias, los canales DM guardados, los marcadores y la configuracion completa.\n\nUsalo solo si el addon esta corrupto o quieres empezar de cero. Esta accion NO se puede deshacer."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="clear_cache"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _cleanup_caches():
    if not xbmcgui.Dialog().yesno(
        "EspaDaily - Limpieza",
        "Borrar los archivos de cache temporales?\n\nNo afecta a tus favoritos, historial, Trakt ni configuracion."
    ):
        return

    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    freed = 0

    cache_files = [
        'epg_texto_cache.json',
        'espadaily_cinemeta_cache.json',
        'espadaily_fa_cache.json',
        'espadaily_sc_cache.json',
        'espadaily_tmdb_lists_cache.json',
        'top_movies_thumbs.json',
    ]
    for fn in cache_files:
        fp = os.path.join(profile, fn)
        if os.path.exists(fp):
            try:
                freed += os.path.getsize(fp)
                os.remove(fp)
            except OSError:
                pass

    api_cache_dir = os.path.join(profile, 'api_cache')
    if os.path.isdir(api_cache_dir):
        for fn in os.listdir(api_cache_dir):
            if fn.endswith('.json'):
                fp = os.path.join(api_cache_dir, fn)
                try:
                    freed += os.path.getsize(fp)
                    os.remove(fp)
                except OSError:
                    pass

    ytdlp_dir = os.path.join(profile, 'packages', 'yt_dlp')
    if os.path.isdir(ytdlp_dir):
        try:
            import shutil
            for root, _dirs, files in os.walk(ytdlp_dir):
                for f in files:
                    try:
                        freed += os.path.getsize(os.path.join(root, f))
                    except OSError:
                        pass
            shutil.rmtree(ytdlp_dir, ignore_errors=True)
        except Exception:
            pass

    active_ids = None
    try:
        lists = core_settings.get_trakt_lists()
        if lists is not None:
            active_ids = {str(l.get('id')) for l in lists if l.get('id') is not None}
    except Exception:
        active_ids = None
    if active_ids is not None and os.path.isdir(profile):
        for fn in os.listdir(profile):
            if fn.startswith('trakt_thumbs_') and fn.endswith('.json'):
                list_id = fn[len('trakt_thumbs_'):-len('.json')]
                if list_id not in active_ids:
                    fp = os.path.join(profile, fn)
                    try:
                        freed += os.path.getsize(fp)
                        os.remove(fp)
                    except OSError:
                        pass

    xbmcgui.Dialog().ok(
        "EspaDaily - Limpieza",
        "Cache borrada.\n\nSe han liberado {0}.".format(_human_size(freed))
    )
    xbmc.executebuiltin("Container.Refresh")


def _vacuum_metadata_db_action():
    if not xbmcgui.Dialog().yesno(
        "EspaDaily - Compactar metadatos",
        "Eliminar entradas caducadas (mas de 30 dias) y compactar la base de datos?\n\nLos metadatos recientes se conservan."
    ):
        return
    try:
        import metadata_enricher
        deleted, freed = metadata_enricher.prune_and_vacuum()
        xbmcgui.Dialog().ok(
            "EspaDaily - Compactar metadatos",
            "Se han borrado {0} entradas y liberado {1}.".format(deleted, _human_size(freed))
        )
    except Exception as e:
        xbmcgui.Dialog().ok("EspaDaily - Error", "No se pudo compactar.\n\n{0}".format(str(e)))
    xbmc.executebuiltin("Container.Refresh")


def _clear_cache():
    if not xbmcgui.Dialog().yesno(
        "EspaDaily - Restablecer addon",
        "Vas a BORRAR TODOS LOS DATOS DEL ADDON y dejarlo como recien instalado.\n\nSe perderan los favoritos, el historial, Trakt, las categorias propias, los marcadores, los canales y la configuracion completa.\n\nEsta accion NO se puede deshacer. Continuar?",
        nolabel="Cancelar",
        yeslabel="Restablecer"
    ):
        return

    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if os.path.exists(p):
        for f in os.listdir(p):
            if f.endswith(".json"):
                try: os.remove(os.path.join(p, f))
                except Exception: pass
    sys_path = _get_sys_path()
    if os.path.exists(sys_path):
        try: os.remove(sys_path)
        except Exception: pass
    xbmcgui.Dialog().notification("EspaDaily", "Addon restablecido", xbmcgui.NOTIFICATION_INFO)
    # Refrescar para reflejar cambios (ej: debug desactivado)
    xbmc.executebuiltin("Container.Refresh")

def _fs(au, st, sth="", pu=""):
    if pu and au == pu: _fb(st, sth); return
    d = connector.fetch_atres_format(au)
    if not d: _fb(st, sth); return
    ss = d.get("seasons", []); rw = d.get("rows", []); id_ = d.get("items", []) or d.get("itemRows", [])
    fmt_prem = d.get("premium", False)
    erh = None
    for ro in rw:
        if ro.get("type") == "EPISODE": erh = ro.get("href"); break
    if erh: _lfr(erh, st, sth, fmt_prem); return
    if id_: _rel(id_, st, sth, fmt_prem); return
    if len(ss) > 1:
        for s in ss:
            t = s.get("title", "Temporada"); sh = s.get("link", {}).get("href")
            if sh and sh != au:
                li = xbmcgui.ListItem(label=t); li.setArt({'thumb': sth, 'icon': sth})
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs", au=sh, st=st, sth=sth, pu=au), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1])); return
    elif len(ss) == 1:
        sh = ss[0].get("link", {}).get("href")
        if sh and sh != au: _fs(sh, st, sth, pu=au); return
    _fb(st, sth)

def _fb(st, sth):
    li = xbmcgui.ListItem(label=f"Buscar '{st}' en Internet..."); li.setArt({'thumb': sth, 'icon': sth})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=st, ot=sth), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _lfr(ru, st, sth="", fmt_prem=False):
    items = connector.fetch_atres_episodes(ru)
    if items:
        _rel(items, st, sth, fmt_prem)
    else:
        _fb(st, sth)

def _ep_dialog(q, ot, t="", eid=""):
    import url_player as _up
    title = urllib.parse.unquote(t) if t else q
    sn_installed = xbmc.getCondVisibility("System.HasAddon({0})".format(_up._SN_ID))
    sn_label = "[B]Reproducir con StreamNinja[/B]" if sn_installed else "[B]Instalar StreamNinja[/B]"
    opts = ["[B]Buscar en internet[/B]", sn_label]
    acts = ["buscar", "sn"]
    _ext_off = core_settings.are_external_integrations_disabled()
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
        opts.append("[COLOR red]Buscar en YouTube[/COLOR]")
        acts.append("youtube")
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
        opts.append("[COLOR FFD2691E]Buscar en webs de torrent[/COLOR]")
        acts.append("elementum")
    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
        opts.append("[COLOR deepskyblue]Buscar en addon Dailymotion (Gujal)[/COLOR]")
        acts.append("dm_gujal")
    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.palantir3)"):
        opts.append("[COLOR orange]Buscar en Palantir[/COLOR]")
        acts.append("palantir")
    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.balandro)"):
        opts.append("[COLOR chartreuse]Buscar en Balandro[/COLOR]")
        acts.append("balandro")
    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.jacktook)"):
        opts.append("[COLOR mediumpurple]Buscar en Jacktook[/COLOR]")
        acts.append("jacktook")
    sel = xbmcgui.Dialog().select(title, opts)
    if sel < 0:
        return
    act = acts[sel]
    if act == "buscar":
        xbmc.executebuiltin("Container.Update({0})".format(_u(action="lfr", q=q, ot=ot)))
    elif act == "sn":
        if _up.streamninja_check_or_install():
            xbmc.log("[EspaDaily] ep_dialog SN eid={0}".format(eid), xbmc.LOGINFO)
            if eid:
                ep_plugin_url = "{0}?action=play_media&url={1}".format(sys.argv[0], urllib.parse.quote(eid, safe=""))
                safe_url = urllib.parse.quote(ep_plugin_url, safe="")
                xbmc.log("[EspaDaily] ep_dialog SN plugin_url={0}".format(ep_plugin_url), xbmc.LOGINFO)
                xbmc.executebuiltin("RunPlugin(plugin://{0}/?action=url_play&url={1})".format(_up._SN_ID, safe_url))
            else:
                xbmc.log("[EspaDaily] ep_dialog SN sin eid, abriendo SN home", xbmc.LOGWARNING)
                _up.streamninja_open_or_install()
    elif act == "elementum":
        kb = xbmc.Keyboard(q, 'Buscar en webs de torrent')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            _search_elementum(kb.getText())
    elif act == "youtube":
        _search_youtube_from_results(q)
    elif act == "dm_gujal":
        _search_dailymotion_gujal(q)
    elif act == "palantir":
        kb = xbmc.Keyboard(q, 'Buscar en Palantir 3')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            _search_palantir(kb.getText())
    elif act == "balandro":
        _search_balandro_from_results(q)
    elif act == "jacktook":
        _search_jacktook_from_results(q)


def _rel(items, st, sth="", fmt_prem=False):
    for i in items:
        tt = i.get("title", "Capítulo"); en = i.get("name", ""); dt = f"{en} - {tt}" if en else tt

        sq = _bi(st, f"{tt} {en}" if en else tt)
        im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical"); th = _fix_img(tr) or sth
        tag = i.get("tagType", "")
        is_open = i.get("open", False)
        is_prem_ep = (tag in ("EXCLUSIVE", "ORIGINAL", "PREVIEW") or fmt_prem) and not is_open
        ep_label = f"{dt} [COLOR gray][ATP+?][/COLOR]" if is_prem_ep else dt
        li = xbmcgui.ListItem(label=ep_label); li.setArt({'thumb': th, 'icon': th, 'fanart': th})
        li.setInfo('video', {'title': dt, 'plot': i.get('description', '')})

        # Menú contextual: añadir a favoritos (episodio individual)
        _add_fav_cm(li, dt, "atresplayer", "lfr", {"q": sq, "ot": th})

        eid = i.get("id", "")
        if not eid:
            h = i.get("link", {}).get("href", "")
            m = re.search(r'/episode/([a-fA-F0-9]{20,30})', h)
            if m: eid = m.group(1)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ep_dialog", q=sq, ot=th, t=urllib.parse.quote(dt), eid=eid), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _clean_title(t):
    # Si hay dos partes separadas por " : ", quedarse con la segunda (suele ser el titulo real)
    if " : " in t: parts = t.split(" : "); t = parts[1] if len(parts[1]) > len(parts[0]) else parts[0]
    return t.strip() # Devolver limpio

def _lfd(q, ot, mode="", extra_params=None, nh=None):
    cq = _clean_title(q)
    rs = []
    
    if mode == "movie":
        # Intentar varias combinaciones para encontrar contenido en español
        variations = [
            f"{cq} pelicula completa castellano",
            f"{cq} pelicula completa español",
            f"{cq} pelicula completa",
            f"{cq} completa español",
            f"{cq} castellano",
            cq # Como ultimo recurso, el titulo limpio a secas
        ]
        
        for v in variations:
            rs = _sr(v, extra_params)
            if rs: break # Si encontramos algo, nos quedamos con ello
            
    elif mode == "exact":
        # Busca exactamente lo que el usuario escribió
        rs = _sr(q, extra_params)

    elif mode == "keywords":
        # Busca solo por palabras clave de más de 3 letras
        kw = " ".join([w for w in re.findall(r'\w+', q) if len(w) > 3])
        if kw: rs = _sr(kw, extra_params)

    else:
        # Logica estandar para series/programas (o User, Long, Short)
        # Si es modo User/Long/Short, el 'q' puede ser el termino de busqueda normal, y 'extra_params' lleva el filtro.
        # Intentamos con titulo limpio primero
        rs = _sr(cq, extra_params) 
        if not rs and cq != q: rs = _sr(q, extra_params) # Intentar con el original si el limpio falla
    
    if not rs and mode not in ["exact", "keywords"]: 
        # Ultimo intento: buscar solo palabras clave (mayores de 3 letras)
        kw = " ".join([w for w in re.findall(r'\w+', q) if len(w) > 3])
        if kw: rs = _sr(kw, extra_params)
    
    # Botón de alternativas de búsqueda al inicio de resultados
    _ext_off_alt = core_settings.are_external_integrations_disabled()
    _has_alt_addons = (
        xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)") or
        xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)") or
        (not _ext_off_alt and xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)")) or
        (not _ext_off_alt and xbmc.getCondVisibility("System.HasAddon(plugin.video.palantir3)"))
    )
    if _has_alt_addons:
        _alt_label = "[COLOR yellow][B]¿No es lo que buscas?[/B][/COLOR]"
    else:
        _alt_label = "[COLOR yellow][B]Editar búsqueda y reintentar[/B][/COLOR]"
    li_alt = xbmcgui.ListItem(label=_alt_label)
    li_alt.setArt({'icon': 'DefaultAddonsSearch.png', 'thumb': 'DefaultAddonsSearch.png'})
    li_alt.setInfo('video', {'plot': "Busca en otros addons instalados o edita tu búsqueda."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_alt_prompt", q=cq, ot=ot), listitem=li_alt, isFolder=False)

    if not rs: 
        xbmcgui.Dialog().notification("EspaDaily", "No se encontraron resultados", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    sr = _gsr(cq, rs, mode)[:25] # Aumentamos un poco el limite para tener mas donde ordenar
    
    if not sr: 

        if xbmcgui.Dialog().yesno("EspaDaily", "No se encontraron coincidencias relevantes.\n\n¿Quieres editar las palabras clave y probar otra vez?"):
             kb = xbmc.Keyboard(q, 'Editar Búsqueda')
             kb.doModal()
             if kb.isConfirmed():
                 nq = kb.getText()
                 if nq:
                     xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=nq, ot=ot)})")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    # GUARDAR RUTA DE EXPLORACIÓN (solo si hay resultados válidos y no viene del historial)
    if not nh:
        exploration_history.add_exploration(q)
    
    min_dur = core_settings.get_min_duration() * 60
    for sc, v in sr:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        
        # FILTRO ESTRICTO DE DURACIÓN
        if min_dur > 0 and du < min_dur: continue
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url") or ot
        
        # En modo pelicula mostramos el titulo completo del video encontrado
        if mode == "movie":
             lb = vt
        else:
             lb = f"{vt} ({int(sc*100)}% match)"

        li = xbmcgui.ListItem(label=lb); li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Subido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        
        # MENU CONTEXTUAL PARA DESCARGAR Y PALANTIR
        cm = []
        if core_settings.is_palantir_installed() and core_settings.is_palantir_integration_enabled() and not core_settings.are_external_integrations_disabled():
            cm.append(("Buscar en Palantir 3", f"RunPlugin({_u(action='palantir_search', q=vt)})"))

        cm.append(("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})"))
        cm.append(("Abrir en el navegador", f"RunPlugin({_u(action='dm_open_browser', url=vi)})"))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="pv", vid=vi, title=urllib.parse.quote(vt)), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _pv(vid, title=""):
    """Gestor principal de reproducción de vídeos Dailymotion."""
    try:
        dm_cfg = _load_dm_settings()
        dm_level = dm_cfg.get('dm_safe_level', 0)
        max_quality = dm_cfg.get('dm_max_quality', 1080)


        d = connector.resolve_video(vid)
        if not d:
            xbmcgui.Dialog().ok("Error", "No se pudo resolver el video.")
            return

        v_title = d.get('title', vid)
        v_thumb = d.get('thumbnail_url') or d.get('thumbnail_360_url', '')
        v_duration = d.get('duration', 0)

        def _record_history():
            try: _add_watch_entry(vid, v_title, thumb=v_thumb, duration=v_duration)
            except Exception: pass

        _is_windows = xbmc.getCondVisibility("System.Platform.Windows")
        
        # Determinar si usamos YT-DLP:
        # - Si el usuario seleccionó Nivel 3 (YT-DLP) explícitamente (cualquier SO)
        # - O si está en "Desactivado" (Nivel 0) en Windows (ya que es el default obligatorio)
        use_ytdlp = (dm_level == 3) or (_is_windows and dm_level == 0)

        if dm_level == 4:
            result = connector.play_dm(vid, dm_level=1, max_quality=max_quality)
            if result and result.get('url'):
                _record_history()
                raw_url = result['url']
                url_part = raw_url.split('|', 1)[0] if '|' in raw_url else raw_url
                headers_part = raw_url.split('|', 1)[1] if '|' in raw_url else ''
                _isa_h = headers_part if headers_part else urllib.parse.urlencode({
                    'User-Agent': "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36",
                    'Referer': "https://www.dailymotion.com/",
                    'Origin': "https://www.dailymotion.com",
                })
                li = xbmcgui.ListItem(path=url_part)
                li.setMimeType(result.get('mime', 'application/x-mpegURL'))
                li.setContentLookup(False)
                li.setProperty("inputstream", "inputstream.adaptive")
                li.setProperty("inputstream.adaptive.manifest_type", "hls")
                li.setProperty("inputstream.adaptive.manifest_headers", _isa_h)
                li.setProperty("inputstream.adaptive.stream_headers", _isa_h)
                subs = result.get('subs')
                if subs and isinstance(subs, list):
                    li.setSubtitles(subs)
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)
            return

        if not use_ytdlp:
            # FLUJO NORMAL / CONNECTOR (Plataformas NO-Windows, o Windows forzado a nivel 1 o 2)
            result = connector.play_dm(vid, dm_level=dm_level, max_quality=max_quality)
            if result and result.get('url'):
                _record_history()
                li = xbmcgui.ListItem(path=result['url'])
                if result.get('mime'):
                    li.setMimeType(result['mime'])
                li.setContentLookup(False)
                subs = result.get('subs')
                if subs and isinstance(subs, list):
                    li.setSubtitles(subs)
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)
                return

            # Fallback a resolve_video básico si play_dm falla silenciosamente por alguna razón extraña
            qs = d.get("qualities") or {}; murl = ""
            if "auto" in qs:
                for s in qs["auto"]:
                    if s.get("type") == "application/x-mpegURL": murl = s.get("url"); break
            if not murl: xbmcgui.Dialog().notification("EspaDaily", "No se encontró stream válido", xbmcgui.NOTIFICATION_ERROR); return
            vs = connector.fetch_hls_variants(murl)
            if not vs:
                _record_history()
                li = xbmcgui.ListItem(path=murl)
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)
                return
            lbs = [v['label'] for v in vs]
            rt = xbmcgui.Dialog().select("Selecciona Calidad", lbs)
            su = vs[rt]['url'] if rt >= 0 else vs[0]['url']
            if rt < 0: xbmcgui.Dialog().notification("EspaDaily", "Reproduciendo máxima calidad...", xbmcgui.NOTIFICATION_INFO)
            _record_history()
            li = xbmcgui.ListItem(path=su)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)

        else:
            # FLUJO YT-DLP AVANZADO: Cascada de Fallbacks
            _dm_ok = False
            dm_web_url = f"https://www.dailymotion.com/video/{vid}"
            
            # Método 1: yt-dlp (Subprocess)
            try:
                import subprocess, json as _json
                # xbmc.log("[EspaDaily] DM Win: Intentando yt-dlp por CLI...", xbmc.LOGINFO)
                xbmcgui.Dialog().notification("EspaDaily", "Resolviendo con yt-dlp...", xbmcgui.NOTIFICATION_INFO, 2000)
                
                _proc = subprocess.run(
                    ['python', '-m', 'yt_dlp', '--dump-json', '--no-download',
                     '--format', 'best[ext=mp4]/best', '--no-playlist', dm_web_url],
                    capture_output=True, text=True, timeout=30, creationflags=0x08000000
                )
                if _proc.returncode == 0 and _proc.stdout.strip():
                    info = _json.loads(_proc.stdout)
                    stream_url = info.get('url', '')
                    if stream_url:
                        _record_history()
                        li = xbmcgui.ListItem(path=stream_url)
                        li.setProperty('IsPlayable', 'true')
                        li.setContentLookup(False)
                        try:
                            # Intentar pasarlo a Kodi como resolución limpia
                            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
                        except Exception:
                            # Direct play si el setResolved falla (fuera de tiempo, etc)
                            xbmc.Player().play(stream_url, li)
                        _dm_ok = True
            except Exception as e:
                # xbmc.log(f"[EspaDaily] DM Win: yt-dlp falló: {e}", xbmc.LOGWARNING)
                pass

            # Método 2: Abrir Navegador
            if not _dm_ok:
                if xbmcgui.Dialog().yesno(
                    "Error Kodi/Windows",
                    "Dailymotion suele bloquear Kodi en plataformas Windows devolviendo errores 403 HTTP.\n\n"
                    "No se pudo resolver el enlace nativamente.\n¿Quieres abrir este episodio en el Navegador Web?\n\n"
                    "[I](Si eliges 'No' forzaremos los últimos fallbacks internos)[/I]",
                    yeslabel="Navegador Web", nolabel="Forzar Kodi"
                ):
                    try:
                        import webbrowser
                        webbrowser.open(dm_web_url)
                        xbmcgui.Dialog().notification("EspaDaily", "Enlace enviado al navegador", xbmcgui.NOTIFICATION_INFO)
                    except Exception:
                        xbmcgui.Dialog().ok("EspaDaily", f"Abre la siguiente URL en tu navegador de internet:\n\n{dm_web_url}")
                    _record_history() # Se cuenta como visto porque lo abrieron externamente
                    _dm_ok = True
            
            # Método 3: Forzar connector local "por si acaso" el CDN lo permite hoy
            if not _dm_ok:
                try:
                    result = connector.play_dm(vid, dm_level=dm_level, max_quality=max_quality)
                    if result and result.get('url'):
                        _record_history()
                        li = xbmcgui.ListItem(path=result['url'])
                        if result.get('mime'): li.setMimeType(result['mime'])
                        li.setContentLookup(False)
                        subs = result.get('subs')
                        if subs and isinstance(subs, list): li.setSubtitles(subs)
                        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)
                        
                        import time as _t; _t.sleep(2)  # Dar tiempo a ver si falla el reproductor
                        if xbmc.Player().isPlaying(): _dm_ok = True
                except Exception:
                    pass

            # Método 4: Addon_DM_Gujal
            if not _dm_ok and xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
                try:
                    dm_plugin_url = f"plugin://plugin.video.dailymotion_com/?url={vid}&mode=playVideo"
                    xbmc.executebuiltin(f'PlayMedia("{dm_plugin_url}")')
                    import time as _t; _t.sleep(3)
                    if xbmc.Player().isPlaying():
                        _record_history()
                        _dm_ok = True
                except Exception:
                    pass
            
            # Limpiar resolución si todo falla, para no dejar Kodi pensando infinito
            if not _dm_ok:
                try:
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                except Exception:
                    pass

    except Exception as e:
        _l(f"Play Error: {e}")
        xbmcgui.Dialog().ok("Error", str(e))

def _download_video(vid, title):
    if not vid: return
    
    try:
        d = connector.resolve_video(vid)
        if not d:
            xbmcgui.Dialog().ok("EspaDaily", "No se pudo resolver el video para descarga.")
            return
        qs = d.get("qualities") or {}
        
        all_links = []
        
        # 1. Buscar enlaces MP4 directos
        for res_key, formats in qs.items():
            if res_key == "auto": continue
            for f in formats:
                u = f.get("url")
                if not u: continue
                if f.get("type") == "video/mp4":
                    res_val = int(res_key) if res_key.isdigit() else 0
                    all_links.append({'label': f"{res_key}p (Descarga Directa MP4)", 'url': u, 'res': res_val, 'type': 'mp4'})
        
        # 2. Buscar HLS (M3U8) como fallback
        m3u8_master = ""
        if "auto" in qs:
            for s in qs["auto"]:
                if s.get("type") == "application/x-mpegURL":
                    m3u8_master = s.get("url", "")
                    vs = connector.fetch_hls_variants(m3u8_master)
                    for v in vs:
                        rs_str = v['label'].split(' ')[0]
                        res_val = int(rs_str.split('x')[1]) if 'x' in rs_str else 0
                        all_links.append({'label': f"{rs_str} (HLS por Segmentos .TS)", 'url': v['url'], 'res': res_val, 'type': 'hls'})
                    if m3u8_master:
                        all_links.append({'label': "ULTRA (Mejor calidad via yt-dlp)", 'url': m3u8_master, 'res': 99999, 'type': 'ultra'})

        # Ordenar por resolucion
        all_links.sort(key=lambda x: x['res'], reverse=True)

        if not all_links:
            xbmcgui.Dialog().ok("EspaDaily", "No se han encontrado enlaces de descarga para este contenido.\n\nEl servidor puede estar bloqueando el acceso directo a este video.")
            return

        # Leer modo de descarga configurado
        dm_cfg = _load_dm_settings()
        dl_mode = dm_cfg.get('dl_mode', 0)

        # Modo 0 (DIRECTO): Mostrar menú de selección (comportamiento actual)
        if dl_mode == 0:
            lbs = [l['label'] for l in all_links]
            sel = xbmcgui.Dialog().select("Selecciona Calidad de Descarga", lbs)
            if sel < 0: return
            target = all_links[sel]
        # Modo 1 (SAFE MODE): Mejor MP4 directo disponible
        elif dl_mode == 1:
            mp4s = [l for l in all_links if l['type'] == 'mp4']
            if mp4s:
                target = mp4s[0]
            else:
                xbmcgui.Dialog().ok("EspaDaily", "No hay enlaces MP4 directos.\nCambia a modo ULTRA en ajustes.")
                return
        # Modo 2 (ESPADAILY): Mejor HLS disponible
        elif dl_mode == 2:
            hls_links = [l for l in all_links if l['type'] == 'hls']
            if hls_links:
                target = hls_links[0]
            else:
                xbmcgui.Dialog().ok("EspaDaily", "No hay enlaces HLS disponibles.\nCambia a modo ULTRA en ajustes.")
                return
        # Modo 3 (YT-DLP) y 4 (ULTRA): Usar yt-dlp
        else:
            ultra = [l for l in all_links if l['type'] == 'ultra']
            if ultra:
                target = ultra[0]
            else:
                mp4s = [l for l in all_links if l['type'] == 'mp4']
                target = mp4s[0] if mp4s else all_links[0]
        
        # Pedir directorio de destino
        path = xbmcgui.Dialog().browse(3, 'Selecciona dónde guardar el video', 'video', '', False, False, '')
        if not path: return
        
        # Confirmar HLS si aplica
        if target['type'] == 'hls':
            if not xbmcgui.Dialog().yesno("Descarga HLS", "Este video no tiene enlace directo.\nSe bajará por segmentos y se unirán al final.\n\nEs un proceso lento. ¿Continuar?"):
                return

        # Preparar nombres de archivo
        safe_title = "".join([c for c in title if c.isalnum() or c in ' -_']).strip()
        if not safe_title: safe_title = vid
        ext = ".mp4" if target['type'] in ('mp4', 'ultra') else ".ts"
        dest = os.path.join(path, f"{safe_title}{ext}")
        

        if target['type'] == 'mp4':
            _do_download_direct(target['url'], dest, title)
        elif target['type'] == 'ultra':
            _do_download_ultra(vid, dest, title)
        else:
            _do_download_hls(target['url'], dest, title)
            
    except Exception as e:
        _log_error(f"Download Error video {vid}: {str(e)}")
        xbmcgui.Dialog().ok("EspaDaily Error", f"Error al preparar descarga: {str(e)}")

def _do_download_direct(url, dest, title):
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando MP4", f"Conectando: {title}")
    tmp_dest = dest + ".tmp"
    try:
        clean_url = url.split('|')[0] if '|' in url else url
        dm_h = {"User-Agent": "Mozilla/5.0 (Linux; Android 7.1.1; Pixel Build/NMF26O) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.91 Mobile Safari/537.36", "Origin": "https://www.dailymotion.com", "Referer": "https://www.dailymotion.com/"}
        r = requests.get(clean_url, headers=dm_h, stream=True, timeout=30)
        total = int(r.headers.get('content-length', 0))
        done = 0
        with open(tmp_dest, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024*256):
                if dp.iscanceled(): break
                f.write(chunk)
                done += len(chunk)
                if total > 0:
                    percent = int(done * 100 / total)
                    msg = f"Descargado: {done/(1024*1024):.1f}MB / {total/(1024*1024):.1f}MB"
                    dp.update(percent, msg)
        cancelled = dp.iscanceled()
        dp.close()
        if not cancelled:
            os.rename(tmp_dest, dest)
            core_settings.log_download(title, dest, vid)
            xbmcgui.Dialog().ok("¡Éxito!", f"Video guardado correctamente en:\n{dest}")
        elif os.path.exists(tmp_dest):
            os.remove(tmp_dest)
    except Exception as e:
        if 'dp' in locals(): dp.close()
        if os.path.exists(tmp_dest): os.remove(tmp_dest)
        _log_error(f"Error Direct DL: {str(e)}")
        xbmcgui.Dialog().ok("Error", f"Error en transferencia: {str(e)}")

def _do_download_hls(playlist_url, dest, title):
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando HLS", "Obteniendo segmentos...")
    dm_h = {"User-Agent": "Mozilla/5.0 (Linux; Android 7.1.1; Pixel Build/NMF26O) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.91 Mobile Safari/537.36", "Origin": "https://www.dailymotion.com", "Referer": "https://www.dailymotion.com/"}
    clean_url = playlist_url.split('|')[0] if '|' in playlist_url else playlist_url
    try:
        if '?' in clean_url:
            base_url = clean_url.split('?')[0].rsplit('/', 1)[0] + '/'
            params = '?' + clean_url.split('?')[1]
        else:
            base_url = clean_url.rsplit('/', 1)[0] + '/'
            params = ''

        m3u8_content = requests.get(clean_url, headers=dm_h, timeout=15).text
        segments = [l for l in m3u8_content.splitlines() if l and not l.startswith('#')]
        total_seg = len(segments)
        
        if total_seg == 0:
            xbmcgui.Dialog().ok("Error", "La lista de reproducción está vacía."); return

        tmp_dest = dest + ".tmp"
        with open(tmp_dest, 'wb') as f_out:
            for idx, seg_name in enumerate(segments):
                if dp.iscanceled(): break
                
                if seg_name.startswith('http'):
                    seg_url = seg_name
                else:
                    seg_url = base_url + seg_name + params
                
                success = False
                for attempt in range(3):
                    try:
                        seg_data = requests.get(seg_url, headers=dm_h, timeout=12).content
                        f_out.write(seg_data)
                        success = True
                        break
                    except Exception: continue
                
                if not success: raise Exception(f"Fallo crítico en segmento {idx+1}")
                
                percent = int((idx + 1) * 100 / total_seg)
                msg = f"Segmento {idx+1}/{total_seg} - {title}"
                dp.update(percent, msg)
        
        cancelled = dp.iscanceled()
        dp.close()
        if not cancelled:
            os.rename(tmp_dest, dest)
            core_settings.log_download(title, dest, "HLS")
            xbmcgui.Dialog().ok("¡Completado!", f"El video HLS se ha unido y guardado en:\n{dest}")
        elif os.path.exists(tmp_dest):
            os.remove(tmp_dest)
    except Exception as e:
        if 'dp' in locals(): dp.close()
        if os.path.exists(tmp_dest): os.remove(tmp_dest)
        _log_error(f"HLS Merge Error: {str(e)}")
        xbmcgui.Dialog().ok("Error Union HLS", f"Fallo: {str(e)}")

def _get_ytdlp_pkg_path():
    """Devuelve la ruta de paquetes yt-dlp en addon_data."""
    profile = xbmcvfs.translatePath(
        xbmcaddon.Addon().getAddonInfo('profile')
    )
    pkg_path = os.path.join(profile, "packages")
    if not os.path.exists(pkg_path):
        os.makedirs(pkg_path)
    return pkg_path


def _ensure_ytdlp():
    """Descarga yt-dlp wheel desde PyPI si no existe en addon_data/packages."""
    import io
    pkg_path = _get_ytdlp_pkg_path()
    ytdlp_dir = os.path.join(pkg_path, "yt_dlp")
    if os.path.isdir(ytdlp_dir):
        return True

    try:
        pypi_r = requests.get("https://pypi.org/pypi/yt-dlp/json", timeout=15)
        if pypi_r.status_code != 200:
            return False
        whl_url = None
        for u in pypi_r.json().get("urls", []):
            if u["filename"].endswith(".whl") and "py3-none-any" in u["filename"]:
                whl_url = u["url"]
                break
        if not whl_url:
            return False
        whl_r = requests.get(whl_url, timeout=120)
        if whl_r.status_code != 200:
            return False
        whl_data = io.BytesIO(whl_r.content)
        with zipfile.ZipFile(whl_data) as zf:
            for member in zf.namelist():
                if member.startswith("yt_dlp/"):
                    zf.extract(member, pkg_path)
        return os.path.isdir(ytdlp_dir)
    except Exception as e:
        _log_error(f"Error descargando yt-dlp: {str(e)}")
    return False


def _find_system_python():
    """Busca un Python del sistema >= 3.10 que pueda ejecutar yt-dlp."""
    import subprocess
    no_win = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    for py in ["python", "python3", "py"]:
        try:
            r = subprocess.run(
                [py, "-c", "import sys; v=sys.version_info; print(f'{v.major}.{v.minor}'); assert v >= (3,10)"],
                capture_output=True, text=True, timeout=5,
                creationflags=no_win
            )
            if r.returncode == 0:
                return py
        except Exception:
            continue
    return None


def _write_dl_helper(pkg_path, vid, dest, progress_file):
    """Genera un script Python que descarga con yt-dlp y escribe progreso."""
    helper_path = os.path.join(pkg_path, "_dl_helper.py")
    script = f'''
import sys, os, json
sys.path.insert(0, {repr(pkg_path)})
import yt_dlp

progress_file = {repr(progress_file)}

def hook(d):
    info = {{"status": d.get("status", ""), "percent": 0, "text": ""}}
    if d["status"] == "downloading":
        total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
        done = d.get("downloaded_bytes", 0)
        speed = d.get("speed") or 0
        if total > 0:
            info["percent"] = int(done * 100 / total)
            mb_d = done / (1024*1024)
            mb_t = total / (1024*1024)
            sp = speed / (1024*1024) if speed else 0
            info["text"] = f"{{mb_d:.1f}}MB / {{mb_t:.1f}}MB ({{sp:.1f}} MB/s)"
        elif done > 0:
            info["percent"] = 50
            info["text"] = f"Descargando: {{done/(1024*1024):.1f}}MB"
    elif d["status"] == "finished":
        info["percent"] = 95
        info["text"] = "Finalizando..."
    with open(progress_file, "w") as f:
        json.dump(info, f)

opts = {{
    "format": "best[ext=mp4]/best",
    "outtmpl": {repr(dest)},
    "quiet": True,
    "no_warnings": True,
    "progress_hooks": [hook],
    "noprogress": True,
}}
url = "https://www.dailymotion.com/video/{vid}"
try:
    ydl = yt_dlp.YoutubeDL(opts)
    ydl.download([url])
    with open(progress_file, "w") as f:
        json.dump({{"status": "done", "percent": 100, "text": "Completado"}}, f)
except Exception as e:
    with open(progress_file, "w") as f:
        json.dump({{"status": "error", "percent": 0, "text": str(e)[:300]}}, f)
'''
    with open(helper_path, 'w', encoding='utf-8') as f:
        f.write(script)
    return helper_path


def _do_download_ultra(vid, dest, title):
    """Modo ULTRA: Descarga via yt-dlp (helper script + system Python)."""
    import subprocess
    import threading

    # Android/dispositivos sin Python del sistema: informar
    if xbmc.getCondVisibility("System.Platform.Android"):
        xbmcgui.Dialog().ok(
            "EspaDaily",
            "Las descargas de Dailymotion no están\n"
            "disponibles en Android.\n\n"
            "Dailymotion bloquea descargas directas.\n"
            "Usa un PC con Python 3.10+ instalado."
        )
        return

    try:
        if xbmcvfs.exists(dest):
            if not xbmcgui.Dialog().yesno("EspaDaily", "El archivo ya existe. ¿Sobrescribir?"): return
            xbmcvfs.delete(dest)

        dp = xbmcgui.DialogProgress()
        dp.create("Descargando (Modo ULTRA)", "Preparando...")

        if not dest.endswith(".mp4"):
            dest = os.path.splitext(dest)[0] + ".mp4"

        # 1. Buscar Python del sistema >= 3.10
        dp.update(2, "Buscando Python del sistema...")
        py_cmd = _find_system_python()
        if not py_cmd:
            dp.close()
            xbmcgui.Dialog().ok(
                "EspaDaily",
                "Se necesita Python 3.10+ instalado en el sistema.\n\n"
                "Descárgalo de python.org e instálalo\n"
                "marcando 'Add to PATH'.\n\n"
                "Después reinicia Kodi."
            )
            return

        # 2. Descargar yt-dlp si no existe
        pkg_path = _get_ytdlp_pkg_path()
        ytdlp_dir = os.path.join(pkg_path, "yt_dlp")
        if not os.path.isdir(ytdlp_dir):
            dp.update(5, "Descargando componente yt-dlp (~3MB)...")
            if not _ensure_ytdlp():
                dp.close()
                xbmcgui.Dialog().ok("EspaDaily", "Error descargando yt-dlp.\nComprueba tu conexión a internet.")
                return

        # 3. Generar y ejecutar script auxiliar
        dp.update(10, "Iniciando descarga...")
        progress_file = os.path.join(pkg_path, "_dl_progress.json")
        if os.path.exists(progress_file):
            os.remove(progress_file)

        helper_path = _write_dl_helper(pkg_path, vid, dest, progress_file)
        no_win = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

        proc = subprocess.Popen(
            [py_cmd, helper_path],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=no_win
        )

        # 4. Polling de progreso
        cancelled = False
        while proc.poll() is None:
            if dp.iscanceled():
                cancelled = True
                proc.kill()
                break
            if os.path.exists(progress_file):
                try:
                    with open(progress_file, 'r') as f:
                        info = json.loads(f.read())
                    dp.update(info.get("percent", 0), info.get("text", "Descargando..."))
                except Exception:
                    pass
            time.sleep(0.5)

        dp.close()

        # Limpiar script auxiliar
        for tmp in [helper_path, progress_file]:
            if os.path.exists(tmp):
                try: os.remove(tmp)
                except Exception: pass

        if cancelled:
            for ext in ["", ".part"]:
                p = dest + ext
                if os.path.exists(p):
                    try: os.remove(p)
                    except Exception: pass
            return

        # Leer resultado final
        if proc.returncode == 0 and os.path.exists(dest):
            core_settings.log_download(title, dest, "MP4 (ULTRA)")
            xbmcgui.Dialog().ok("EspaDaily", "¡Descarga ULTRA completada!")
        else:
            stderr = ""
            try:
                stderr = proc.stderr.read().decode('utf-8', errors='replace')[:200]
            except Exception:
                pass
            raise Exception(f"yt-dlp falló (código {proc.returncode}): {stderr}")

    except Exception as e:
        if 'dp' in locals(): dp.close()
        for ext in [".part", ".tmp"]:
            p = dest + ext
            if os.path.exists(p):
                try: os.remove(p)
                except Exception: pass
        _log_error(f"Ultra Error: {str(e)}")
        xbmcgui.Dialog().ok("Error Ultra", f"Fallo en descarga Ultra:\n{str(e)}")

def _dm_search_direct(q, extra_params=None):
    params = {
        "search": q,
        "fields": "id,title,owner.username,duration,thumbnail_360_url,thumbnail_720_url",
        "limit": 50
    }
    if extra_params:
        params.update(extra_params)
    ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    for verify in (True, False):
        try:
            r = requests.get(
                "https://api.dailymotion.com/videos",
                params=params,
                headers={"User-Agent": ua},
                timeout=15,
                verify=verify
            )
            return r.json().get("list", [])
        except Exception:
            continue
    return []

def _sr(q, extra_params=None):
    p = {}
    if core_settings.is_recent_active():
        p["sort"] = "recent"
    if extra_params:
        p.update(extra_params)
    if connector:
        try:
            return connector.search_dailymotion(q, p if p else None)
        except Exception:
            pass
    return _dm_search_direct(q, p if p else None)

def _gsr(q, rs, mode=""):
    if not rs: return []
    sc = []; ql = q.lower().strip(); qn = re.findall(r'(\d+)', ql)
    for r in rs:
        t = r.get("title", "").strip(); tl = t.lower()
        if not t: continue
        

        rt = difflib.SequenceMatcher(None, ql, tl).ratio(); s = rt
        
        # FILTRO ESTRICTO: Si no contiene las palabras clave de la busqueda, penalizar fuertemente
        # (Esto evita que salgan resultados random como 'La Monja' buscando 'Top Gun')
        q_words = [w for w in ql.split() if len(w) > 3] # Palabras importantes (>3 letras)
        if q_words:
            matches = sum(1 for w in q_words if w in tl)
            if matches == 0: 
                s -= 1.0 # Penalizacion masiva si no coincide ninguna palabra clave
            elif matches < len(q_words):
                s -= 0.1 # Pequeña penalizacion si faltan palabras

        if ql in tl: s += 0.35 # Match contenido exacto
        

        words_q = set(ql.split())
        words_t = set(tl.split())
        common = words_q.intersection(words_t)
        if len(common) > 0: s += (len(common) / len(words_q)) * 0.2
        

        tn = re.findall(r'(\d+)', tl)
        if qn and tn:
            if qn[-1] in tn: s += 0.4
            if set(qn).issubset(set(tn)): s += 0.1
            

        # IMPORTANTE: Solo aplicamos bonus de duracion si el titulo coincide razonablemente bien (s > 0.3)
        # Esto evita que 'La Monja' (larga) gane a 'Iron Man 3' (corto) si el titulo no se parece.
        du = r.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        
        if s > 0.3: # Solo si hay match de titulo decente
            if not core_settings.is_prioritize_match_active():
                # Modo ESTÁNDAR: Fuerte bonus por duración
                if du > 600: s += 0.6    # Gran bonus si coincide titulo y es larga
                elif du > 300: s += 0.2
            else:
                # Modo PRECISIÓN: Bonus por duración mínimo
                if du > 600: s += 0.05
            
            if du < 180: s -= 0.1  # Penalizacion leve por ser muy corto (trailer)
        else:
            # Si el titulo no coincide bien, la duracion NO ayuda.
            pass
        

        if any(w in tl for w in ["español", "castellano", "spanish"]):
            s += 0.15

        # Filtrado especifico de peliculas
        if mode == "movie":
            # Penalizar contenido que no sea pelicula
            if any(w in tl for w in ["trailer", "avance", "entrevista", "making", "detras", "clip", "promo"]):
                s -= 0.5
            # Bonus por indicadores de pelicula
            if any(w in tl for w in ["pelicula", "completa", "movie", "film"]):
                s += 0.2

        s = min(s, 1.0)
        sc.append((s, r))
    sc.sort(key=lambda x: x[0], reverse=True); return sc



def _show_fav_news():
    """Agregador: Busca contenido reciente de los favoritos con margen dinámico."""
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("EspaDaily", "No tienes favoritos guardados", xbmcgui.NOTIFICATION_WARNING)
        return
        
    # 1. Preguntar margen
    opts = [
        "Últimas 24 horas",
        "Últimas 48 horas (Recomendado)",
        "Última semana (7 días)",
        "Último mes (30 días - Lento)"
    ]
    sel = xbmcgui.Dialog().select("Margen de búsqueda de Novedades", opts)
    if sel < 0: return # Cancelado
    
    margins = [86400, 172800, 604800, 2592000]
    time_limit = int(time.time()) - margins[sel]
    sel_label = opts[sel]

    pdp = xbmcgui.DialogProgress()
    pdp.create("Novedades de mis Favoritos", f"Buscando: {sel_label}...")
    
    all_results = []
    
    queries = []
    seen = set()
    for f in favs:
        q = None
        if f.get('action') == 'lfr':
            q = f.get('params', {}).get('q')
        elif f.get('action') in ['ls', 'ls_rtve', 'ls_mediaset', 'fs', 'fs_rtve']:
            q = f['title']
            if ": " in q: q = q.split(": ")[-1]
        
        if q and q.lower() not in seen:
            queries.append(q)
            seen.add(q.lower())
            
    if not queries:
        pdp.close()
        xbmcgui.Dialog().ok("Mi Periódico", "No hay series o búsquedas en favoritos para analizar.")
        return

    total = len(queries)
    for i, q in enumerate(queries):
        if pdp.iscanceled(): break
        pdp.update(int((i / max(total, 1)) * 100), f"Analizando: [B]{q}[/B]")
        
        rs = _sr(q, {"created_after": time_limit})
        if rs:
            sr = _gsr(q, rs, mode="keywords") 
            for score, v in sr:
                if score > 0.35: # Filtro de calidad para evitar basura
                    vid = v.get("id")
                    if not any(r[1].get("id") == vid for r in all_results):
                        all_results.append((score, v, q))

    pdp.close()
    
    if not all_results:
        xbmcgui.Dialog().ok("Novedades de mis Favoritos", f"No se han encontrado novedades en '{sel_label}' para tus favoritos.")
        return

    # Mostrar resultados consolidados
    h = int(sys.argv[1])
    all_results.sort(key=lambda x: x[0], reverse=True)
    xbmcplugin.setContent(h, 'videos')
    
    for score, v, origin in all_results:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url")
        
        label = f"[COLOR yellow][{origin}][/COLOR] {vt}"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Favorito: {origin}\nSubido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        
        cm = []
        if core_settings.is_palantir_installed() and core_settings.is_palantir_integration_enabled() and not core_settings.are_external_integrations_disabled():
            cm.append(("Buscar en Palantir 3", f"RunPlugin({_u(action='palantir_search', q=vt)})"))
        cm.append(("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})"))
        cm.append(("Abrir en el navegador", f"RunPlugin({_u(action='dm_open_browser', url=vi)})"))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vi, title=urllib.parse.quote(vt)), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

def _show_favorites():
    favs = core_settings.get_favorites()
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)

    _FLOWFAV_REPO_ID = 'repository.flowfavmanager'
    _FLOWFAV_ADDON_ID = 'plugin.program.flowfavmanager'
    try:
        xbmcaddon.Addon(_FLOWFAV_ADDON_ID)
        li_flow = xbmcgui.ListItem(label="[COLOR violet][B]Flow FavManager[/B][/COLOR]")
        li_flow.setArt({'icon': _mi('favoritos.png')})
        li_flow.setInfo('video', {'plot': 'Abre el editor avanzado de favoritos de Kodi.\nOrganiza, personaliza colores, iconos, formatos, crea secciones, perfiles y copias de seguridad.'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="open_flowfav"), listitem=li_flow, isFolder=False)
    except Exception:
        li_flow = xbmcgui.ListItem(label="[COLOR gray]Flow FavManager (No instalado)[/COLOR]")
        li_flow.setArt({'icon': _mi('favoritos.png')})
        li_flow.setInfo('video', {'plot': 'Gestor avanzado de favoritos para Kodi.\nPulsa para instalar o ver instrucciones.'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="flowfav_install"), listitem=li_flow, isFolder=False)


    cats = category_manager.load_cats()
    if cats:
         li_c = xbmcgui.ListItem(label=f"[COLOR yellow][B]Mis Categorías ({len(cats)})[/B][/COLOR]")
         li_c.setArt({'icon': _mi('favoritos.png')})
         li_c.setInfo('video', {'plot': "Accede a tus carpetas y listas personalizadas ('Infantil', 'Noticias', etc).\n\nPuedes crear nuevas categorías desde el menú principal."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cat_menu"), listitem=li_c, isFolder=True)


    if favs:
         li_n = xbmcgui.ListItem(label="[COLOR yellow][B]Novedades de mis Favoritos[/B][/COLOR]")
         li_n.setArt({'icon': _mi('favoritos.png')})
         li_n.setInfo('video', {'plot': "Analiza automáticamente tus favoritos y busca contenido subido recientemente.\n\nPodrás elegir el margen de tiempo (24h, 48h, 7 días...).\n\nIdeal para ver qué hay de nuevo sin ir sección por sección."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fav_news"), listitem=li_n, isFolder=True)


    if not favs:
        if not cats: # Only show 'empty' if no cats either
             li = xbmcgui.ListItem(label="No tienes favoritos guardados")
             li.setArt({'icon': 'DefaultIconInfo.png'})
             li.setInfo('video', {'plot': "Haz clic derecho en cualquier programa o serie y selecciona 'Añadir a Mis Favoritos' para guardarlo aquí."})
             xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    else:
        for f in favs:
            li = xbmcgui.ListItem(label=f['title'])
            li.setArt({'icon': f['icon'], 'thumb': f['icon']})
        
            cm = []
            

            if core_settings.is_palantir_installed() and core_settings.is_palantir_integration_enabled() and not core_settings.are_external_integrations_disabled():
                cm.append(("Buscar en Palantir 3", f"RunPlugin({_u(action='palantir_search', q=f['title'])})"))
            
            # Buscar en torrents (Elementum). Los torrents en sí son legales. Es más, en muchas webs los enlaces son legales.
            # Solo busca el tíulo, no enlaces. Los enlaces los buscará Elementum por su cuenta y riesgo.
            cm.append(("Buscar en webs de torrent", f"RunPlugin({_u(action='elementum_search', q=f['title'])})"))


            cm.append(("Editar nombre y buscar", f"RunPlugin({_u(action='edit_and_search', q=f['title'], ot=f['icon'])})"))

            cm.append(("Renombrar...", f"RunPlugin({_u(action='fav_rename', fav_url=f['url'], old_title=f['title'])})"))
            cm.append(("Mover arriba", f"RunPlugin({_u(action='fav_move_up', fav_url=f['url'])})"))
            cm.append(("Mover abajo", f"RunPlugin({_u(action='fav_move_down', fav_url=f['url'])})"))
            

            # Usar 'cat_move_from_favs' para MOVER (borra de favs y añade a cat) en lugar de solo añadir.
            cm.append(("Mover a Categoría...", f"RunPlugin({_u(action='cat_move_from_favs', fav_url=f['url'], q=f['title'])})"))
            

            cm.append(("Eliminar de Favoritos", f"RunPlugin({_u(action='remove_favorite', fav_url=f['url'])})"))
            
            li.addContextMenuItems(cm)
            
            # Reconstruir la URL con la acción y parámetros guardados
            # URL que se abre al hacer clic en el favorito:
            u_params = f"action={f['action']}"
            for k,v in f.get('params', {}).items():
                u_params += f"&{k}={urllib.parse.quote(str(v))}"
            

            if f['action'] == 'lfr' and '&nh=' not in u_params:
                u_params += "&nh=1"
            
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?"+u_params, listitem=li, isFolder=True)


    _bfav_icon = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'adv_backup.png')
    li = xbmcgui.ListItem(label="[COLOR cyan]Backup de Favoritos[/COLOR]")
    li.setArt({'icon': _bfav_icon})
    li.setInfo('video', {'plot': "Exportar o importar favoritos en formato JSON."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fav_backup_menu"), listitem=li, isFolder=True)



    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _fav_backup_menu():
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    li = xbmcgui.ListItem(label="[COLOR cyan]Exportar Favoritos...[/COLOR]")
    li.setArt({'icon': os.path.join(_med, 'backup_favs.png')})
    li.setInfo('video', {'plot': "Guarda tus favoritos principales en un archivo JSON para compartirlos."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fav_export"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR cyan]Importar Favoritos...[/COLOR]")
    li.setArt({'icon': 'DefaultFolderBack.png'})
    li.setInfo('video', {'plot': "Carga favoritos desde un archivo JSON."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fav_import"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

def _show_downloads():
    dls = core_settings.get_downloads()
    if not dls:
        li = xbmcgui.ListItem(label="No hay historial de descargas")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.setInfo('video', {'plot': "Cuando descargues un vídeo con éxito, aparecerá aquí.\nPuedes descargar vídeos desde los resultados de búsqueda pulsando clic derecho.\n\nDescargo de responsabilidad:\nEspaDaily no almacena ni distribuye contenido.\nLas descargas se realizan directamente desde las fuentes públicas de internet.\nEl usuario es el único responsable del uso que haga de esta función y de cumplir la legislación vigente en su país."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    else:
        for d in dls:
            path = d['path']
            if not os.path.exists(path):
                label = f"[COLOR grey][ELIMINADO][/COLOR] {d['title']}"
                is_valid = False
            else:
                label = f"{d['title']} ({d['date']})"
                is_valid = True
                
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': 'DefaultVideo.png'})
            li.setInfo('video', {'title': d['title'], 'plot': f"Archivo: {path}\nDescargado el: {d['date']}"})
            
            cm = [("Quitar del historial", f"RunPlugin({_u(action='remove_download', dl_path=path)})")]
            if is_valid:
                 li.setProperty("IsPlayable", "true")
                 cm.append(("[COLOR red]ELIMINAR ARCHIVO DEL DISCO[/COLOR]", f"RunPlugin({_u(action='delete_download_file', dl_path=path, title=d['title'])})"))
             
                 u = path
            else:
                 u = ""
                 
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=False if is_valid else True)
        
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _add_fav_cm(li, title, platform, action, params):
    # URL para favoritos
    # ID unico para no duplicar (Atr3splay3r usa 'au')
    id_val = params.get('cid') or params.get('pid') or params.get('url') or params.get('au') or params.get('q')
    if not id_val:
        # Fallback: hash de params
        id_val = str(hash(json.dumps(params, sort_keys=True)))
    fav_url = f"{action}_{id_val}"
    params_json = json.dumps(params)
    li.addContextMenuItems([
        ("Añadir a Mis Favoritos", f"RunPlugin({_u(action='add_favorite', title=title, fav_url=fav_url, icon=li.getArt('icon'), platform=platform, fav_action=action, params=params_json)})")
    ])

def _delete_download_file(path, title):
    if xbmcgui.Dialog().yesno("Eliminar Archivo", f"¿Estás seguro de que quieres eliminar físicamente el archivo?\n\n[B]{title}[/B]\n\nEsta acción eliminará el archivo de tu disco duro para siempre."):
        try:
            if os.path.exists(path):
                os.remove(path)
                core_settings.remove_download(path)
                xbmcgui.Dialog().notification("EspaDaily", "Archivo eliminado satisfactoriamente", xbmcgui.NOTIFICATION_INFO)
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().ok("EspaDaily", "El archivo ya no existe en esa ruta.")
                core_settings.remove_download(path)
                xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
            xbmcgui.Dialog().ok("EspaDaily Error", f"No se pudo eliminar: {str(e)}")



def _get_snapshot_dir():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    sd = os.path.join(p, 'snapshots')
    if not os.path.exists(sd): os.makedirs(sd)
    return sd

def _get_platform_cats(platform):
    return connector.get_platform_cats(platform)

def _fetch_list_data(platform, cid):
    return connector.fetch_list_data(platform, cid)
    
def _toggle_snapshot_context():
    core_settings.cycle_snapshot_context()
    xbmc.executebuiltin("Container.Refresh")

def _snapshot_context_help():
    t = (
        "[B]CONTEXTO DE BÚSQUEDA EN INSTANTÁNEAS[/B]\n\n"
        "Define cómo se construye la búsqueda al abrir contenido guardado.\n\n"
        
        "[B]Ejemplo: 'El Hormiguero' en 'Programas' de 'Atresplayer'[/B]\n\n"
        
        "[B]• CLÁSICO (Recomendado):[/B]\n"
        "  - Atresplayer: 'El Hormiguero'\n"
        "  - RTVE: 'RTVE El Hormiguero'\n"
        "  - Mediaset: 'Mediaset El Hormiguero'\n\n"
        
        "[B]• Nivel 0 (Solo Título):[/B]\n"
        "  - 'El Hormiguero'\n\n"
        
        "[B]• Nivel 1 (Categoría):[/B]\n"
        "  - 'Programas El Hormiguero'\n\n"
        
        "[B]• Nivel 2 (Plataforma+Categoría):[/B]\n"
        "  - 'Atresplayer Programas El Hormiguero'\n\n"
        
        "[B]¿CUÁL ELEGIR?[/B]\n"
        "CLÁSICO es la opción más segura y probada. Los niveles avanzados "
        "pueden mejorar la precisión en algunos casos, pero también pueden "
        "fallar si no hay vídeos con esas palabras exactas en el título."
    )
    xbmcgui.Dialog().textviewer("Ayuda: Contexto de Búsqueda", t)

def _snapshot_info():
    t = (
        "Es recomendable crear una instantánea periódicamente.\n\n"
        "Esto te permite acceder a los menús guardados incluso si se corta el acceso "
        "a las listas online, el servidor falla o el addon deja de recibir actualizaciones de contenido.\n\n"
        "Esta opción también puede ser interesante para cargar backups o listas compartidas por otros usuarios."
    )
    xbmcgui.Dialog().textviewer("Recomendación de Instantáneas", t)

def snapshots_menu():

    msg = "Es recomendable crear una instantánea periódicamente por si se corta el acceso a las listas online, falla el servidor o el contenido deja de actualizarse."
    li = xbmcgui.ListItem(label=f"[COLOR cyan][B]RECOMENDACIÓN:[/B][/COLOR] {msg}")
    li.setInfo('video', {'plot': "Es recomendable crear una instantánea periódicamente. Esto te permite acceder a los menús guardados incluso si se corta el acceso a las listas online, el servidor falla o el addon deja de recibir actualizaciones de contenido.\n\nEsta opción también puede ser interesante para cargar backups o listas compartidas por otros usuarios."})
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="snapshot_info"), listitem=li, isFolder=False)

    # 1. Crear
    li = xbmcgui.ListItem(label="[COLOR green][B]+ CREAR NUEVA INSTANTÁNEA[/B][/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="create_snapshot"), listitem=li, isFolder=False)

    # 2. Borrar (listar para borrar)
    li = xbmcgui.ListItem(label="[COLOR red]BORRAR INSTANTÁNEAS...[/COLOR]")
    li.setArt({'icon': 'DefaultIconError.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="delete_snapshot_menu"), listitem=li, isFolder=True)

    # 3. Exportar (NUEVO)
    li = xbmcgui.ListItem(label="[COLOR yellow]EXPORTAR INSTANTÁNEAS...[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="export_snapshot_menu"), listitem=li, isFolder=True)

    # 4. Importar (NUEVO)
    li = xbmcgui.ListItem(label="[COLOR orange]IMPORTAR INSTANTÁNEA...[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="import_snapshot_menu"), listitem=li, isFolder=True)
    
    # 5. Contexto de Búsqueda (INDEPENDIENTE)
    curr_ctx = core_settings.get_snapshot_context_level()
    ctx_labels = {-1: "CLÁSICO (Recomendado)", 0: "APAGADO (Solo Título)", 1: "Nivel 1 (Categoría)", 2: "Nivel 2 (Plataforma+Cat)"}
    label_txt = ctx_labels.get(curr_ctx, "Desconocido")
    
    li = xbmcgui.ListItem(label=f"Contexto de Búsqueda: [COLOR yellow]{label_txt}[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Pulsa para cambiar el modo. Ver [?] Ayuda para más detalles."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_snapshot_context"), listitem=li, isFolder=False)

    # 4. Botón de Ayuda
    li = xbmcgui.ListItem(label="[COLOR blue][?] Ayuda: ¿Qué es el Contexto de Búsqueda?[/COLOR]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="snapshot_context_help"), listitem=li, isFolder=False)

    # 5. Listar existentes
    sd = _get_snapshot_dir()
    files = sorted([f for f in os.listdir(sd) if f.endswith('.json')], reverse=True)
    
    addon = xbmcaddon.Addon()
    icon = addon.getAddonInfo('icon')

    for f in files:
        # Formato: snapshot_YYYYMMDD_HHMMSS.json
        try:
            ts_str = f.replace("instantaneas_espadaily_", "").replace("snapshot_", "").replace(".json", "")
            # Simple parsing manually
            date_str = f"{ts_str[6:8]}/{ts_str[4:6]}/{ts_str[0:4]} {ts_str[9:11]}:{ts_str[11:13]}"
            li = xbmcgui.ListItem(label=f"Instantánea: {date_str}")
            li.setArt({'icon': 'DefaultFolder.png', 'thumb': icon})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="view_snapshot", file=f, path="root"), listitem=li, isFolder=True)
        except Exception: continue

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _create_snapshot():
    # 1. Elegir alcance (Scope)
    scope_opts = ["Todo el Catálogo (Atresplayer + RTVE + Mediaset)", "Seleccionar plataformas..."]
    scope_sel = xbmcgui.Dialog().select("¿Qué quieres guardar?", scope_opts)
    if scope_sel < 0: return

    platforms = ["atresplayer", "rtve", "mediaset"]
    selected_platforms = []
    
    if scope_sel == 0:
        selected_platforms = platforms
    else:
        # Multiselect dialog
        labels = ["Atresplayer", "RTVE Play", "Mediaset Infinity"]

        initial_sel = [0, 1, 2] 
        ms_res = xbmcgui.Dialog().multiselect("Selecciona plataformas", labels, preselect=initial_sel)
        if not ms_res: return # Cancelled or empty
        
        for idx in ms_res:
            selected_platforms.append(platforms[idx])

    if not selected_platforms: return

    # 2. Elegir Tipo
    opts = ["Actualizable (Conectada)", "Independiente (Desconectada)"]
    sel = xbmcgui.Dialog().select("Tipo de Instantánea", opts)
    if sel < 0: return
    
    is_dynamic = (sel == 0)
    
    # Confirmacion final
    plat_str = ", ".join([p.upper() for p in selected_platforms])
    if not xbmcgui.Dialog().yesno("Crear Instantánea", f"Se guardarán: {plat_str}.\n\nEste proceso puede tardar unos segundos.\n¿Continuar?"):
        return

    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Creando Instantánea', 'Inicializando...')
    
    data = {
        "timestamp": int(time.time()),
        "type": "dynamic" if is_dynamic else "static",
        "content": {}
    }
    
    total_steps = 0
    for p in selected_platforms: total_steps += len(_get_platform_cats(p))
    
    current_step = 0
    
    for plt in selected_platforms:
        data["content"][plt] = {}
        cats = _get_platform_cats(plt)
        
        for c in cats:
            if pDialog.iscanceled(): 
                pDialog.close()
                return
            
            percentage = int((current_step / total_steps) * 100)
            pDialog.update(percentage, f"Escaneando {plt}...\nCategoría: {c['title']}")
            
            items = _fetch_list_data(plt, c["id"])
            data["content"][plt][c["title"]] = {
                "icon": c.get("icon"),
                "items": items
            }
            current_step += 1

    pDialog.update(100, "Guardando archivo...")
    
    # Save
    ts = time.strftime("%Y%m%d_%H%M%S")
    fname = f"instantaneas_espadaily_{ts}.json"
    fpath = os.path.join(_get_snapshot_dir(), fname)
    
    with open(fpath, 'w', encoding='utf-8') as f:
        json.dump(data, f)
        
    pDialog.close()
    xbmcgui.Dialog().notification("EspaDaily", "Instantánea creada correctamente", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _view_snapshot(f, path):
    fpath = os.path.join(_get_snapshot_dir(), f)
    if not os.path.exists(fpath): return
    
    with open(fpath, 'r', encoding='utf-8') as fo:
        data = json.load(fo)
        
    content = data.get("content", {})
    
    if path == "root":
    
        platforms = [
            {"id": "atresplayer", "label": "Atresplayer", "icon": "DefaultFolder.png"},
            {"id": "rtve", "label": "RTVE Play", "icon": "DefaultFolder.png"},
            {"id": "mediaset", "label": "Mediaset Infinity", "icon": "DefaultFolder.png"},
        ]
        for p in platforms:
            li = xbmcgui.ListItem(label=p["label"])
            li.setArt({'icon': p['icon']})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="view_snapshot", file=f, path=p["id"]), listitem=li, isFolder=True)
            
    elif "/" not in path:
    
        plt = path
        cats_data = content.get(plt, {})
        for cat_title, cat_data in cats_data.items():
            li = xbmcgui.ListItem(label=cat_title)
            li.setArt({'icon': cat_data.get("icon", "DefaultFolder.png")})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="view_snapshot", file=f, path=f"{plt}/{cat_title}"), listitem=li, isFolder=True)
            
    else:
    
        parts = path.split("/")
        plt = parts[0]
        cat = parts[1]
        
        items = content.get(plt, {}).get(cat, {}).get("items", [])
        
        for i in items:
            tt = i.get("title")
            th = i.get("image")
            

            

            snap_mode = core_settings.get_snapshot_context_level()
            
            q = tt
            
            if snap_mode == -1:

                if plt == "mediaset": q = f"Mediaset {tt}"
                elif plt == "rtve": q = f"RTVE {tt}"
                else: q = tt # Atr3splay3r default
                
            else:

                # Construir cadena de contexto: "Plataforma || Categoria"
                
                plt_clean = plt
                if plt == "mediaset": plt_clean = "Mediaset"
                elif plt == "rtve": plt_clean = "RTVE"
                elif plt == "atresplayer": plt_clean = "Atresplayer"
                
                ctx_data = f"{plt_clean}||{cat}"
                
                # Forzar el nivel especifico de los ajustes de instantanea
                q = core_settings.build_query(tt, ctx_data, force_level=snap_mode)
            
            li = xbmcgui.ListItem(label=tt)
            li.setArt({'thumb': th, 'icon': th})
            li.setInfo('video', {'title': tt, 'plot': i.get('plot', '')})
            

            snap_type = data.get("type", "static")
            
            if snap_type == "dynamic" and i.get("action_type"):
                # DINAMICO: Reconectar con plataforma
                at = i.get("action_type")
                pm = i.get("params", {})
                
                # Caso especial para M3d1as3t href
                if at == "ls_mediaset" and i.get("href"):

                     pass 
                
                # Construir URL con parametros originales
                url_params = {"action": at}
                url_params.update(pm)
                
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(**url_params), listitem=li, isFolder=True)
            
            else:
                # ESTATICO: Buscar en la red
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=q, ot=th), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _delete_snapshot_menu():
    sd = _get_snapshot_dir()
    files = sorted([f for f in os.listdir(sd) if f.endswith('.json')], reverse=True)
    
    for f in files:
        ts_str = f.replace("instantaneas_espadaily_", "").replace("snapshot_", "").replace(".json", "")
        date_str = f"{ts_str[6:8]}/{ts_str[4:6]}/{ts_str[0:4]} {ts_str[9:11]}:{ts_str[11:13]}"
        
        li = xbmcgui.ListItem(label=f"[BORRAR] {date_str}")
        li.setArt({'icon': 'DefaultIconError.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="delete_snapshot", file=f), listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _delete_snapshot(f):
    if xbmcgui.Dialog().yesno("Borrar Instantánea", "¿Estás seguro de querer borrar esta instantánea?"):
        try:
            os.remove(os.path.join(_get_snapshot_dir(), f))
            xbmcgui.Dialog().notification("EspaDaily", "Borrada correctamente", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except Exception: pass


def _import_backup():
    f = xbmcgui.Dialog().browse(1, 'Seleccionar Backup', 'files', '.zip', False, False, '')
    if not f: return

    file_labels = {
        'settings.json': 'Configuración General',
        'favorites.json': 'Favoritos',
        'search_history.json': 'Historial de Búsquedas',
        'history.json': 'Historial (v1)',
        'custom_categories.json': 'Categorías Personalizadas',
        'exploration_history.json': 'Historial de Navegación',
        'dm_settings.json': 'Ajustes Dailymotion',
        'watch_history.json': 'Historial de Visionado',
        'custom_iptv.json': 'Listas IPTV Personalizadas',
        'url_history.json': 'Historial de URLs',
        'url_bookmarks.json': 'Marcadores de URLs',
    }
    mergeable = ['favorites.json', 'search_history.json', 'history.json', 'exploration_history.json',
                 'watch_history.json', 'url_history.json', 'url_bookmarks.json', 'custom_iptv.json']
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))

    try:
        with zipfile.ZipFile(f, 'r') as zf:
            available = zf.namelist()
        known = [fz for fz in available if fz in file_labels]
    
        cache_files = [fz for fz in available if fz.startswith("cat_cache_") and fz.endswith(".json")]
        if cache_files:
            known.append('__cache__')
            file_labels['__cache__'] = 'Caché de Categorías ({0})'.format(len(cache_files))
    
        snap_files = [fz for fz in available if fz.startswith('snapshots/') and fz.endswith('.json')]
        if snap_files:
            known.append('__snapshots__')
            file_labels['__snapshots__'] = 'Instantáneas ({0})'.format(len(snap_files))

        if not known:
            xbmcgui.Dialog().ok("EspaDaily", "Este archivo no contiene datos reconocidos.")
            return

        options = [file_labels.get(fz, fz) for fz in known]
        selected = xbmcgui.Dialog().multiselect("¿Qué deseas importar?", options,
                                                preselect=list(range(len(options))))
        if selected is None or len(selected) == 0: return

        files_to_restore = [known[i] for i in selected]
        restored = 0
        with zipfile.ZipFile(f, 'r') as zf:
            for fz in files_to_restore:
                if fz == '__snapshots__':
                    sd = os.path.join(p, 'snapshots')
                    if not os.path.exists(sd): os.makedirs(sd)
                    for sf in snap_files:
                        data = zf.read(sf)
                        with open(os.path.join(sd, os.path.basename(sf)), 'wb') as f_out:
                            f_out.write(data)
                        restored += 1
                    continue
                if fz == '__cache__':
                    for cf in cache_files:
                        data = zf.read(cf)
                        with open(os.path.join(p, cf), 'wb') as f_out:
                            f_out.write(data)
                        restored += 1
                    continue
                dest_path = os.path.join(p, fz)
                if fz in mergeable and os.path.exists(dest_path):
                    choice = xbmcgui.Dialog().select(file_labels[fz],
                        ["Sustituir (borrar actual)", "Añadir (fusionar con actual)", "Omitir"])
                    if choice == 2 or choice == -1: continue
                    elif choice == 1:
                        try:
                            with open(dest_path, 'r', encoding='utf-8') as fh: current = json.load(fh)
                            with zf.open(fz) as zfile: backup = json.load(zfile)
                            if isinstance(current, list) and isinstance(backup, list):
                                merged = current + [x for x in backup if x not in current]
                                with open(dest_path, 'w', encoding='utf-8') as fh: json.dump(merged, fh, ensure_ascii=False)
                                restored += 1; continue
                            elif isinstance(current, dict) and isinstance(backup, dict):
                                current.update(backup)
                                with open(dest_path, 'w', encoding='utf-8') as fh: json.dump(current, fh, ensure_ascii=False)
                                restored += 1; continue
                        except Exception: pass
                resolved = os.path.realpath(os.path.join(p, fz))
                if not resolved.startswith(os.path.realpath(p)):
                    continue
                zf.extract(fz, p)
                restored += 1

        xbmcgui.Dialog().ok("Importación Completa", "Se restauraron {0} elementos.".format(restored))
        xbmc.executebuiltin("Container.Refresh")

    except Exception as e:
        xbmcgui.Dialog().ok("Error", "Fallo al importar:\n{0}".format(e))

def _export_snapshot_menu():
    # 1. Listar disponibles
    sd = _get_snapshot_dir()
    files = sorted([f for f in os.listdir(sd) if f.endswith('.json')], reverse=True)
    
    if not files:
        xbmcgui.Dialog().notification("EspaDaily", "No hay instantáneas para exportar", xbmcgui.NOTIFICATION_WARNING)
        return

    # Formatear nombres para el diálogo
    display_list = []
    for f in files:
        ts_str = f.replace("instantaneas_espadaily_", "").replace("snapshot_", "").replace(".json", "")
        # Intentar formatear fecha si es posible
        try:
             date_str = f"{ts_str[6:8]}/{ts_str[4:6]}/{ts_str[0:4]} {ts_str[9:11]}:{ts_str[11:13]}"
             display_list.append(date_str)
        except Exception:
             display_list.append(f) # Fallback

    # 2. Selección múltiple
    sel = xbmcgui.Dialog().multiselect("Seleccionar instantáneas a exportar", display_list)
    if not sel: return
    
    # 3. Elegir destino
    dest_folder = xbmcgui.Dialog().browse(0, 'Exportar a...', 'files', '', False, False, '')
    if not dest_folder: return
    
    # 4. Copiar archivos
    count = 0
    import shutil
    try:
        for idx in sel:
            filename = files[idx]
            src = os.path.join(sd, filename)
            dst = os.path.join(dest_folder, filename)
            shutil.copy2(src, dst)
            count += 1
        
        xbmcgui.Dialog().notification("EspaDaily", f"{count} instantáneas exportadas", xbmcgui.NOTIFICATION_INFO)
        
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al exportar:\n{str(e)}")

def _export_favorites():
    """Exporta solo la lista de favoritos principales (favorites.json)"""
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("EspaDaily", "No hay favoritos para exportar", xbmcgui.NOTIFICATION_INFO)
        return
        
    ts = time.strftime("%Y%m%d_%H%M")
    default_name = f"espadaily_favoritos_{ts}.json"
    
    d = xbmcgui.Dialog().browse(3, 'Guardar Favoritos', 'files', '', False, False, default_name)
    if not d: return
    
    if os.path.isdir(d):
        d = os.path.join(d, default_name)
    elif not d.lower().endswith(".json"):
        d += ".json"
        
    try:
        with open(d, 'w', encoding='utf-8') as f:
            json.dump(favs, f, ensure_ascii=False, indent=2)
        
        xbmcgui.Dialog().ok("Exportar Favoritos", f"Guardado correctamente:\n{os.path.basename(d)}\n\nElementos: {len(favs)}")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", str(e))

def _import_favorites():
    """Importa lista de favoritos desde JSON"""
    f = xbmcgui.Dialog().browse(1, 'Seleccionar archivo de favoritos', 'files', '.json', False, False, '')
    if not f: return
    
    try:
        with open(f, 'r', encoding='utf-8') as fp:
            new_favs = json.load(fp)
        
        if not isinstance(new_favs, list):
            xbmcgui.Dialog().ok("Error", "El archivo no es una lista válida de favoritos.")
            return


        if new_favs and 'url' not in new_favs[0]:
            xbmcgui.Dialog().ok("Error", "El formato del JSON no parece ser de favoritos de EspaDaily.")
            return

        opts = ["Fusionar (Añadir nuevos)", "Reemplazar lista completa"]
        sel = xbmcgui.Dialog().select("¿Cómo importar?", opts)
        if sel < 0: return
        
        if sel == 0:
    
            added = 0
            for item in new_favs:
                if core_settings.add_favorite(item['title'], item['url'], item['icon'], item['platform'], item['action'], item['params']):
                    added += 1
            xbmcgui.Dialog().notification("EspaDaily", f"{added} favoritos añadidos", xbmcgui.NOTIFICATION_INFO)
            
        else:
            # Sobreescribir manualmente ya que core_settings no expone set_favorites

            profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
            fav_file = os.path.join(profile, 'favorites.json')
            with open(fav_file, 'w', encoding='utf-8') as out:
                json.dump(new_favs, out)
            xbmcgui.Dialog().notification("EspaDaily", "Lista reemplazada", xbmcgui.NOTIFICATION_INFO)
            
        xbmc.executebuiltin("Container.Refresh")
            
    except Exception as e:
        xbmcgui.Dialog().ok("Error", str(e))

def _import_snapshot_menu():
    # 1. Seleccionar archivo .json
    f = xbmcgui.Dialog().browse(1, 'Seleccionar Instantánea', 'files', '.json', False, False, '')
    if not f: return
    

    # Copiar a la carpeta de instantaneas
    
    sd = _get_snapshot_dir()
    fname = os.path.basename(f)
    dest = os.path.join(sd, fname)
    
    # Preguntar si sobreescribir si ya existe
    if os.path.exists(dest):
        if not xbmcgui.Dialog().yesno("EspaDaily", "Esta instantánea ya existe.\n¿Sobrescribir?"):
            return
            
    try:
        import shutil
        shutil.copy2(f, dest)
        xbmcgui.Dialog().notification("EspaDaily", "Instantánea importada con éxito", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al importar:\n{str(e)}")
        
def _toggle_advanced_search():
    new_state = not core_settings.is_advanced_search_active()
    core_settings.set_advanced_search_active(new_state)
    msg = "MENÚ AVANZADO ACTIVADO" if new_state else "BÚSQUEDA DIRECTA (SIMPLE)"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _advanced_search_menu():
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    # === CATÁLOGOS OFICIALES ===
    li = xbmcgui.ListItem(label="[B]— CATÁLOGOS OFICIALES —[/B]")
    li.setArt({'icon': _mi('info.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Buscar en Catálogo de Atresplayer")
    li.setArt({'icon': _mi('cat_atres.png')})
    li.setInfo('video', {'plot': "Busca directamente en el catálogo oficial de Atresplayer por nombre aproximado."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_atres_catalog"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Buscar en Catálogo de Mediaset")
    li.setArt({'icon': _mi('cat_mediaset.png')})
    li.setInfo('video', {'plot': "Busca directamente en el catálogo oficial de Mediaset (Mitele) por nombre aproximado."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_mediaset_catalog"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Buscar en Catálogo de RTVE")
    li.setArt({'icon': _mi('cat_rtve.png')})
    li.setInfo('video', {'plot': "Busca directamente en el catálogo oficial de RTVE Play por nombre aproximado."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_rtve_catalog"), listitem=li, isFolder=True)

    # === BÚSQUEDAS BÁSICAS ===
    li = xbmcgui.ListItem(label="[B]— BÚSQUEDAS BÁSICAS —[/B]")
    li.setArt({'icon': _mi('info.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda Estándar (Por Título)")
    li.setArt({'icon': _mi('busqueda.png')})
    _add_fav_cm(li, "Búsqueda Estándar", "search", "execute_adv_search", {"mode": ""})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode=""), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda de Películas (Modo Cine)")
    li.setArt({'icon': _mi('cat_peliculas.png')})
    li.setInfo('video', {'plot': "Optimiza la búsqueda para encontrar películas completas en castellano.\nPrueba variantes como 'pelicula completa', 'castellano', etc."})
    _add_fav_cm(li, "Búsqueda de Películas", "search", "execute_adv_search", {"mode": "movie"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="movie"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda de Series (Temporada + Capítulo)")
    li.setArt({'icon': 'DefaultTVShows.png'})
    li.setInfo('video', {'plot': "Introduce el nombre de la serie y el addon te pedirá número de temporada y capítulo.\nConstruye automáticamente la mejor query posible."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="series"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Buscar en Webs P2P (Elementum)")
    li.setArt({'icon': _mi('adv_p2p.png')})
    li.setInfo('video', {'plot': "Busca torrents en webs P2P a través del addon Elementum.\nRequiere tener Elementum instalado."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_elementum_prompt"), listitem=li, isFolder=True)

    if _has_ace_player() and core_settings.is_acestream_enabled():
        li = xbmcgui.ListItem(label="Buscar en AceStream (¿VPN?)")
        li.setArt({'icon': _mi('adv_acestream.png')})
        li.setInfo('video', {'plot': "Buscador de identificadores AceStream.\n\nEsta herramienta consulta unicamente la API publica oficial de AceStream (search.acestream.net). No aloja, distribuye ni enlaza a ningun contenido concreto. Funciona igual que cualquier motor de busqueda web, donde se escribe un termino y se obtienen los resultados publicos indexados por la propia red AceStream.\n\nLa reproduccion de cualquier contenido encontrado es responsabilidad exclusiva del usuario."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_acestream_prompt"), listitem=li, isFolder=True)

    # === FILTROS DE DURACIÓN ===
    li = xbmcgui.ListItem(label="[B]— FILTROS DE DURACIÓN —[/B]")
    li.setArt({'icon': _mi('info.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda de Vídeos Largos (+20 min)")
    li.setArt({'icon': _mi('adv_videos_largos.png')})
    li.setInfo('video', {'plot': "Filtra los resultados para mostrar solo vídeos de más de 20 minutos.\nIdeal para encontrar episodios completos o películas."})
    _add_fav_cm(li, "Vídeos Largos (+20 min)", "search", "execute_adv_search", {"mode": "long"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="long"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda de Vídeos Cortos (-10 min)")
    li.setArt({'icon': _mi('adv_videos_cortos.png')})
    li.setInfo('video', {'plot': "Filtra los resultados para mostrar solo vídeos de menos de 10 minutos.\nIdeal para buscar clips, canciones o sketches."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="short"), listitem=li, isFolder=True)

    # === FILTROS TEMPORALES ===
    li = xbmcgui.ListItem(label="[B]— FILTROS TEMPORALES —[/B]")
    li.setArt({'icon': _mi('info.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Contenido de Hoy (Últimas 24h)")
    li.setArt({'icon': _mi('adv_hoy.png')})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en las últimas 24 horas.\nPerfecto para informativos y programas diarios."})
    _add_fav_cm(li, "Contenido de Hoy (24h)", "search", "execute_adv_search", {"mode": "recent_24h"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_24h"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Contenido de Esta Semana")
    li.setArt({'icon': _mi('adv_semana.png')})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en los últimos 7 días."})
    _add_fav_cm(li, "Contenido de esta Semana", "search", "execute_adv_search", {"mode": "recent_week"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_week"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Contenido de Este Mes")
    li.setArt({'icon': _mi('adv_mes.png')})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en los últimos 30 días."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_month"), listitem=li, isFolder=True)

    # === FILTROS DE CALIDAD E IDIOMA ===
    li = xbmcgui.ListItem(label="[B]— CALIDAD E IDIOMA —[/B]")
    li.setArt({'icon': _mi('info.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Solo HD (Alta Definición)")
    li.setArt({'icon': _mi('adv_hd.png')})
    li.setInfo('video', {'plot': "Filtra para mostrar únicamente vídeos en HD (720p o superior)."})
    _add_fav_cm(li, "Solo HD", "search", "execute_adv_search", {"mode": "hd"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="hd"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Solo Contenido en Español")
    li.setArt({'icon': _mi('adv_idioma.png')})
    li.setInfo('video', {'plot': "Filtra para mostrar solo vídeos con idioma español configurado."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="spanish"), listitem=li, isFolder=True)

    # === FILTROS AVANZADOS ===
    li = xbmcgui.ListItem(label="[B]— FILTROS AVANZADOS —[/B]")
    li.setArt({'icon': _mi('info.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda por Usuario / Canal")
    li.setArt({'icon': _mi('adv_usuario.png')})
    li.setInfo('video', {'plot': "Busca contenido subido ÚNICAMENTE por un usuario específico (ej: 'rtve', 'atresplayer').\n\nPuedes filtrar por texto dentro del canal."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="user"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda Inversa (Excluir palabras)")
    li.setArt({'icon': 'DefaultIconError.png'})
    li.setInfo('video', {'plot': "Busca X pero EXCLUYENDO resultados que contengan ciertas palabras.\nÚtil para evitar 'trailer', 'making of', 'clip', etc."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="exclude"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda Exacta (Sin limpieza)")
    li.setArt({'icon': _mi('adv_exacta.png')})
    li.setInfo('video', {'plot': "Busca EXACTAMENTE lo que escribas, sin intentar limpiar el título ni quitar paréntesis."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="exact"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda por Palabras Clave")
    li.setArt({'icon': _mi('adv_palabras.png')})
    li.setInfo('video', {'plot': "Extrae solo las palabras importantes (más de 3 letras) y busca por ellas. Útil si el título oficial es muy largo o complejo."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="keywords"), listitem=li, isFolder=True)

    # === UTILIDADES ===
    li = xbmcgui.ListItem(label="[B]— UTILIDADES —[/B]")
    li.setArt({'icon': _mi('info.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="Repetir Última Búsqueda (con filtros)")
    li.setArt({'icon': _mi('adv_repetir.png')})
    li.setInfo('video', {'plot': "Toma la última búsqueda de tu historial y te permite ejecutarla con cualquiera de los filtros anteriores."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="repeat_last"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Búsqueda Múltiple (varios términos)")
    li.setArt({'icon': _mi('adv_multiple.png')})
    li.setInfo('video', {'plot': "Busca varios términos separados por comas en Dailymotion.\nEjemplo: 'saber y ganar, pasapalabra, el hormiguero'"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="multi_search"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _execute_adv_search(mode):
    ep = None
    exclude_words = None
    q = ""
    

    
    # --- BUSQUEDA POR USUARIO ---
    if mode == "user":
        kb = xbmc.Keyboard('', 'Introduce el ID de Usuario/Canal')
        kb.doModal()
        if not kb.isConfirmed(): return
        user = kb.getText()
        if not user: return
        ep = {"owner": user}
        

        kb = xbmc.Keyboard('', f'Buscar en canal de {user} (Opcional, vacío = últimos vídeos)')
        kb.doModal()
        if kb.isConfirmed():
            q = kb.getText()
        # Si vacio, buscamos lo ultimo de ese usuario
        if q: _add_to_history(q)
        _lfd(q if q else " ", "", mode=mode, extra_params=ep, nh=True)
        return
    
    # --- SERIES SEARCH (ask for name, season, episode) ---
    if mode == "series":
        kb = xbmc.Keyboard('', 'Nombre de la Serie')
        kb.doModal()
        if not kb.isConfirmed(): return
        series_name = kb.getText()
        if not series_name: return
        

        kb = xbmc.Keyboard('', 'Número de Temporada (vacío = cualquiera)')
        kb.doModal()
        if not kb.isConfirmed(): return
        season = kb.getText()
        
        # Pedir capítulo
        kb = xbmc.Keyboard('', 'Número de Capítulo (vacío = cualquiera)')
        kb.doModal()
        if not kb.isConfirmed(): return
        episode = kb.getText()
        

        q = series_name
        if season:
            q += f" T{season}" # Format: T1, T2, etc.
        if episode:
            q += f" Capitulo {episode}"
            # Intentar formatos alternativos
        
        _add_to_history(q)
        _lfd(q, "", mode="", extra_params=None, nh=True)
        return
    
    # --- EXCLUDE SEARCH (ask for search + words to exclude) ---
    if mode == "exclude":
        kb = xbmc.Keyboard('', '¿Qué quieres buscar?')
        kb.doModal()
        if not kb.isConfirmed(): return
        q = kb.getText()
        if not q: return
        
        kb = xbmc.Keyboard('trailer, clip, making of', 'Palabras a EXCLUIR (separadas por coma)')
        kb.doModal()
        if not kb.isConfirmed(): return
        exclude_text = kb.getText()
        if exclude_text:
            exclude_words = [w.strip().lower() for w in exclude_text.split(",") if w.strip()]
        
        _add_to_history(q)
        _lfd_with_exclusions(q, "", exclude_words)
        return
    
    # --- REPEAT LAST (take from history) ---
    if mode == "repeat_last":
        h = _load_history()
        if not h:
            xbmcgui.Dialog().notification("EspaDaily", "No hay historial", xbmcgui.NOTIFICATION_WARNING)
            return
        

        filters = [
            ("Sin filtros (Estándar)", "", None),
            ("Modo Cine (Películas)", "movie", None),
            ("Solo +20 min", "", {"longer_than": 20}),
            ("Solo -10 min", "", {"shorter_than": 10}),
            ("Solo HD", "", {"hd": 1}),
            ("Solo Español", "", {"language": "es"}),
            ("Últimas 24h", "", {"created_after": int(time.time()) - 86400}),
            ("Última Semana", "", {"created_after": int(time.time()) - 604800}),
        ]
        
        opts = [f[0] for f in filters]
        sel = xbmcgui.Dialog().select(f"Repetir: '{h[0]}' con filtro...", opts)
        if sel < 0: return
        
        chosen_mode, chosen_ep = filters[sel][1], filters[sel][2]
        _lfd(h[0], "", mode=chosen_mode, extra_params=chosen_ep, nh=True)
        return
    

    title = 'Búsqueda Avanzada'
    kb = xbmc.Keyboard('', title)
    kb.doModal()
    if not kb.isConfirmed(): return
    q = kb.getText()
    if not q: return
    
    _add_to_history(q)
    

    if mode == "long":
        ep = {"longer_than": 20}
    elif mode == "short":
        ep = {"shorter_than": 10}
    elif mode == "recent_24h":
        ep = {"created_after": int(time.time()) - 86400, "sort": "recent"}
    elif mode == "recent_week":
        ep = {"created_after": int(time.time()) - 604800, "sort": "recent"}
    elif mode == "recent_month":
        ep = {"created_after": int(time.time()) - 2592000, "sort": "recent"}
    elif mode == "hd":
        ep = {"hd": 1}
    elif mode == "spanish":
        ep = {"language": "es"}
    
    ep = {} if ep is None else ep
    _lfd(q, "", mode=mode, extra_params=ep, nh=True)

def _lfd_with_exclusions(q, ot, exclude_words):
    """Special version of _lfd that filters out results containing excluded words."""
    cq = _clean_title(q)
    rs = _sr(cq)
    if not rs and cq != q: rs = _sr(q)
    
    if not rs:
        xbmcgui.Dialog().notification("EspaDaily", "No se encontraron resultados", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    # Filter out excluded words
    if exclude_words:
        filtered = []
        for r in rs:
            title_lower = r.get("title", "").lower()
            if not any(ex in title_lower for ex in exclude_words):
                filtered.append(r)
        rs = filtered
    
    if not rs:
        xbmcgui.Dialog().notification("EspaDaily", "Todos los resultados fueron excluidos", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    sr = _gsr(cq, rs, "")[:25]
    
    if not sr:
        xbmcgui.Dialog().notification("EspaDaily", "Sin coincidencias relevantes", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    min_dur = core_settings.get_min_duration() * 60
    for sc, v in sr:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        
        if min_dur > 0 and du < min_dur: continue
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url") or ot
        
        lb = f"{vt} ({int(sc*100)}% match)"

        li = xbmcgui.ListItem(label=lb); li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Subido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        li.addContextMenuItems([("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})"), ("Abrir en el navegador", f"RunPlugin({_u(action='dm_open_browser', url=vi)})")])

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="pv", vid=vi, title=urllib.parse.quote(vt)), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _toggle_palantir_search():
    current = core_settings.is_palantir_search_active()
    core_settings.set_palantir_search_active(not current)
    xbmc.executebuiltin("Container.Refresh")

def _p3_b64encode(value):
    """Implementación local de la codificación de Palantir 3"""
    if not isinstance(value, bytes):
        value = str(value).encode()
    value = base64.b64encode(value)
    length = len(value)
    part = int(length / 4)
    value = re.sub(b'=', b'', value)
    # Pa.-..-. lantir reversible encoding: reverse 1/4 and 3/4
    encoded = value[:part][::-1] + value[part:][::-1]
    return urllib.parse.quote(encoded.decode())

def _search_palantir(query):
    if not query: return

    if core_settings.are_external_integrations_disabled():
        return

    # Comprobar si Pala.-.- .-.- ntir está instalado
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.palantir3)"):
        xbmcgui.Dialog().ok("EspaDaily", "El addon Palantir 3 no parece estar instalado.\n\nEsta función requiere Palantir 3 para funcionar.")
        return

    # Item para Palantir
    # P3Item serializado
    item_dict = {
        "action": "buscar3",
        "sql": f"rebuscar {query}",
        "label": query
    }
    
    # Pala-.-.--.- ntir 3 usa codificacion propia
    # El item va como string repr de dict
    encoded_item = _p3_b64encode(str(item_dict))
    
    # Pala-.-..-.- ntir 3 usa ventana HOME (10000) para estado
    # Propiedades para saltarse el teclado
    window = xbmcgui.Window(10000)
    window.setProperty("p3_play", "true")
    window.setProperty("p3_item_buscar", encoded_item)
    
    # Lanzar busqueda en Pala.-.--.-- ntir 3 via plugin://
    # ActivateWindow para abrir resultados
    plugin_url = f"plugin://plugin.video.palantir3/?{encoded_item}"
    
    _l(f"Enviando búsqueda a Palantir 3: {query}")
    _l(f"URL generada: {plugin_url}")
    
    # Container.Update para que al volver atras no se quede en Palantir
    xbmc.executebuiltin(f"Container.Update({plugin_url})")


    # Si aparece un diálogo de OK y no ha cambiado el contenedor, es que ha fallado
    start_watch = time.time()
    while time.time() - start_watch < 15: # 15 segundos de margen
        xbmc.sleep(500)
        

        if xbmc.getInfoLabel("Container.PluginName") == "plugin.video.palantir3":
            return


        if xbmc.getCondVisibility("Window.IsActive(okdialog)"):


            while xbmc.getCondVisibility("Window.IsActive(okdialog)"):
                xbmc.sleep(500)
            

            xbmc.sleep(500)
            if xbmc.getInfoLabel("Container.PluginName") != "plugin.video.palantir3":
                if xbmcgui.Dialog().yesno("EspaDaily", f"Palantir no ha encontrado resultados para:\n[B]{query}[/B]\n\n¿Quieres editar el texto y reintentar?"):
                    kb = xbmc.Keyboard(query, 'Editar búsqueda Palantir')
                    kb.doModal()
                    if kb.isConfirmed():
                        nq = kb.getText()
                        if nq: _search_palantir(nq)
            return

def _search_elementum(query):
    """Busca en Elementum con verificación de instalación."""
    if not query: return
    
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
        xbmcgui.Dialog().ok("EspaDaily", 
            "El addon Elementum no está instalado.\n\n"
            "Esta función requiere Elementum para buscar torrents en webs como 1337x, RARBG, etc.\n\n"
            "Puedes instalarlo desde el repositorio oficial de Kodi o desde GitHub.")
        return
    
    # Abrir búsqueda en Elementum
    elementum_url = f"plugin://plugin.video.elementum/search?q={urllib.parse.quote(query)}"
    xbmc.executebuiltin(f"Container.Update({elementum_url})")


def _search_elementum_prompt():
    kb = xbmc.Keyboard('', 'Buscar en Webs P2P (Elementum)')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    _search_elementum(kb.getText().strip())


def _has_ace_player():
    return (xbmc.getCondVisibility("System.HasAddon(program.plexus)")
            or xbmc.getCondVisibility("System.HasAddon(script.module.horus)"))


def _acestream_available():
    return _has_ace_player() and core_settings.is_acestream_enabled()


def _search_acestream_prompt():
    if not _acestream_available():
        xbmcgui.Dialog().notification("EspaDaily", "Busqueda AceStream no disponible", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    kb = xbmc.Keyboard('', 'Buscar en AceStream')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    query = kb.getText().strip()
    _search_acestream_results(query)


def _toggle_acestream_server_mode():
    new_mode = core_settings.cycle_acestream_server_mode()
    labels = {"auto": "Automatico (local + publico)", "publico": "Siempre publico", "local": "Solo local"}
    xbmcgui.Dialog().notification("AceStream", "Servidor: {0}".format(labels.get(new_mode, new_mode)), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _toggle_acestream_enabled():
    if not _has_ace_player() and not core_settings.is_acestream_enabled():
        xbmcgui.Dialog().notification("EspaDaily", "Necesitas Plexus o Horus instalado", xbmcgui.NOTIFICATION_INFO, 3000)
        return
    new_state = not core_settings.is_acestream_enabled()
    core_settings.set_acestream_enabled(new_state)
    msg = "Busqueda AceStream activada" if new_state else "Busqueda AceStream desactivada"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")


def _search_acestream_results(query):
    h = int(sys.argv[1])
    if not _acestream_available():
        xbmcgui.Dialog().notification("EspaDaily", "Busqueda AceStream no disponible", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    if not query:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    encoded_q = urllib.parse.quote_plus(query)
    _ace_mode = core_settings.get_acestream_server_mode()
    _local_url = "http://127.0.0.1:6878/server/api?method=search&query={0}&page=0".format(encoded_q)
    _public_url = "https://search.acestream.net/?method=search&api_key=test_api_key&api_version=1&query={0}&page=0".format(encoded_q)
    if _ace_mode == "publico":
        api_urls = [("servidor publico", _public_url)]
    elif _ace_mode == "local":
        api_urls = [("motor local", _local_url)]
    else:
        api_urls = [("motor local", _local_url), ("servidor publico", _public_url)]

    progress = xbmcgui.DialogProgressBG()
    try:
        progress.create("AceStream", "Buscando: {0}".format(query))
    except Exception:
        progress = None

    data = None
    results = []
    last_error = None
    used_endpoint = ""
    last_state = None

    from urllib.request import urlopen as _urlopen, Request as _Request
    for label, api_url in api_urls:
        try:
            xbmc.log("[espadaily] AceStream search via {0}".format(label), xbmc.LOGINFO)
            req = _Request(api_url, headers={"User-Agent": "Mozilla/5.0 (Kodi)"})
            resp = _urlopen(req, timeout=10)
            raw = resp.read().decode("utf-8", errors="replace")
            xbmc.log("[espadaily] AceStream {0} response ({1} chars)".format(label, len(raw)), xbmc.LOGINFO)
            try:
                parsed = json.loads(raw)
            except Exception as je:
                last_state = "error"
                last_error = "Respuesta no es JSON ({0}): {1}".format(label, str(je))
                continue
            if isinstance(parsed, dict) and parsed.get("error"):
                last_state = "error"
                last_error = "{0}: {1}".format(label, parsed.get("error"))
                continue
            _res = []
            if isinstance(parsed, list):
                _res = parsed
            elif isinstance(parsed, dict):
                _res_obj = parsed.get("result") or {}
                _res = _res_obj.get("results") or parsed.get("results") or []
            if not isinstance(_res, list):
                _res = []
            if not _res:
                last_state = "empty"
                last_error = "Sin resultados en {0}".format(label)
                xbmc.log("[espadaily] AceStream {0}: respuesta valida pero sin resultados, probando siguiente".format(label), xbmc.LOGINFO)
                continue
            data = parsed
            results = _res
            used_endpoint = label
            last_state = "results"
            break
        except Exception as e:
            last_state = "error"
            last_error = "{0}: {1}".format(label, type(e).__name__)
            xbmc.log("[espadaily] AceStream {0} failed: {1}".format(label, type(e).__name__), xbmc.LOGWARNING)
            continue

    if progress:
        try: progress.close()
        except Exception: pass

    if data is None:
        if last_state == "empty":
            xbmcgui.Dialog().ok("AceStream", "Sin resultados para: {0}".format(query))
            xbmcplugin.endOfDirectory(h, succeeded=True)
        else:
            xbmcgui.Dialog().ok("Buscar en AceStream",
                "No se pudo realizar la busqueda.\n\n"
                "Detalle: {0}".format(last_error or "error desconocido"))
            xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    xbmc.log("[espadaily] AceStream search returned {0} results from {1}".format(len(results), used_endpoint), xbmc.LOGINFO)

    xbmcplugin.setPluginCategory(h, "AceStream: {0}".format(query))
    xbmcplugin.setContent(h, "videos")

    for item in results:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or item.get("title") or "Sin nombre")
        infohash = str(item.get("infohash") or item.get("id") or "").strip()
        if not infohash:
            continue

        categories = item.get("categories") or []
        if not isinstance(categories, list):
            categories = [categories] if categories else []
        categories = [str(c) for c in categories if c]

        availability = item.get("availability") or 0
        try:
            availability = float(availability)
            if availability > 1:
                availability = availability / 100.0
        except (TypeError, ValueError):
            availability = 0

        plot_lines = []
        if categories:
            plot_lines.append("Categoria: {0}".format(", ".join(categories)))
        desc = str(item.get("description") or "").strip()
        if desc:
            plot_lines.append(desc)
        if availability > 0:
            plot_lines.append("Disponibilidad: {0:.0f}%".format(availability * 100))
        plot = "\n".join(plot_lines) if plot_lines else name

        li = xbmcgui.ListItem(label=name)
        li.setInfo("video", {"title": name, "plot": plot})
        li.setArt({"icon": "DefaultAddonTvInfo.png"})
        li.setProperty("IsPlayable", "true")
        _add_fav_cm(li, name, "acestream", "play_ace_result", {"infohash": infohash, "name": name})
        play_url = _u(action="play_ace_result", infohash=infohash, name=name)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def _play_ace_result(infohash, name):
    xbmc.log("[espadaily] _play_ace_result called: infohash={0} name={1}".format(infohash, name), xbmc.LOGINFO)
    h = int(sys.argv[1])

    if not infohash:
        xbmc.log("[espadaily] _play_ace_result aborted: empty infohash", xbmc.LOGWARNING)
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return

    has_plexus = xbmc.getCondVisibility("System.HasAddon(program.plexus)")
    has_horus = xbmc.getCondVisibility("System.HasAddon(script.module.horus)")
    if not (has_plexus or has_horus):
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok(
            "EspaDaily",
            "Para reproducir enlaces Acestream necesitas uno de estos addons:\n\n"
            "  • Plexus (program.plexus)\n"
            "  • Horus (script.module.horus)\n\n"
            "Instálalo y vuelve a intentarlo.",
        )
        return

    try:
        _add_watch_entry("acestream://" + infohash, name or infohash[:12])
        xbmc.log("[espadaily] _play_ace_result: watch entry added", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log("[espadaily] _play_ace_result: _add_watch_entry failed: {0}".format(e), xbmc.LOGERROR)

    if has_plexus:
        ace_q = urllib.parse.quote("acestream://" + infohash, safe="")
        target = "plugin://program.plexus/?url={0}&mode=1&name=Acestream".format(ace_q)
    else:
        target = "plugin://script.module.horus/?action=play&id={0}".format(infohash)

    # Encadenar via setResolvedUrl (no PlayMedia): Android Kodi 21 muere si dos
    # busydialogs estan activos a la vez (xbmc/xbmc#24526).
    li = xbmcgui.ListItem(path=target)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(h, True, li)


_CATALOG_CACHE_TTL = 86400  # 24h

def _get_cached_catalog(cache_key, fetch_fn):
    """Devuelve el catálogo desde caché si está fresco (<24h), si no lo reescanea."""
    try:
        cached = _load_cache(cache_key)
        if isinstance(cached, dict) and isinstance(cached.get("ts"), (int, float)) and isinstance(cached.get("data"), dict):
            age = time.time() - cached["ts"]
            if age < _CATALOG_CACHE_TTL and cached["data"]:
                return cached["data"]
    except Exception:
        pass
    try:
        data = fetch_fn()
    except Exception:
        data = {}
    if data:
        try:
            _save_cache(cache_key, {"ts": time.time(), "data": data})
        except Exception:
            pass
    return data


def _catalog_fuzzy_search(query, catalog):
    if not catalog or not isinstance(catalog, dict):
        return []
    q = (query or "").strip().lower()
    if not q:
        return []
    all_items = []
    for cat_name, cat_items in catalog.items():
        if not isinstance(cat_items, list):
            continue
        for item in cat_items:
            if not isinstance(item, dict):
                continue
            t = str(item.get("t") or item.get("title") or "")
            u = str(item.get("u") or item.get("url") or "")
            th = str(item.get("th") or item.get("thumbnail") or "")
            p = str(item.get("p") or item.get("plot") or "")
            if t:
                all_items.append({"title": t, "url": u, "thumb": th, "plot": p, "category": str(cat_name)})
    # Dedup: misma key (título normalizado) solo aparece una vez, con el mejor score
    # y preferiblemente con URL navegable.
    best = {}
    for prog in all_items:
        tl = prog["title"].lower()
        if not tl:
            continue
        if q in tl:
            score = 0.95 + (len(q) / max(len(tl), 1)) * 0.05
        else:
            try:
                score = difflib.SequenceMatcher(None, q, tl).ratio()
            except Exception:
                score = 0.0
        if score <= 0.3:
            continue
        key = tl.strip()
        current = best.get(key)
        if current is None:
            best[key] = (score, prog)
        else:
            cur_score, cur_prog = current
            # Sustituir si mejor score, o mismo score pero URL navegable
            if score > cur_score or (score == cur_score and prog.get("url") and not cur_prog.get("url")):
                best[key] = (score, prog)
    scored = list(best.values())
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[:20]


def _search_atresplayer_catalog():
    kb = xbmc.Keyboard('', 'Buscar en Catálogo de Atresplayer')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    query = kb.getText().strip()
    try:
        catalog = _get_cached_catalog("catalog_atresplayer", connector._fetch_all_atres_catalog)
    except Exception as e:
        xbmcgui.Dialog().ok("EspaDaily", f"Error al obtener el catálogo: {str(e)}")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    if not catalog:
        xbmcgui.Dialog().ok("EspaDaily", "No se pudo obtener el catálogo de Atresplayer.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    results = _catalog_fuzzy_search(query, catalog)
    if not results:
        if xbmcgui.Dialog().yesno("EspaDaily", f"No se encontró '[B]{query}[/B]' en el catálogo de Atresplayer.\n\n¿Buscar en Dailymotion?"):
            _lfd(query, "")
        else:
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    h = int(sys.argv[1])
    for score, prog in results:
        pct = int(score * 100)
        label = f"[B]{prog['title']}[/B] [COLOR gray]({prog['category']})[/COLOR] [COLOR lime]{pct}%[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': prog['thumb'] or 'DefaultVideo.png', 'thumb': prog['thumb']})
        li.setInfo('video', {'plot': prog['plot'] or f"{prog['title']} — {prog['category']} ({pct}%)"})
        if prog['url']:
            nav_url = _u(action="fs", au=prog['url'], st=prog['title'], sth=prog['thumb'])
        else:
            nav_url = _u(action="lfr", q=prog['title'], ot=prog['thumb'])
        xbmcplugin.addDirectoryItem(handle=h, url=nav_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _search_mediaset_catalog():
    kb = xbmc.Keyboard('', 'Buscar en Catálogo de Mediaset')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    query = kb.getText().strip()
    try:
        catalog = _get_cached_catalog("catalog_mediaset", connector._fetch_all_mediaset_catalog)
    except Exception as e:
        xbmcgui.Dialog().ok("EspaDaily", f"Error al obtener el catálogo: {str(e)}")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    if not catalog:
        xbmcgui.Dialog().ok("EspaDaily", "No se pudo obtener el catálogo de Mediaset.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    results = _catalog_fuzzy_search(query, catalog)
    if not results:
        if xbmcgui.Dialog().yesno("EspaDaily", f"No se encontró '[B]{query}[/B]' en el catálogo de Mediaset.\n\n¿Buscar en Dailymotion?"):
            _lfd(query, "")
        else:
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    h = int(sys.argv[1])
    for score, prog in results:
        pct = int(score * 100)
        if prog['url']:
            suffix = ""
            nav_url = _u(action="fs_mediaset", purl=prog['url'], st=prog['title'], sth=prog['thumb'], cid="")
        else:
            suffix = " [COLOR gray][Internet][/COLOR]"
            nav_url = _u(action="lfr", q=prog['title'], ot=prog['thumb'])
        label = f"[B]{prog['title']}[/B] [COLOR gray]({prog['category']})[/COLOR] [COLOR lime]{pct}%[/COLOR]{suffix}"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': prog['thumb'] or 'DefaultVideo.png', 'thumb': prog['thumb']})
        plot = prog['plot'] or f"{prog['title']} — {prog['category']} ({pct}%)"
        if not prog['url']:
            plot += "\n[COLOR gray]Sin enlace directo a Mediaset — abrirá búsqueda en Dailymotion.[/COLOR]"
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=h, url=nav_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def _search_rtve_catalog():
    kb = xbmc.Keyboard('', 'Buscar en Catálogo de RTVE')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    query = kb.getText().strip()
    try:
        catalog = _get_cached_catalog("catalog_rtve", connector._fetch_all_rtve_catalog)
    except Exception as e:
        xbmcgui.Dialog().ok("EspaDaily", f"Error al obtener el catálogo: {str(e)}")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    if not catalog:
        xbmcgui.Dialog().ok("EspaDaily", "No se pudo obtener el catálogo de RTVE.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    results = _catalog_fuzzy_search(query, catalog)
    if not results:
        if xbmcgui.Dialog().yesno("EspaDaily", f"No se encontró '[B]{query}[/B]' en el catálogo de RTVE.\n\n¿Buscar en Dailymotion?"):
            _lfd(query, "")
        else:
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    h = int(sys.argv[1])
    for score, prog in results:
        pct = int(score * 100)
        label = f"[B]{prog['title']}[/B] [COLOR gray]({prog['category']})[/COLOR] [COLOR lime]{pct}%[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': prog['thumb'] or 'DefaultVideo.png', 'thumb': prog['thumb']})
        li.setInfo('video', {'plot': prog['plot'] or f"{prog['title']} — {prog['category']} ({pct}%)"})
        if prog['url']:
            nav_url = _u(action="fs_rtve", pid=prog['url'], st=prog['title'], sth=prog['thumb'])
        else:
            nav_url = _u(action="lfr", q=prog['title'], ot=prog['thumb'])
        xbmcplugin.addDirectoryItem(handle=h, url=nav_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


_TDT_JSON_URL = "https://www.tdtchannels.com/lists/tv.json"
_TDT_M3U_URL = "https://www.tdtchannels.com/lists/tv.m3u8"
_CUSTOM_IPTV_FILE = "custom_iptv.json"
_DM_SAVED_CHANNELS_FILE = "dm_saved_channels.json"
_tdt_json_cache = {"data": None}

def _load_custom_iptv():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    fp = os.path.join(p, _CUSTOM_IPTV_FILE)
    if not os.path.exists(fp): return []
    try:
        with open(fp, 'r', encoding='utf-8') as f: return json.load(f)
    except (json.JSONDecodeError, IOError): return []

def _save_custom_iptv(lists):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    fp = os.path.join(p, _CUSTOM_IPTV_FILE)
    try:
        with open(fp, 'w', encoding='utf-8') as f: json.dump(lists, f, ensure_ascii=False)
    except IOError: pass

def _load_dm_saved_channels():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    fp = os.path.join(p, _DM_SAVED_CHANNELS_FILE)
    if not os.path.exists(fp): return []
    try:
        with open(fp, 'r', encoding='utf-8') as f: return json.load(f)
    except (json.JSONDecodeError, IOError): return []

def _save_dm_saved_channels(channels):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    fp = os.path.join(p, _DM_SAVED_CHANNELS_FILE)
    try:
        with open(fp, 'w', encoding='utf-8') as f: json.dump(channels, f, ensure_ascii=False)
    except IOError: pass

def _parse_m3u_content(text):
    lines = text.splitlines()
    channels = []
    cur_name, cur_logo, cur_group = "", "", ""
    for line in lines:
        line = line.strip()
        if line.startswith("#EXTINF:"):
            cur_name = line.split(",", 1)[-1].strip() if "," in line else "Canal"
            m = re.search(r'tvg-logo="([^"]*)"', line)
            cur_logo = m.group(1) if m else ""
            m2 = re.search(r'group-title="([^"]*)"', line)
            cur_group = m2.group(1) if m2 else ""
        elif line and not line.startswith("#"):
            channels.append({"name": cur_name or "Canal", "url": line, "logo": cur_logo, "group": cur_group})
            cur_name, cur_logo, cur_group = "", "", ""
    return channels

def _render_m3u_channels(channels, source_label=""):
    h = int(sys.argv[1])
    xbmcplugin.setContent(h, 'videos')
    for ch in channels:
        label = ch["name"]
        if ch["group"]:
            label = "[COLOR gray][{0}][/COLOR] {1}".format(ch["group"], ch["name"])
        li = xbmcgui.ListItem(label=label)
        thumb = ch["logo"] or "DefaultAddonPVRClient.png"
        li.setArt({'icon': thumb, 'thumb': thumb})
        plot = "Canal: {0}".format(ch["name"])
        if ch["group"]: plot += "\nGrupo: {0}".format(ch["group"])
        if source_label: plot += "\n\n{0}".format(source_label)
        li.setInfo('video', {'title': ch["name"], 'plot': plot})
        cm = [("A\u00f1adir a Favoritos", "RunPlugin({0})".format(
            _u(action="add_favorite", title=ch["name"], fav_url=ch["url"], icon=thumb, platform="tdt", fav_action="play_tdt", params=json.dumps({}))
        ))]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_tdt", url=ch["url"], title=ch["name"]), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

# --- SLYGUY ADDON INSTALLER ---
_SLYGUY_REPO_ID = "repository.slyguy"
_SLYGUY_REPO_ZIP = "https://k.slyguy.xyz/repository.slyguy.zip"

def _slyguy_install(addon_id, addon_name):
    """Wrapper para SlyGuy: un solo repo, varios addons (Pluto, Samsung TV+, ...).

    El motor reusa el repo si ya esta registrado, asi que la segunda instalacion de
    otro addon SlyGuy no redescarga `repository.slyguy.zip`."""
    if _ek_addon_is_installed(addon_id):
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo {0}...".format(addon_name), xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    if _ek_try_recover_addon(addon_id):
        xbmcgui.Dialog().notification("EspaDaily", "{0} reactivado".format(addon_name), xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    _ek_install_repo_and_addon(addon_id, _SLYGUY_REPO_ID, _SLYGUY_REPO_ZIP, addon_name)

def _atresdaily_install():
    _ek_atresdaily_launch()

def _open_espatv():
    _ek_espatv_launch()

def _is_atresdaily_installed():
    """Verifica si atresdaily está instalado (cualquier versión)."""
    try:
        xbmcaddon.Addon("plugin.video.atresdaily")
        return True
    except Exception:
        return False

# Conservado un ciclo: tras wrappear _open_atresdaily/_atresdaily_install ya no
# tiene callers en el flujo nuevo. Eliminar en la proxima limpieza.
def _show_atresdaily_instructions():
    xbmcgui.Dialog().textviewer("Instalar AtresDaily",
        "[B]A\u00f1adir v\u00eda repositorio[/B]\n\n"
        "1. Ajustes \u2192 Explorador de archivos \u2192 A\u00f1adir fuente.\n"
        "   URL: https://espatv.github.io/atresdaily/\n"
        "   (Debe terminar en .io/atresdaily/, no la del navegador)\n"
        "   Nombre: atresdaily \u2192 Aceptar.\n\n"
        "2. Add-ons \u2192 cajita abierta (arriba izquierda) \u2192 Instalar desde archivo zip.\n"
        "   (Si salta aviso de seguridad: Ajustes \u2192 activar \"Or\u00edgenes desconocidos\")\n"
        "   Seleccionar fuente atresdaily \u2192 repository.atresdaily-1.0.1.zip.\n\n"
        "3. Cuando aparezca \"Add-on instalado\":\n"
        "   Instalar desde repositorio \u2192 AtresDaily Repository \u2192 Add-ons de v\u00eddeo \u2192 AtresDaily \u2192 Instalar.\n\n"
        "[B]V\u00eda ZIP[/B]\n\n"
        "Descargar el .zip desde github.com\n"
        "Add-ons \u2192 cajita \u2192 Instalar desde archivo zip \u2192 seleccionar el archivo.")

def _open_atresdaily():
    _ek_atresdaily_launch()

def live_tv_menu():
    h = int(sys.argv[1])

    _LCN = {
        "La 1": 1, "La 2": 2, "Antena 3": 3, "Cuatro": 4, "Telecinco": 5,
        "laSexta": 6, "Canal 24h": 7, "Teledeporte": 8, "Boing": 9,
        "Clan TVE": 10, "Neox": 11, "Nova": 12, "Mega": 13, "Energy": 14,
        "Factoría de Ficción": 15, "Atreseries": 16, "Be Mad": 17, "Divinity": 18,
    }

    channels = []

    for c in connector._RTVE_LIVE_CHANNELS:
        channels.append({
            'name': c['name'], 'logo': c['logo'],
            'action': 'play_live_rtve', 'params': {'video_id': c['video_id']},
            'plot': c.get('plot', ''),
        })

    for c in connector._MEDIASET_LIVE_CHANNELS:
        logo = connector._MEDIASET_CH_LOGOS.get(c['id'], 'DefaultAddonPVRClient.png')
        channels.append({
            'name': c['name'], 'logo': logo,
            'action': 'play_live_mediaset', 'params': {'url': c['url']},
            'plot': "Canal en directo: {0}".format(c['name']),
        })

    if _is_atresdaily_installed():
        try:
            for c in connector.get_live_channels():
                logo = connector._ATRES_CH_LOGOS.get(c['id'], 'DefaultAddonPVRClient.png')
                channels.append({
                    'name': c['name'], 'logo': logo,
                    'action': 'play_live_atres', 'params': {'ch_id': c['id']},
                    'plot': "Canal en directo: {0}".format(c['name']),
                })
        except Exception:
            pass

    channels.sort(key=lambda x: _LCN.get(x['name'], 99))

    _media_epg = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    _epg_icon  = os.path.join(_media_epg, 'directo.png')
    li_epg = xbmcgui.ListItem(label="[B]Programacion TV (EPG en texto)[/B]")
    li_epg.setArt({'icon': _epg_icon, 'thumb': _epg_icon})
    li_epg.setInfo('video', {'plot': "Parrilla de programacion en texto de los canales disponibles en EspaDaily.\nActualizacion automatica cada 2 horas."})
    li_epg.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="epg_texto_espadaily"), listitem=li_epg, isFolder=True)

    for ch in channels:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(ch['name']))
        li.setArt({'icon': ch['logo'], 'thumb': ch['logo']})
        li.setInfo('video', {'title': ch['name'], 'plot': ch['plot']})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=ch['action'], **ch['params']),
                                    listitem=li, isFolder=False)

    _sn_id = "plugin.video.streamninja"
    _sn_installed = xbmc.getCondVisibility("System.HasAddon({0})".format(_sn_id))
    lbl_sn = "[COLOR deepskyblue][B]StreamNinja[/B][/COLOR] (Necesario)" if _sn_installed else "[COLOR orange][B]StreamNinja[/B][/COLOR] (Necesario)"
    plt_sn = "Activa el Modo Ninja con StreamNinja para dominar cualquier enlace de video.\n\nNecesario para la reproduccion de muchos de los canales de TV." if _sn_installed else "Instala el Modo Ninja: StreamNinja para dominar cualquier enlace de video.\n\nNecesario para la reproduccion de muchos de los canales de TV."
    _media = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    sn_icon = os.path.join(_media, 'sn_logo.jpg')
    li_sn = xbmcgui.ListItem(label=lbl_sn)
    li_sn.setArt({"icon": sn_icon, "thumb": sn_icon})
    li_sn.setInfo("video", {"plot": plt_sn})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="url_player_ensure_sn"), listitem=li_sn, isFolder=False)

    li = xbmcgui.ListItem(label="[B]M\u00e1s canales de televisi\u00f3n[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Lista completa de canales TDT espa\u00f1oles.\n\nIncluye nacionales, auton\u00f3micos, tem\u00e1ticos y m\u00e1s."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tdt_channels_json"), listitem=li, isFolder=True)

    # --- Pluto TV y Samsung TV Plus (SlyGuy) ---
    li = xbmcgui.ListItem(label="[B]Pluto TV[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "TV gratuita con canales tem\u00e1ticos (cine, series, noticias...).\nRequiere addon SlyGuy (se instala autom\u00e1ticamente)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="slyguy_install", addon_id="slyguy.pluto.tv.provider", title="Pluto TV"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B]Samsung TV Plus[/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Canales de TV gratuitos de Samsung.\nRequiere addon SlyGuy (se instala autom\u00e1ticamente)."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="slyguy_install", addon_id="slyguy.samsung.tv.plus", title="Samsung TV Plus"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[B][COLOR red]E[/COLOR][COLOR yellow]s[/COLOR][COLOR red]p[/COLOR][COLOR yellow]a[/COLOR][COLOR red]T[/COLOR][COLOR yellow]V[/COLOR][/B]")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Addon todo-en-uno para contenido en castellano.\nTDT, RTVE a la carta, Dailymotion, YouTube, radio, podcast y mucho m\u00e1s.\n\nSi est\u00e1 instalado se abre directamente.\nSi no, te guiar\u00e1 para instalarlo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="open_espatv"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="TDT Channels Espa\u00f1a (M3U)")
    li.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li.setInfo('video', {'plot': "Lista M3U alternativa."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tdt_channels"), listitem=li, isFolder=True)

    # --- Listas IPTV personalizadas ---
    custom_lists = _load_custom_iptv()
    for lst in custom_lists:
        name = lst.get("name", "Lista")
        url = lst.get("url", "")
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(name))
        li.setArt({'icon': 'DefaultAddonPVRClient.png'})
        li.setInfo('video', {'plot': "Lista personalizada\nURL: {0}".format(url)})
        cm = [("Eliminar esta lista", "RunPlugin({0})".format(_u(action="delete_custom_iptv", url=url)))]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_custom_iptv", url=url), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="A\u00f1adir IPTV M3U")
    li.setArt({'icon': 'DefaultAddSource.png'})
    li.setInfo('video', {'plot': "Introduce la URL de canales IPTV en formato M3U/M3U8.\nEjemplo:\nhttps://ejemplo.com/canales.m3u8"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="add_custom_iptv"), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

def live_mediaset_menu():
    h = int(sys.argv[1])
    for c in connector._MEDIASET_LIVE_CHANNELS:
        ch_id = c["id"]; name = c["name"]; url = c["url"]
        thumb = connector._MEDIASET_CH_LOGOS.get(ch_id, "DefaultAddonPVRClient.png")
        li = xbmcgui.ListItem(label=f"[B]{name}[/B]")
        li.setArt({'icon': thumb, 'thumb': thumb})
        li.setInfo('video', {'title': name, 'plot': f"Canal en directo: {name}"})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_live_mediaset", url=url), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

def play_live_mediaset(url):
    import url_player as _up
    if not _up.streamninja_check_or_install():
        return
    sn_url = f"plugin://plugin.video.streamninja/?action=url_play&url={urllib.parse.quote(url, safe='')}"
    xbmc.executebuiltin(f'RunPlugin({sn_url})')

def live_atres_menu():
    h = int(sys.argv[1])
    if not _is_atresdaily_installed():
        li = xbmcgui.ListItem(label="[B][COLOR red]⚠ Atres[/COLOR][COLOR blue]Daily[/COLOR][COLOR red] no está instalado[/COLOR][/B]")
        li.setArt({'icon': 'DefaultIconError.png'})
        li.setInfo('video', {'plot': "AtresDaily es necesario para acceder a los canales en directo de Antena 3.\n\nPulsa para instalar o ver instrucciones."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="atresdaily_install"), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for c in connector.get_live_channels():
        ch_id = c["id"]; name = c["name"]
        thumb = connector._ATRES_CH_LOGOS.get(ch_id, "DefaultAddonPVRClient.png")
        li = xbmcgui.ListItem(label=f"[B]{name}[/B]")
        li.setArt({'icon': thumb, 'thumb': thumb})
        li.setInfo('video', {'title': name})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_live_atres", ch_id=ch_id), listitem=li, isFolder=False)

    li_a3 = xbmcgui.ListItem(label="[B]En Directo A3[/B]")
    li_a3.setArt({'icon': 'DefaultAddonPVRClient.png'})
    li_a3.setInfo('video', {'plot': "Programación en directo del grupo Antena 3 ahora mismo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="live_atres_now"), listitem=li_a3, isFolder=True)
    li_note = xbmcgui.ListItem(label="[COLOR yellow]NOTA: Los directos pueden fallar con VPN activa[/COLOR]")
    li_note.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li_note, isFolder=False)
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)

def play_live_atres(ch_id):
    if not _is_atresdaily_installed():
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification("EspaDaily", "AtresDaily no está instalado.", xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    stream = connector.resolve_live_channel(ch_id)
    if stream:
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        stream += "|User-Agent=" + urllib.parse.quote(ua)
        li = xbmcgui.ListItem(path=stream)
        li.setMimeType("application/x-mpegURL")
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
    else:
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification("EspaDaily", "Emisión no disponible", xbmcgui.NOTIFICATION_ERROR)

def live_atres_now():
    h = int(sys.argv[1])
    if not _is_atresdaily_installed():
        li = xbmcgui.ListItem(label="[B][COLOR red]⚠ AtresDaily no está instalado[/COLOR][/B]")
        li.setArt({'icon': 'DefaultIconError.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="atresdaily_install"), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    items = connector.fetch_live_schedule()
    if not items:
        li = xbmcgui.ListItem(label="Sin datos de emisión disponibles")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    for item in items:
        title = item.get("title") or item.get("name", "Emisión")
        link = item.get("link") or {}
        href = link.get("href", "")
        ch_id = item.get("mainChannel") or item.get("contentId")
        if not ch_id and "/" in href:
            ch_id = href.rstrip("/").split("/")[-1]
        if not ch_id:
            continue
        img_data = item.get("image") or item.get("images") or {}
        img = img_data.get("pathHorizontal") if isinstance(img_data, dict) else None
        thumb = _fix_img(img) if img else "DefaultAddonPVRClient.png"
        channel_name = link.get("url", "").replace("/directos/", "").replace("/", "").title()
        label = f"{title} [COLOR yellow]({channel_name})[/COLOR]" if channel_name else title
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb, 'thumb': thumb, 'fanart': thumb})
        li.setInfo('video', {'title': title})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_live_atres", ch_id=ch_id), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)

def play_atres_episode(eid):
    h = int(sys.argv[1])
    if not _is_atresdaily_installed():
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification("EspaDaily", "AtresDaily no está instalado.", xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    stream = connector.resolve_atres_episode(eid)
    if stream:
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        stream += "|User-Agent=" + urllib.parse.quote(ua) + "&Referer=https%3A%2F%2Fwww.atresplayer.com%2F"
        li = xbmcgui.ListItem(path=stream)
        li.setInfo('video', {'title': 'Atresplayer'})
        li.setMimeType("application/x-mpegURL")
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(h, True, li)
    else:
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification("EspaDaily", "Contenido no disponible en Atresplayer (requiere premium o no existe)", xbmcgui.NOTIFICATION_WARNING, 4000)

def live_rtve_menu():
    h = int(sys.argv[1])
    for c in connector._RTVE_LIVE_CHANNELS:
        li = xbmcgui.ListItem(label=f"[B]{c['name']}[/B]")
        li.setArt({'icon': c['logo'], 'thumb': c['logo']})
        li.setInfo('video', {'title': c['name'], 'plot': c['plot']})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_live_rtve", video_id=c['video_id']), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

def play_live_rtve(video_id):
    result = connector.resolve_rtve_live(video_id)
    headers_str = "User-Agent=Mozilla%2F5.0&Referer=https%3A%2F%2Fwww.rtve.es%2F&Origin=https%3A%2F%2Fwww.rtve.es"
    li = xbmcgui.ListItem(path=result["url"])
    li.setProperty("inputstream", "inputstream.adaptive")
    li.setProperty("inputstream.adaptive.manifest_type", "mpd")
    li.setProperty("inputstream.adaptive.manifest_headers", headers_str)
    li.setProperty("inputstream.adaptive.stream_headers", headers_str)
    if result["license_url"]:
        li.setProperty("inputstream.adaptive.license_type", "com.widevine.alpha")
        li.setProperty("inputstream.adaptive.license_key", result["license_url"])
    li.setMimeType("application/dash+xml")
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

def tdt_channels_json():
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("TDT Channels", "Descargando lista actualizada...")
    try:
        dp.update(30, "Conectando con tdtchannels.com...")
        r = requests.get(_TDT_JSON_URL, timeout=15)
        if r.status_code != 200: raise Exception("Error HTTP {0}".format(r.status_code))
        dp.update(70, "Procesando canales...")
        data = r.json()
        dp.close()
        countries = data.get("countries", [])
        if not countries:
            xbmcgui.Dialog().ok("TDT Channels", "No se encontraron datos.")
            xbmcplugin.endOfDirectory(h); return
        _tdt_json_cache["data"] = countries[0].get("ambits", [])
        for ambit in _tdt_json_cache["data"]:
            name = ambit.get("name", "Sin nombre")
            num = len(ambit.get("channels", []))
            li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(name, num))
            li.setArt({'icon': 'DefaultAddonPVRClient.png'})
            li.setInfo('video', {'plot': "Categor\u00eda: {0}\nCanales: {1}".format(name, num)})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="tdt_json_ambit", url=name), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h)
    except Exception as e:
        dp.close()
        _log_error("Error TDT JSON: {0}".format(e))
        xbmcgui.Dialog().ok("TDT Channels", "No se pudo cargar:\n{0}".format(e))
        try: xbmcplugin.endOfDirectory(h)
        except Exception: pass

def tdt_json_ambit(ambit_name):
    h = int(sys.argv[1])
    ambits = _tdt_json_cache.get("data")
    if not ambits:
        try:
            r = requests.get(_TDT_JSON_URL, timeout=15)
            data = r.json()
            countries = data.get("countries", [])
            if countries:
                ambits = countries[0].get("ambits", [])
                _tdt_json_cache["data"] = ambits
        except Exception:
            xbmcgui.Dialog().ok("TDT Channels", "No se pudo cargar la lista.")
            xbmcplugin.endOfDirectory(h); return
    if not ambits:
        xbmcplugin.endOfDirectory(h); return
    target = None
    for a in ambits:
        if a.get("name") == ambit_name:
            target = a; break
    if not target:
        xbmcplugin.endOfDirectory(h); return
    channels = []
    for ch in target.get("channels", []):
        name = ch.get("name", "Canal")
        opts = ch.get("options", [])
        logo = ch.get("logo", "")
        for opt in opts:
            fmt = opt.get("format", "")
            url = opt.get("url", "")
            if url and fmt.lower() in ("m3u8", "mp4", ""):
                channels.append({"name": name, "url": url, "logo": logo, "group": ambit_name})
                break
    if channels:
        _render_m3u_channels(channels, "TDT Channels - {0}".format(ambit_name))
    else:
        xbmcgui.Dialog().ok("TDT Channels", "No se encontraron streams para {0}.".format(ambit_name))
        xbmcplugin.endOfDirectory(h)

def tdt_channels():
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("TDT Channels", "Descargando lista M3U...")
    try:
        dp.update(30, "Conectando...")
        r = requests.get(_TDT_M3U_URL, timeout=15)
        if r.status_code != 200: raise Exception("Error HTTP {0}".format(r.status_code))
        dp.update(70, "Procesando canales...")
        channels = _parse_m3u_content(r.text)
        dp.close()
        if not channels:
            xbmcgui.Dialog().ok("TDT Channels", "No se encontraron canales.")
            xbmcplugin.endOfDirectory(h); return
        _render_m3u_channels(channels, "TDT Channels Espa\u00f1a")
    except Exception as e:
        dp.close()
        _log_error("Error TDT M3U: {0}".format(e))
        xbmcgui.Dialog().ok("TDT Channels", "No se pudo cargar:\n{0}".format(e))
        try: xbmcplugin.endOfDirectory(h)
        except Exception: pass

def play_tdt(url, title=""):
    try:
        is_m3u8 = '.m3u8' in url.lower().split('|')[0]
        ua = ""
        use_ia = False

        if core_settings.is_iptv_anti_errors_active() and '|' not in url:
            ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

        if is_m3u8 and core_settings.is_tdt_inputstream_active():
            if xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
                use_ia = True
            else:
                xbmc.log("[EspaDaily] InputStream Adaptive activado pero no instalado.", xbmc.LOGWARNING)

        if use_ia:
            play_url = url.split('|')[0]
        elif ua and '|' not in url:
            play_url = url + "|User-Agent=" + urllib.parse.quote(ua)
        else:
            play_url = url

        li = xbmcgui.ListItem(path=play_url)
        if title: li.setInfo('video', {'title': title})
        if is_m3u8: li.setMimeType('application/x-mpegURL')
        li.setContentLookup(False)

        if use_ia:
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstreamaddon', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            if ua:
                li.setProperty('inputstream.adaptive.stream_headers', 'User-Agent=' + urllib.parse.quote(ua))

        xbmc.Player().play(play_url, li)
    except Exception as e:
        _log_error("Error TDT play: {0}".format(e))
        xbmcgui.Dialog().ok("Error", "No se pudo reproducir:\n{0}".format(e))

def add_custom_iptv():
    kb = xbmc.Keyboard('', 'URL de la lista M3U/M3U8')
    kb.doModal()
    if not kb.isConfirmed(): return
    url = kb.getText().strip()
    if not url: return
    if not url.startswith(('http://', 'https://')):
        xbmcgui.Dialog().ok("EspaDaily", "La URL debe empezar por http:// o https://"); return
    try:
        r = requests.get(url, timeout=10)
        if r.status_code != 200:
            xbmcgui.Dialog().ok("EspaDaily", "No se pudo acceder a la URL.\nError HTTP {0}".format(r.status_code)); return
        channels = _parse_m3u_content(r.text)
        if not channels:
            xbmcgui.Dialog().ok("EspaDaily", "La URL no contiene canales v\u00e1lidos en formato M3U."); return
    except Exception as e:
        xbmcgui.Dialog().ok("EspaDaily", "Error al verificar la URL:\n{0}".format(e)); return
    kb2 = xbmc.Keyboard('', 'Nombre para la lista ({0} canales encontrados)'.format(len(channels)))
    kb2.doModal()
    if not kb2.isConfirmed() or not kb2.getText().strip(): return
    name = kb2.getText().strip()
    lists = _load_custom_iptv()
    if any(l.get("url") == url for l in lists):
        xbmcgui.Dialog().notification("EspaDaily", "Esta lista ya est\u00e1 a\u00f1adida", xbmcgui.NOTIFICATION_WARNING); return
    lists.append({"name": name, "url": url})
    _save_custom_iptv(lists)
    xbmcgui.Dialog().notification("EspaDaily", "Lista '{0}' a\u00f1adida".format(name), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def view_custom_iptv(url):
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("Lista IPTV", "Descargando lista...")
    try:
        dp.update(30, "Descargando...")
        r = requests.get(url, timeout=15)
        if r.status_code != 200: raise Exception("Error HTTP {0}".format(r.status_code))
        dp.update(70, "Procesando canales...")
        channels = _parse_m3u_content(r.text)
        dp.close()
        if not channels:
            xbmcgui.Dialog().ok("Lista IPTV", "No se encontraron canales.")
            xbmcplugin.endOfDirectory(h); return
        _render_m3u_channels(channels, "Lista personalizada")
    except Exception as e:
        dp.close()
        _log_error("Error lista IPTV: {0}".format(e))
        xbmcgui.Dialog().ok("Lista IPTV", "No se pudo cargar:\n{0}".format(e))
        try: xbmcplugin.endOfDirectory(h)
        except Exception: pass

def delete_custom_iptv(url):
    lists = _load_custom_iptv()
    name = next((l.get("name", "Lista") for l in lists if l.get("url") == url), "Lista")
    if xbmcgui.Dialog().yesno("EspaDaily", "\u00bfEliminar la lista '{0}'?".format(name)):
        new_lists = [l for l in lists if l.get("url") != url]
        _save_custom_iptv(new_lists)
        xbmcgui.Dialog().notification("EspaDaily", "Lista eliminada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")




_WATCH_HISTORY_FILE = "watch_history.json"
_MAX_WATCH_HISTORY = 100

def _load_watch_history():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    fp = os.path.join(p, _WATCH_HISTORY_FILE)
    if not os.path.exists(fp): return []
    try:
        with open(fp, 'r', encoding='utf-8') as f: return json.load(f)
    except (json.JSONDecodeError, IOError): return []

def _save_watch_history(history):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    fp = os.path.join(p, _WATCH_HISTORY_FILE)
    try:
        with open(fp, 'w', encoding='utf-8') as f: json.dump(history, f, ensure_ascii=False)
    except IOError: pass

def _add_watch_entry(vid, title, thumb="", duration=0):
    if not vid: return
    history = _load_watch_history()
    history = [entry for entry in history if entry.get("vid") != vid]
    history.insert(0, {"vid": vid, "title": title, "thumb": thumb, "duration": duration, "watched_at": int(time.time())})
    history = history[:_MAX_WATCH_HISTORY]
    _save_watch_history(history)

def _get_watched_ids():
    return set(entry.get("vid", "") for entry in _load_watch_history())

def _view_watch_history():
    import datetime
    h = int(sys.argv[1])
    history = _load_watch_history()
    if history:
        li = xbmcgui.ListItem(label="[COLOR red][B]Borrar todo el historial de visionado[/B][/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        li.setInfo('video', {'plot': "Tienes {0} v\u00eddeos en el historial.".format(len(history))})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="clear_watch_history"), listitem=li, isFolder=False)
    if not history:
        li = xbmcgui.ListItem(label="[COLOR gray]No has reproducido ning\u00fan v\u00eddeo a\u00fan[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h); return
    xbmcplugin.setContent(h, 'videos')
    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')
    for entry in history:
        vid = entry.get('vid', '')
        vt = entry.get('title', 'Video')
        dth = entry.get('thumb', '') or ai
        du = entry.get('duration', 0)
        try: du = int(du)
        except (ValueError, TypeError): du = 0
        watched_at = entry.get('watched_at', 0)
        try:
            dt = datetime.datetime.fromtimestamp(watched_at)
            date_str = dt.strftime("%d/%m/%Y %H:%M")
        except Exception: date_str = ""
        label = "[COLOR lime][V][/COLOR] {0}".format(vt)
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': dth, 'icon': dth})
        plot = "Visto: {0}".format(date_str)
        if du: plot += "\nDuraci\u00f3n: {0}m {1}s".format(du // 60, du % 60)
        li.setInfo('video', {'title': vt, 'plot': plot, 'duration': du})
        li.setProperty("IsPlayable", "true")
        is_ace = bool(vid and vid.startswith("acestream://"))
        cm = []
        if vid:
            cm.append(("Eliminar del historial", "RunPlugin({0})".format(_u(action="del_watch_entry", url=vid))))
            if is_ace:
                _ih = vid.replace("acestream://", "")
                _fav_params = json.dumps({"infohash": _ih, "name": vt})
                cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(
                    _u(action="add_favorite", title=vt, fav_url="ace_" + _ih,
                       icon=dth, platform="acestream",
                       fav_action="play_ace_result", params=_fav_params))))
            else:
                cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action="dm_open_browser", url=vid))))
                _fav_params = json.dumps({"vid": vid, "title": vt})
                cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(
                    _u(action="add_favorite", title=vt, fav_url="pv_" + vid,
                       icon=dth, platform="dailymotion",
                       fav_action="pv", params=_fav_params))))
        li.addContextMenuItems(cm)
        if is_ace:
            play_url = _u(action="play_ace_result", infohash=vid.replace("acestream://", ""), name=vt)
        else:
            play_url = _u(action="pv", vid=vid, title=urllib.parse.quote(vt))
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

def _del_watch_entry(vid):
    if not vid: return
    history = _load_watch_history()
    history = [entry for entry in history if entry.get("vid") != vid]
    _save_watch_history(history)
    xbmc.executebuiltin("Container.Refresh")

def _clear_watch_history():
    if xbmcgui.Dialog().yesno("EspaDaily", "\u00bfBorrar todo el historial de visionado?"):
        _save_watch_history([])
        xbmc.executebuiltin("Container.Refresh")




def _show_trending():
    h = int(sys.argv[1])
    try:
        time_limit = int(time.time()) - 604800
        params = {
            "sort": "trending", "language": "es", "created_after": time_limit,
            "limit": 50,
            "fields": "id,title,thumbnail_720_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"
        }
        resp = requests.get("https://api.dailymotion.com/videos", params=params, timeout=15)
        rs = resp.json().get("list", [])
        if not rs:
            xbmcgui.Dialog().ok("Tendencias", "No se han encontrado v\u00eddeos en tendencia.")
            xbmcplugin.endOfDirectory(h); return
        xbmcplugin.setContent(h, 'videos')
        watched_ids = _get_watched_ids()
        addon = xbmcaddon.Addon()
        ai = addon.getAddonInfo('icon')
        for i, v in enumerate(rs):
            vt = v.get("title", "Video")
            vi = v.get("id")
            ow = v.get("owner.screenname") or v.get("owner.username", "")
            du = 0
            try: du = int(v.get("duration", 0))
            except (ValueError, TypeError): pass
            vw = 0
            try: vw = int(v.get("views_total", 0))
            except (ValueError, TypeError): pass
            dth = v.get("thumbnail_720_url") or v.get("thumbnail_url") or ai
            is_watched = vi in watched_ids if vi else False
            watched_mark = "[COLOR lime][V][/COLOR] " if is_watched else ""
            label = "[COLOR orange]{0}.[/COLOR] {1}{2}".format(i + 1, watched_mark, vt)
            li = xbmcgui.ListItem(label=label)
            li.setArt({'thumb': dth, 'icon': dth})
            li.setInfo('video', {'title': vt, 'plot': "Canal: {0}\nVistas: {1:,}\nDuraci\u00f3n: {2}m {3}s".format(ow, vw, du // 60, du % 60), 'duration': du})
            li.setProperty("IsPlayable", "true")
            cm = []
            if vi:
                cm.append(("Descargar Video", "RunPlugin({0})".format(_u(action="download_video", vid=vi, title=vt))))
                cm.append(("Abrir en navegador", "RunPlugin({0})".format(_u(action="dm_open_browser", url=vi))))
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vi, title=urllib.parse.quote(vt)), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", "Error al cargar tendencias:\n{0}".format(str(e)))
        try: xbmcplugin.endOfDirectory(h)
        except Exception: pass




def _multi_search():
    kb = xbmc.Keyboard('', 'T\u00e9rminos separados por comas')
    kb.doModal()
    if not kb.isConfirmed(): return
    raw = kb.getText().strip()
    if not raw: return
    terms = [t.strip() for t in raw.split(',') if t.strip()]
    if not terms:
        xbmcgui.Dialog().notification("EspaDaily", "No se encontraron t\u00e9rminos v\u00e1lidos", xbmcgui.NOTIFICATION_WARNING)
        return
    if len(terms) > 10:
        terms = terms[:10]
        xbmcgui.Dialog().notification("EspaDaily", "Limitado a 10 t\u00e9rminos", xbmcgui.NOTIFICATION_INFO)
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("B\u00fasqueda M\u00faltiple", "Buscando {0} t\u00e9rminos...".format(len(terms)))
    all_results = []
    seen_ids = set()
    try:
        for idx, term in enumerate(terms):
            if dp.iscanceled(): break
            dp.update(int((idx / len(terms)) * 100), "Buscando: {0}".format(term))
            try:
                params = {"search": term, "sort": "relevance", "language": "es", "limit": 10,
                          "fields": "id,title,thumbnail_720_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"}
                resp = requests.get("https://api.dailymotion.com/videos", params=params, timeout=15)
                for item in resp.json().get("list", []):
                    vid = item.get("id", "")
                    if vid and vid not in seen_ids:
                        seen_ids.add(vid)
                        all_results.append((term, item))
            except Exception: pass
    finally:
        dp.close()
    if not all_results:
        xbmcgui.Dialog().ok("B\u00fasqueda M\u00faltiple", "No se encontraron resultados para ning\u00fan t\u00e9rmino.")
        xbmcplugin.endOfDirectory(h); return
    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')
    for term, item in all_results:
        vid = item.get("id", "")
        title = item.get("title", "Sin t\u00edtulo")
        thumb = item.get("thumbnail_720_url") or item.get("thumbnail_url", "") or ai
        dur = 0
        try: dur = int(item.get("duration", 0))
        except (ValueError, TypeError): pass
        owner = item.get("owner.screenname") or item.get("owner.username", "")
        views = 0
        try: views = int(item.get("views_total", 0))
        except (ValueError, TypeError): pass
        dur_min = dur // 60 if dur else 0
        label = "[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(title, term)
        if dur_min: label += " [COLOR cyan]{0}min[/COLOR]".format(dur_min)
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb, 'thumb': thumb})
        li.setInfo('video', {'plot': "Canal: {0}\nB\u00fasqueda: {1}\nDuraci\u00f3n: {2}min\nVisitas: {3:,}".format(owner, term, dur_min, views), 'duration': dur})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vid, title=urllib.parse.quote(title)), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)
    xbmcgui.Dialog().notification("B\u00fasqueda M\u00faltiple", "{0} resultados de {1} t\u00e9rminos".format(len(all_results), len(terms)))




def _dm_open_browser(vid):
    url = "https://www.dailymotion.com/video/{0}".format(vid) if vid else ""
    if not url: return
    try:
        if xbmc.getCondVisibility("System.Platform.Android"):
            xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","","{0}")'.format(url))
        else:
            import webbrowser
            webbrowser.open(url)
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)
    except Exception:
        xbmcgui.Dialog().ok("Abrir en navegador", "No se pudo abrir autom\u00e1ticamente.\n\nAbre esta URL:\n{0}".format(url))

def _sanitize_log_line(line):
    line = re.sub(r'(access_token=)[^&\s]+', lambda m: m.group(1) + '***', line)
    line = re.sub(r'(bearer=)[^&\s]+', lambda m: m.group(1) + '***', line)
    line = re.sub(r'(hdnts=)[^&\s]+', lambda m: m.group(1) + '***', line)
    line = re.sub(r'(token=)[^&\s]+', lambda m: m.group(1) + '***', line)
    line = re.sub(r'(Authorization:\s*Bearer\s+)\S+', lambda m: m.group(1) + '***', line, flags=re.IGNORECASE)
    return line

def _view_kodi_log():
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("EspaDaily", "No se encontr\u00f3 el archivo de log de Kodi.")
            return
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        last_lines = lines[-100:]
        espa_lines = [_sanitize_log_line(l.rstrip()) for l in last_lines if 'espadaily' in l.lower() or 'espakodi' in l.lower()]
        if not espa_lines:
            espa_lines = [_sanitize_log_line(l.rstrip()) for l in last_lines[-30:]]
        text = "\n".join(espa_lines[-50:])
        xbmcgui.Dialog().textviewer("Log de Kodi (EspaDaily)", text)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", "No se pudo leer el log:\n{0}".format(e))

def _view_kodi_log_full():
    """Muestra las últimas N líneas del log de Kodi sin filtrar."""
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("EspaDaily", "No se encontr\u00f3 el archivo de log de Kodi.")
            return
        opts = ["\u00daltimas 50 l\u00edneas", "\u00daltimas 100 l\u00edneas", "\u00daltimas 200 l\u00edneas"]
        counts = [50, 100, 200]
        sel = xbmcgui.Dialog().select("\u00bfCu\u00e1ntas l\u00edneas?", opts)
        if sel < 0: return
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        text = "".join([_sanitize_log_line(l) for l in lines[-counts[sel]:]])
        xbmcgui.Dialog().textviewer("Log de Kodi (completo)", text)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", "No se pudo leer el log:\n{0}".format(e))

def _view_kodi_log_errors():
    """Muestra solo las líneas de error y warning del log."""
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("EspaDaily", "No se encontr\u00f3 el archivo de log de Kodi.")
            return
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        error_lines = [_sanitize_log_line(l.rstrip()) for l in lines[-500:]
                       if ' error ' in l.lower() or 'warning' in l.lower() or 'exception' in l.lower() or 'traceback' in l.lower()]
        if not error_lines:
            xbmcgui.Dialog().ok("EspaDaily", "No se encontraron errores recientes en el log.")
            return
        text = "\n".join(error_lines[-80:])
        xbmcgui.Dialog().textviewer("Errores del Log de Kodi", text)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", "No se pudo leer el log:\n{0}".format(e))

def _search_kodi_log():
    """Busca un texto en el log de Kodi."""
    kb = xbmc.Keyboard('', 'Buscar en el log de Kodi')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        return
    term = kb.getText().strip().lower()
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("EspaDaily", "No se encontr\u00f3 el archivo de log.")
            return
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        matches = [_sanitize_log_line(l.rstrip()) for l in lines if term in l.lower()]
        if not matches:
            xbmcgui.Dialog().ok("EspaDaily", "No se encontr\u00f3 '{0}' en el log.".format(kb.getText().strip()))
            return
        header = "{0} resultados para '{1}'".format(len(matches), kb.getText().strip())
        text = "\n".join(matches[-80:])
        xbmcgui.Dialog().textviewer(header, text)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", str(e))

def _log_info():
    """Muestra información sobre el log de Kodi y el log interno."""
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        msg = "[B]Log de Kodi[/B]\n"
        if os.path.exists(log_path):
            size = os.path.getsize(log_path)
            with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
                total_lines = sum(1 for _ in f)
            if size > 1048576:
                msg += "Tamaño: {0:.1f} MB\n".format(size / 1048576)
            else:
                msg += "Tamaño: {0:.1f} KB\n".format(size / 1024)
            msg += "Líneas: {0:,}\n".format(total_lines)
            msg += "Ruta: {0}\n".format(log_path)
        else:
            msg += "No encontrado\n"
        msg += "\n[B]Log Interno EspaDaily[/B]\n"
        base_dir = os.path.dirname(os.path.abspath(__file__))
        err_log = os.path.join(base_dir, 'espadaily_errors.log')
        if os.path.exists(err_log):
            esize = os.path.getsize(err_log)
            with open(err_log, 'r', encoding='utf-8', errors='replace') as f:
                elines = sum(1 for _ in f)
            msg += "Tamaño: {0:.1f} KB\n".format(esize / 1024)
            msg += "Líneas: {0:,}\n".format(elines)
            msg += "Debug: {0}".format("ACTIVADO" if _is_debug_active() else "DESACTIVADO")
        else:
            msg += "No existe (activa Debug para generarlo)"
        xbmcgui.Dialog().textviewer("Informaci\u00f3n de Logs", msg)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", str(e))

def _export_log():
    """Exporta el log a un archivo TXT."""
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("EspaDaily", "No se encontr\u00f3 el archivo de log de Kodi.")
            return
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        opts = ["Solo entradas de EspaDaily", "Log completo (\u00faltimas 500 l\u00edneas)", "Solo errores y warnings"]
        sel = xbmcgui.Dialog().select("\u00bfQu\u00e9 exportar?", opts)
        if sel < 0: return
        if sel == 0:
            filtered = [_sanitize_log_line(l) for l in lines if 'espadaily' in l.lower() or 'espakodi' in l.lower()]
            suffix = "espadaily"
        elif sel == 1:
            filtered = [_sanitize_log_line(l) for l in lines[-500:]]
            suffix = "completo"
        else:
            filtered = [_sanitize_log_line(l) for l in lines if ' error ' in l.lower() or 'warning' in l.lower() or 'exception' in l.lower() or 'traceback' in l.lower()]
            suffix = "errores"
        if not filtered:
            xbmcgui.Dialog().ok("EspaDaily", "No hay entradas que exportar.")
            return
        d = xbmcgui.Dialog().browse(3, 'Guardar log exportado', 'files')
        if not d: return
        ts = time.strftime("%Y%m%d_%H%M%S")
        fname = "kodi_log_{0}_{1}.txt".format(suffix, ts)
        if os.path.isdir(d):
            dest = os.path.join(d, fname)
        else:
            dest = d if d.lower().endswith('.txt') else d + '.txt'
        with open(dest, 'w', encoding='utf-8') as f:
            f.write("Log exportado por EspaDaily -- {0}\n".format(time.strftime('%d/%m/%Y %H:%M:%S')))
            f.write("Tipo: {0}\n".format(opts[sel]))
            f.write("L\u00edneas: {0}\n".format(len(filtered)))
            f.write("=" * 60 + "\n\n")
            f.writelines(filtered)
        xbmcgui.Dialog().ok("Exportado", "Log guardado en:\n{0}\n\n{1} l\u00edneas exportadas.".format(dest, len(filtered)))
    except Exception as e:
        xbmcgui.Dialog().ok("Error", "No se pudo exportar:\n{0}".format(e))

def _clear_error_log():
    """Elimina el log interno de errores."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    log_file = os.path.join(base_dir, 'espadaily_errors.log')
    if not os.path.exists(log_file):
        xbmcgui.Dialog().ok("EspaDaily", "No existe el archivo de log interno.")
        return
    size_kb = os.path.getsize(log_file) / 1024
    if xbmcgui.Dialog().yesno("EspaDaily", "\u00bfEliminar el log interno?\n\nTama\u00f1o: {0:.1f} KB".format(size_kb)):
        try:
            os.remove(log_file)
            xbmcgui.Dialog().notification("EspaDaily", "Log interno eliminado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
            xbmcgui.Dialog().ok("Error", str(e))

def _view_log_visual():
    """Visor de log visual: cada linea es un item con colores por severidad."""
    log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
    if not os.path.exists(log_path):
        xbmcgui.Dialog().ok("EspaDaily", "No se encontr\u00f3 el archivo de log de Kodi.")
        return

    opts = ["\u00daltimas 50 l\u00edneas", "\u00daltimas 100 l\u00edneas", "\u00daltimas 200 l\u00edneas", "Solo EspaDaily", "Solo errores"]
    sel = xbmcgui.Dialog().select("Modo de vista", opts)
    if sel < 0: return

    try:
        with open(log_path, 'r', encoding='utf-8', errors='replace') as f:
            all_lines = f.readlines()
    except Exception as e:
        xbmcgui.Dialog().ok("Error", str(e))
        return

    if sel == 0:
        lines = all_lines[-50:]
    elif sel == 1:
        lines = all_lines[-100:]
    elif sel == 2:
        lines = all_lines[-200:]
    elif sel == 3:
        lines = [l for l in all_lines if 'espadaily' in l.lower() or 'espakodi' in l.lower()][-100:]
    else:
        lines = [l for l in all_lines if ' error ' in l.lower() or 'exception' in l.lower() or 'traceback' in l.lower()][-100:]

    if not lines:
        xbmcgui.Dialog().ok("EspaDaily", "No hay entradas que mostrar.")
        return

    h = int(sys.argv[1])
    for i, raw in enumerate(lines):
        line = _sanitize_log_line(raw.rstrip())
        ll = line.lower()


        if ' error ' in ll or 'exception' in ll or 'traceback' in ll:
            sev = 'error'
        elif 'warning' in ll:
            sev = 'warning'
        elif 'espadaily' in ll or 'espakodi' in ll:
            sev = 'espa'
        elif ' debug ' in ll:
            sev = 'debug'
        else:
            sev = 'info'

        # Extraer timestamp si existe (formato: 2026-03-16 23:05:26.421)
        ts_display = ""
        if len(line) > 23 and line[4] == '-' and line[10] == ' ':
            ts_display = line[11:19]  # HH:MM:SS
            body = line[23:].strip()
    
            if body.startswith("T:"):
                space_idx = body.find(' ')
                if space_idx > 0:
                    body = body[space_idx:].strip()
    
            for tag in ['info <general>:', 'error <general>:', 'warning <general>:', 'debug <general>:', 'notice <general>:']:
                if body.lower().startswith(tag):
                    body = body[len(tag):].strip()
                    break
        else:
            body = line


        if len(body) > 120:
            label_text = body[:117] + "..."
        else:
            label_text = body


        if sev == 'error':
            label = "[COLOR red][B]X[/B][/COLOR] "
            if ts_display:
                label += "[COLOR grey]{0}[/COLOR] ".format(ts_display)
            label += "[COLOR red]{0}[/COLOR]".format(label_text)
            icon = 'DefaultIconError.png'
        elif sev == 'warning':
            label = "[COLOR yellow][B]![/B][/COLOR] "
            if ts_display:
                label += "[COLOR grey]{0}[/COLOR] ".format(ts_display)
            label += "[COLOR yellow]{0}[/COLOR]".format(label_text)
            icon = 'DefaultIconWarning.png'
        elif sev == 'espa':
            label = "[COLOR limegreen][B]*[/B][/COLOR] "
            if ts_display:
                label += "[COLOR grey]{0}[/COLOR] ".format(ts_display)
            label += "[COLOR limegreen]{0}[/COLOR]".format(label_text)
            icon = 'DefaultIconInfo.png'
        elif sev == 'debug':
            label = "[COLOR grey]- "
            if ts_display:
                label += "{0} ".format(ts_display)
            label += "{0}[/COLOR]".format(label_text)
            icon = 'DefaultIconInfo.png'
        else:
            label = "[COLOR white]-[/COLOR] "
            if ts_display:
                label += "[COLOR grey]{0}[/COLOR] ".format(ts_display)
            label += "{0}".format(label_text)
            icon = 'DefaultIconInfo.png'

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icon})
        li.setInfo('video', {'plot': line})
        encoded = base64.b64encode(line.encode('utf-8')).decode('ascii')
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="show_log_line", data=encoded), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

def _show_log_line(data):
    """Muestra una linea del log completa en un textviewer."""
    try:
        line = base64.b64decode(data).decode('utf-8')
        xbmcgui.Dialog().textviewer("Detalle del Log", line)
    except Exception:
        xbmcgui.Dialog().ok("Error", "No se pudo decodificar la entrada.")

def _log_menu():
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)

    li = xbmcgui.ListItem(label="[COLOR limegreen]Log de EspaDaily (filtrado)[/COLOR]")
    li.setArt({'icon': _mi('adv_log.png')})
    li.setInfo('video', {'plot': "Muestra las \u00faltimas entradas del log de Kodi que mencionan EspaDaily.\nTokens y datos sensibles se censuran autom\u00e1ticamente."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_kodi_log"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR magenta][B]Visor del Log[/B][/COLOR]")
    li.setArt({'icon': _mi('adv_log.png')})
    li.setInfo('video', {'plot': "Muestra cada l\u00ednea del log como un elemento visual individual.\nCodificado por colores seg\u00fan severidad:\n\n[COLOR red]X Error[/COLOR]\n[COLOR yellow]! Warning[/COLOR]\n[COLOR limegreen]* EspaDaily[/COLOR]\n[COLOR white]- Info[/COLOR]\n[COLOR grey]- Debug[/COLOR]\n\nPermite hacer scroll por las entradas del log."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_log_visual"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Log de Kodi (completo)")
    li.setArt({'icon': _mi('adv_log.png')})
    li.setInfo('video', {'plot': "Muestra las \u00faltimas l\u00edneas del log completo de Kodi, sin filtrar.\nPuedes elegir cu\u00e1ntas l\u00edneas ver."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_kodi_log_full"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR red]Solo Errores y Warnings[/COLOR]")
    li.setArt({'icon': 'DefaultIconError.png'})
    li.setInfo('video', {'plot': "Filtra el log para mostrar solo l\u00edneas de error, warning, exception y traceback."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_kodi_log_errors"), listitem=li, isFolder=False)

    base_dir = os.path.dirname(os.path.abspath(__file__))
    err_log = os.path.join(base_dir, 'espadaily_errors.log')
    if os.path.exists(err_log):
        esize = os.path.getsize(err_log) / 1024
        li = xbmcgui.ListItem(label="[COLOR gold]Log Interno ({0:.0f} KB)[/COLOR]".format(esize))
        li.setArt({'icon': _mi('adv_log.png')})
        li.setInfo('video', {'plot': "Lee el archivo espadaily_errors.log generado por el Modo Debug.\nPuedes elegir cuántas líneas ver."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="view_error_log"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR cyan]Buscar en el Log[/COLOR]")
    li.setArt({'icon': _mi('adv_log.png')})
    li.setInfo('video', {'plot': "Escribe un texto para buscar en todo el log de Kodi.\nMuestra todas las l\u00edneas que coinciden."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="search_kodi_log"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Exportar Log a archivo")
    li.setArt({'icon': _mi('adv_log.png')})
    li.setInfo('video', {'plot': "Guarda el log filtrado, completo o de errores en un archivo TXT.\n\u00datil para compartir o enviar a soporte."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="export_log"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Informaci\u00f3n del Log")
    li.setArt({'icon': _mi('adv_log.png')})
    li.setInfo('video', {'plot': "Muestra el tama\u00f1o, n\u00famero de l\u00edneas y ruta del log de Kodi y del log interno."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="log_info"), listitem=li, isFolder=False)

    if os.path.exists(err_log):
        li = xbmcgui.ListItem(label="[COLOR red]Borrar Log Interno[/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        li.setInfo('video', {'plot': "Elimina el archivo espadaily_errors.log para liberar espacio."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="clear_error_log"), listitem=li, isFolder=False)

    # LoioLog
    try:
        xbmcaddon.Addon("plugin.program.loiolog")
        ll_label = "LoioLog: [COLOR green]INSTALADO[/COLOR]"
    except Exception:
        ll_label = "LoioLog: [COLOR grey]NO INSTALADO[/COLOR]"
    li = xbmcgui.ListItem(label=ll_label)
    li.setArt({'icon': 'DefaultAddonProgram.png'})
    li.setInfo('video', {'plot': "LoioLog es un gestor avanzado de logs para Kodi.\nPermite ver, filtrar, buscar, analizar y exportar los logs del sistema.\n\nSi no est\u00e1 instalado, pulsa para descargarlo e instalarlo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="loiolog_install"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

def _open_loiolog():
    _ek_loiolog_launch()

def _loiolog_install():
    """Wrapper de compatibilidad: delega en el motor.

    Pierde el lookup dinamico de la GitHub Releases API a cambio de las garantias
    antirrace del motor. Tras la primera instalacion del repo, Kodi se encarga de
    actualizar el addon via addons.xml automaticamente."""
    _ek_loiolog_launch()

def _open_flowfav():
    _ek_flowfav_launch()

def _flowfav_install():
    """Wrapper de compatibilidad: delega en el motor.

    Pierde el lookup dinamico de la GitHub Releases API a cambio de las garantias
    antirrace del motor. Tras la primera instalacion del repo, Kodi se encarga de
    actualizar el addon via addons.xml automaticamente."""
    _ek_flowfav_launch()


_EK_REPO_POLL_TIMEOUT_S  = 20
_EK_ADDON_POLL_TIMEOUT_S = 60
_EK_POLL_INTERVAL_MS     = 500
_EK_MAX_REPO_ZIP_BYTES   = 50 * 1024 * 1024
_EK_MAX_ADDON_ZIP_BYTES  = 200 * 1024 * 1024

_EK_ESPATV_ADDON_ID      = "plugin.video.espatv"
_EK_ESPATV_REPO_ID       = "repository.espatv"
_EK_ESPATV_REPO_ZIP      = "https://raw.githubusercontent.com/espakodi/espatv/main/repository.espatv-1.0.0.zip"
_EK_ESPATV_SOURCE        = "https://espakodi.github.io/espatv/"

_EK_ATRESDAILY_ADDON_ID  = "plugin.video.atresdaily"
_EK_ATRESDAILY_REPO_ID   = "repository.atresdaily"
_EK_ATRESDAILY_REPO_ZIP  = "https://espatv.github.io/atresdaily/repository.atresdaily-1.0.1.zip"
_EK_ATRESDAILY_SOURCE    = "https://espatv.github.io/atresdaily/"

_EK_LOIOLOG_ADDON_ID     = "plugin.program.loiolog"
_EK_LOIOLOG_REPO_ID      = "repository.loiolog"
_EK_LOIOLOG_REPO_ZIP     = "https://raw.githubusercontent.com/loioloio/loiolog/main/repository.loiolog-1.0.0.zip"
_EK_LOIOLOG_SOURCE       = "https://loioloio.github.io/loiolog/"

_EK_FLOWFAV_ADDON_ID     = "plugin.program.flowfavmanager"
_EK_FLOWFAV_REPO_ID      = "repository.flowfavmanager"
_EK_FLOWFAV_REPO_ZIP     = "https://loioloio.github.io/flowfav/repository.flowfavmanager-1.0.0.zip"
_EK_FLOWFAV_SOURCE       = "https://loioloio.github.io/flowfav/"

_EK_STREAMNINJA_ADDON_ID = "plugin.video.streamninja"
_EK_STREAMNINJA_REPO_ID  = "repository.streamninja"
_EK_STREAMNINJA_REPO_ZIP = "https://raw.githubusercontent.com/fullstackcurso/estreamninja/main/repository.streamninja-1.0.0.zip"
_EK_STREAMNINJA_SOURCE   = "https://fullstackcurso.github.io/estreamninja/"


def _ek_addon_is_installed(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except Exception:
        return False

def _ek_addon_dir_present(addon_id):
    addon_dir = xbmcvfs.translatePath(f"special://home/addons/{addon_id}/")
    return os.path.isdir(addon_dir) and os.path.isfile(os.path.join(addon_dir, "addon.xml"))

def _ek_jsonrpc(method, params=None):
    req = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        req["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception:
        return {}

def _ek_addon_is_known(addon_id):
    resp = _ek_jsonrpc("Addons.GetAddonDetails", {"addonid": addon_id, "properties": ["enabled"]})
    return "result" in resp and "addon" in resp.get("result", {})

def _ek_enable_addon_jsonrpc(addon_id):
    resp = _ek_jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": True})
    return resp.get("result") == "OK"

def _ek_try_recover_addon(addon_id):
    if _ek_addon_is_known(addon_id):
        if _ek_enable_addon_jsonrpc(addon_id):
            xbmc.sleep(800)
            if _ek_addon_is_installed(addon_id):
                return True
    if not _ek_addon_dir_present(addon_id):
        return False
    xbmc.executebuiltin("UpdateLocalAddons()")
    xbmc.sleep(1500)
    if _ek_addon_is_known(addon_id) and _ek_enable_addon_jsonrpc(addon_id):
        xbmc.sleep(800)
        if _ek_addon_is_installed(addon_id):
            return True
    xbmc.executebuiltin(f"EnableAddon({addon_id})")
    xbmc.sleep(1500)
    return _ek_addon_is_installed(addon_id)

def _ek_get_repo_datadir(repo_id):
    repo_xml = xbmcvfs.translatePath(f"special://home/addons/{repo_id}/addon.xml")
    if not os.path.isfile(repo_xml):
        return None
    try:
        with open(repo_xml, "r", encoding="utf-8") as f:
            content = f.read()
        m = re.search(r"<datadir[^>]*>\s*([^<\s]+)\s*</datadir>", content)
        if m:
            url = m.group(1).strip()
            if not url.endswith("/"):
                url += "/"
            return url
    except Exception as e:
        xbmc.log(f"[EspaDaily] No se pudo leer datadir del repo {repo_id}: {e}", xbmc.LOGWARNING)
    return None

def _ek_find_addon_version_in_index(addons_xml_text, addon_id):
    try:
        m = re.search(
            r'<addon[^>]*\bid="' + re.escape(addon_id) + r'"[^>]*\bversion="([^"]+)"',
            addons_xml_text
        )
        if m: return m.group(1)
        m = re.search(
            r'<addon[^>]*\bversion="([^"]+)"[^>]*\bid="' + re.escape(addon_id) + r'"',
            addons_xml_text
        )
        if m: return m.group(1)
    except Exception:
        pass
    return None

# Fallback: descarga el zip del addon desde el datadir del repo. Se usa cuando InstallAddon
# se queda colgado en la cola interna de Kodi (típico tras un error de red en el primer intento).
def _ek_install_addon_zip_directly(addon_id, repo_id, friendly_name):
    try:
        datadir = _ek_get_repo_datadir(repo_id)
        if not datadir:
            xbmc.log(f"[EspaDaily] Fallback ({friendly_name}): no se pudo obtener datadir de {repo_id}", xbmc.LOGWARNING)
            return False
        try:
            r = requests.get(datadir + "addons.xml", timeout=20)
            if r.status_code != 200:
                return False
            addons_xml = r.text
        except Exception:
            return False
        version = _ek_find_addon_version_in_index(addons_xml, addon_id)
        if not version:
            return False
        addon_zip_url = f"{datadir}{addon_id}/{addon_id}-{version}.zip"
        try:
            r = requests.get(addon_zip_url, timeout=60)
            if r.status_code != 200: return False
            if len(r.content) < 4 or r.content[:2] != b"PK": return False
            if len(r.content) > _EK_MAX_ADDON_ZIP_BYTES: return False
        except Exception:
            return False
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        addons_dir_real = os.path.realpath(addons_dir)
        zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), f"{addon_id}-{version}.zip")
        with open(zip_path, "wb") as f:
            f.write(r.content)
        with zipfile.ZipFile(zip_path, "r") as zf:
            for entry in zf.namelist():
                resolved = os.path.realpath(os.path.join(addons_dir, entry))
                if not resolved.startswith(addons_dir_real):
                    raise Exception(f"ZIP contiene ruta sospechosa: {entry}")
            zf.extractall(addons_dir)
        try: os.remove(zip_path)
        except Exception: pass
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(1500)
        xbmc.executebuiltin(f"EnableAddon({addon_id})")
        xbmc.sleep(1500)
        for _ in range(20):
            if _ek_addon_is_installed(addon_id): return True
            xbmc.executebuiltin(f"EnableAddon({addon_id})")
            xbmc.sleep(_EK_POLL_INTERVAL_MS)
        return _ek_try_recover_addon(addon_id) or _ek_addon_is_installed(addon_id)
    except Exception as e:
        xbmc.log(f"[EspaDaily] Fallback excepcion: {e}", xbmc.LOGERROR)
        return False

def _ek_install_repo_and_addon(addon_id, repo_id, repo_zip_url, friendly_name):
    if _ek_addon_is_installed(addon_id):
        xbmcgui.Dialog().notification("EspaDaily", f"{friendly_name} ya esta instalado", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
        return True
    if _ek_try_recover_addon(addon_id):
        xbmcgui.Dialog().notification("EspaDaily", f"{friendly_name} reactivado correctamente", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
        return True
    # Si el repo ya esta registrado (caso tipico de SlyGuy con N addons en un mismo repo, o
    # de un reintento del usuario), saltamos descarga/extraccion: reextraer sobreescribiria
    # los archivos del repo a media sesion, lo que en Kodi 19/20 deja el repo deshabilitado.
    repo_already_present = _ek_addon_is_installed(repo_id)
    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", f"Descargando repositorio de {friendly_name}..." if not repo_already_present else f"Instalando {friendly_name}...")
    zip_path = None
    bg = None
    try:
        if not repo_already_present:
            dp.update(5, "Descargando repositorio...")
            r = requests.get(repo_zip_url, timeout=30)
            if r.status_code != 200:
                raise Exception(f"Error HTTP {r.status_code}")
            if len(r.content) < 4 or r.content[:2] != b"PK":
                raise Exception("El archivo descargado no es un ZIP valido")
            if len(r.content) > _EK_MAX_REPO_ZIP_BYTES:
                raise Exception(f"Tamano sospechoso: {len(r.content) // 1024}KB")
            zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), f"{repo_id}.zip")
            with open(zip_path, "wb") as f:
                f.write(r.content)
            dp.update(20, "Extrayendo repositorio...")
            addons_dir = xbmcvfs.translatePath("special://home/addons/")
            addons_dir_real = os.path.realpath(addons_dir)
            with zipfile.ZipFile(zip_path, "r") as zf:
                for entry in zf.namelist():
                    resolved = os.path.realpath(os.path.join(addons_dir, entry))
                    if not resolved.startswith(addons_dir_real):
                        raise Exception(f"ZIP contiene ruta sospechosa: {entry}")
                zf.extractall(addons_dir)
            dp.update(35, "Registrando repositorio en Kodi...")
            xbmc.executebuiltin("UpdateLocalAddons()")
            repo_iters = (_EK_REPO_POLL_TIMEOUT_S * 1000) // _EK_POLL_INTERVAL_MS
            repo_ready = False
            for i in range(repo_iters):
                if dp.iscanceled():
                    raise Exception("Cancelado por el usuario")
                try:
                    xbmcaddon.Addon(repo_id)
                    repo_ready = True
                    break
                except Exception:
                    # Algunos repos quedan deshabilitados al extraerse y no se registran hasta que
                    # se les fuerza un EnableAddon. Reintentamos en iters dispersos para no spammear.
                    if i in (4, 12, 24):
                        xbmc.executebuiltin(f"EnableAddon({repo_id})")
                    xbmc.sleep(_EK_POLL_INTERVAL_MS)
            if not repo_ready:
                raise Exception(f"Kodi no registro el repositorio tras {_EK_REPO_POLL_TIMEOUT_S}s")
            dp.update(55, "Activando repositorio...")
            xbmc.executebuiltin(f"EnableAddon({repo_id})")
            xbmc.sleep(1500)
        dp.update(65, "Actualizando indice del repositorio...")
        xbmc.executebuiltin("UpdateAddonRepos()")
        xbmc.sleep(3000)
        # Cerramos antes de InstallAddon: Kodi abre su propio modal de confirmacion y dos
        # modales apilados pierden foco en algunos skins (Estuary mod, Arctic, etc.).
        dp.close()
        xbmcgui.Dialog().notification("EspaDaily", f"Confirma la instalacion de {friendly_name}", xbmcgui.NOTIFICATION_INFO, 4000)
        xbmc.executebuiltin(f"InstallAddon({addon_id})")
        bg = xbmcgui.DialogProgressBG()
        bg.create("EspaDaily", f"Esperando instalacion de {friendly_name}...")
        addon_iters = (_EK_ADDON_POLL_TIMEOUT_S * 1000) // _EK_POLL_INTERVAL_MS
        addon_ready = False
        for i in range(addon_iters):
            if _ek_addon_is_installed(addon_id):
                addon_ready = True
                break
            xbmc.sleep(_EK_POLL_INTERVAL_MS)
            pct = min(int((i + 1) * 100 / addon_iters), 99)
            bg.update(pct, "EspaDaily", f"Esperando instalacion de {friendly_name}...")
        bg.close()
        bg = None
        if not addon_ready and _ek_try_recover_addon(addon_id):
            addon_ready = True
        if addon_ready:
            xbmcgui.Dialog().notification("EspaDaily", f"{friendly_name} instalado correctamente", xbmcgui.NOTIFICATION_INFO, 4000)
            xbmc.executebuiltin("Container.Refresh")
            return True
        bg = xbmcgui.DialogProgressBG()
        bg.create("EspaDaily", f"Instalacion automatica de {friendly_name} (fallback)...")
        bg.update(50)
        ok = _ek_install_addon_zip_directly(addon_id, repo_id, friendly_name)
        bg.close()
        bg = None
        if ok:
            xbmcgui.Dialog().notification("EspaDaily", f"{friendly_name} instalado correctamente", xbmcgui.NOTIFICATION_INFO, 4000)
            xbmc.executebuiltin("Container.Refresh")
            return True
        xbmcgui.Dialog().ok(
            "EspaDaily",
            f"El repositorio de {friendly_name} se instalo, pero la instalacion del addon no se completo.\n\n"
            f"Para terminarla manualmente:\nAddons - Instalar desde repositorio - {friendly_name} - Instalar"
        )
        return False
    except Exception as e:
        try: dp.close()
        except Exception: pass
        if bg:
            try: bg.close()
            except Exception: pass
        xbmc.log(f"[EspaDaily] Error instalando {friendly_name}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "Error de instalacion",
            f"No se pudo instalar {friendly_name} automaticamente.\n\nError: {e}\n\n"
            "Puede que necesites activar Origenes desconocidos en Ajustes."
        )
        return False
    finally:
        if zip_path and os.path.exists(zip_path):
            try: os.remove(zip_path)
            except Exception: pass

def _ek_addon_status_label(addon_id):
    return "[COLOR lime]Instalado[/COLOR]" if _ek_addon_is_installed(addon_id) else "[COLOR orange]No instalado[/COLOR]"

def _ek_addon_icon(addon_id, fallback=None):
    try:
        ad = xbmcaddon.Addon(addon_id)
        path = ad.getAddonInfo("path")
        for name in ("icon.png", "icon.jpg"):
            p = os.path.join(path, name)
            if os.path.exists(p):
                return p
    except Exception:
        pass
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media")
    return fallback or os.path.join(_med, "play_generic.png")


def _ek_espatv_launch():
    try:
        xbmcaddon.Addon(_EK_ESPATV_ADDON_ID)
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo EspaTV...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_EK_ESPATV_ADDON_ID})")
        return
    except Exception:
        pass
    opciones = ["Instalador automatico (puede fallar)", "Ver instrucciones de instalacion manual"]
    idx = xbmcgui.Dialog().select("EspaTV - instalacion", opciones)
    if idx == 0:
        if not xbmcgui.Dialog().yesno("EspaDaily", "EspaTV no esta instalado.\n\n¿Descargar e instalar automaticamente?"):
            return
        _ek_install_repo_and_addon(_EK_ESPATV_ADDON_ID, _EK_ESPATV_REPO_ID, _EK_ESPATV_REPO_ZIP, "EspaTV")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones EspaTV",
            "[B]Como instalar EspaTV[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Origenes desconocidos\n\n"
            f"2. Ajustes - Explorador de archivos - Anadir fuente: {_EK_ESPATV_SOURCE}\n\n"
            "3. Ajustes - Addons - Instalar desde un archivo zip - EspaTV - repository.espatv-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - EspaTV - Addons de video - EspaTV")


def _ek_espadaily_launch():
    xbmc.executebuiltin("Container.Update(plugin://plugin.video.espadaily/,replace)")


def _ek_atresdaily_launch():
    try:
        xbmcaddon.Addon(_EK_ATRESDAILY_ADDON_ID)
        xbmc.executebuiltin(f"Container.Update(plugin://{_EK_ATRESDAILY_ADDON_ID}/,replace)")
        return
    except Exception:
        pass
    opciones = ["Instalador automatico (puede fallar)", "Ver instrucciones de instalacion manual"]
    idx = xbmcgui.Dialog().select("AtresDaily - instalacion", opciones)
    if idx == 0:
        if not xbmcgui.Dialog().yesno("EspaDaily", "AtresDaily no esta instalado.\n\n¿Descargar e instalar automaticamente?"):
            return
        _ek_install_repo_and_addon(_EK_ATRESDAILY_ADDON_ID, _EK_ATRESDAILY_REPO_ID, _EK_ATRESDAILY_REPO_ZIP, "AtresDaily")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones AtresDaily",
            "[B]Como instalar AtresDaily[/B]\n\n"
            "1. Ajustes - Sistema - Addons (activa Origenes desconocidos)\n\n"
            f"2. Ajustes - Explorador de archivos - Anadir fuente: {_EK_ATRESDAILY_SOURCE}\n\n"
            "3. Ajustes - Addons - Instalar desde un archivo zip - AtresDaily - repository.atresdaily-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - AtresDaily - Addons de video - AtresDaily - Instalar")


def _ek_loiolog_launch():
    try:
        xbmcaddon.Addon(_EK_LOIOLOG_ADDON_ID)
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo LoioLog...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_EK_LOIOLOG_ADDON_ID})")
        return
    except Exception:
        pass
    opciones = ["Instalador automatico (puede fallar)", "Ver instrucciones de instalacion manual"]
    idx = xbmcgui.Dialog().select("LoioLog - instalacion", opciones)
    if idx == 0:
        if not xbmcgui.Dialog().yesno("EspaDaily", "LoioLog no esta instalado.\n\n¿Descargar e instalar automaticamente?"):
            return
        _ek_install_repo_and_addon(_EK_LOIOLOG_ADDON_ID, _EK_LOIOLOG_REPO_ID, _EK_LOIOLOG_REPO_ZIP, "LoioLog")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones LoioLog",
            "[B]Como instalar LoioLog[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Origenes desconocidos\n\n"
            f"2. Ajustes - Explorador de archivos - Anadir fuente: {_EK_LOIOLOG_SOURCE}\n\n"
            "3. Ajustes - Addons - Instalar desde un archivo zip - LoioLog - repository.loiolog-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - LoioLog - Addons de programa - LoioLog")


def _ek_flowfav_launch():
    try:
        xbmcaddon.Addon(_EK_FLOWFAV_ADDON_ID)
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo Flow FavManager...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_EK_FLOWFAV_ADDON_ID})")
        return
    except Exception:
        pass
    opciones = ["Instalador automatico (puede fallar)", "Ver instrucciones de instalacion manual"]
    idx = xbmcgui.Dialog().select("Flow FavManager - instalacion", opciones)
    if idx == 0:
        if not xbmcgui.Dialog().yesno("EspaDaily", "Flow FavManager no esta instalado.\n\n¿Descargar e instalar automaticamente?"):
            return
        _ek_install_repo_and_addon(_EK_FLOWFAV_ADDON_ID, _EK_FLOWFAV_REPO_ID, _EK_FLOWFAV_REPO_ZIP, "Flow FavManager")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones Flow FavManager",
            "[B]Flow FavManager[/B] - gestor avanzado de favoritos para Kodi.\n\n"
            "1. Ajustes - Sistema - Addons - activa Origenes desconocidos\n"
            f"2. Ajustes - Explorador de archivos - Anadir fuente: {_EK_FLOWFAV_SOURCE}\n"
            "3. Addons - cajita - Instalar desde archivo zip - flowfav - repository.flowfavmanager-1.0.0.zip\n"
            "4. Instalar desde repositorio - Flow FavManager Repository - Program add-ons - Flow FavManager")


def _ek_streamninja_launch():
    try:
        xbmcaddon.Addon(_EK_STREAMNINJA_ADDON_ID)
        xbmcgui.Dialog().notification("EspaDaily", "Abriendo StreamNinja...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_EK_STREAMNINJA_ADDON_ID})")
        return
    except Exception:
        pass
    opciones = ["Instalador automatico (puede fallar)", "Ver instrucciones de instalacion manual"]
    idx = xbmcgui.Dialog().select("StreamNinja - instalacion", opciones)
    if idx == 0:
        if not xbmcgui.Dialog().yesno("EspaDaily", "StreamNinja no esta instalado.\n\n¿Descargar e instalar automaticamente?"):
            return
        _ek_install_repo_and_addon(_EK_STREAMNINJA_ADDON_ID, _EK_STREAMNINJA_REPO_ID, _EK_STREAMNINJA_REPO_ZIP, "StreamNinja")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones StreamNinja",
            "[B]Como instalar StreamNinja[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Origenes desconocidos\n\n"
            f"2. Ajustes - Explorador de archivos - Anadir fuente: {_EK_STREAMNINJA_SOURCE}\n\n"
            "3. Ajustes - Addons - Instalar desde un archivo zip - StreamNinja - repository.streamninja-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - StreamNinja - Addons de video - StreamNinja")


def espakodi_addons_menu():
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media")

    _items = [
        (_EK_ESPATV_ADDON_ID,      "ek_espatv_launch",
         "EspaTV",
         "EspaTV: TV, radio, podcast, agenda deportiva, top peliculas y series...",
         os.path.join(_med, "directo.png")),
        ("plugin.video.espadaily",  "ek_espadaily_launch",
         "EspaDaily",
         "EspaDaily: contenido de RTVE y otras plataformas espanolas (este addon).",
         None),
        (_EK_ATRESDAILY_ADDON_ID,   "ek_atresdaily_launch",
         "AtresDaily",
         "AtresDaily: catalogo de Atresplayer y busquedas externas.",
         os.path.join(_med, "descargas.png")),
        (_EK_LOIOLOG_ADDON_ID,      "ek_loiolog_launch",
         "LoioLog",
         "LoioLog: visor avanzado de logs de Kodi con filtros y exportacion.",
         os.path.join(_med, "adv_log.png")),
        (_EK_FLOWFAV_ADDON_ID,      "ek_flowfav_launch",
         "Flow FavManager",
         "Flow FavManager: gestor avanzado de favoritos para Kodi.",
         os.path.join(_med, "favoritos.png")),
        (_EK_STREAMNINJA_ADDON_ID,  "ek_streamninja_launch",
         "StreamNinja",
         "StreamNinja: extraccion neutral de flujos de video publicamente accesibles.",
         os.path.join(_med, "srch_externa.png")),
    ]

    for addon_id, action, name, plot, fallback_icon in _items:
        status = _ek_addon_status_label(addon_id)
        title = f"{name} — {status}"
        icon = _ek_addon_icon(addon_id, fallback=fallback_icon)
        li = xbmcgui.ListItem(label=title)
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

def _set_cache_config():
    cfg = _load_dm_settings()
    current = cfg.get('cache_expiry', 0)
    options = [
        "Apagado" + (" [ACTIVO]" if current == 0 else ""),
        "1 d\u00eda" + (" [ACTIVO]" if current == 86400 else ""),
        "1 semana" + (" [ACTIVO]" if current == 604800 else ""),
        "1 mes" + (" [ACTIVO]" if current == 2592000 else ""),
        "Indefinido" + (" [ACTIVO]" if current == -1 else ""),
    ]
    vals = [0, 86400, 604800, 2592000, -1]
    sel = xbmcgui.Dialog().select("Duraci\u00f3n de la cach\u00e9", options)
    if sel < 0: return
    cfg['cache_expiry'] = vals[sel]
    _save_dm_settings(cfg)
    xbmcgui.Dialog().notification("EspaDaily", "Cach\u00e9: {0}".format(options[sel].replace(" [ACTIVO]", "")), xbmcgui.NOTIFICATION_INFO)

def _set_download_path():
    path = xbmcgui.Dialog().browse(0, 'Seleccionar carpeta de descargas', 'files')
    if not path: return
    cfg = _load_dm_settings()
    cfg['download_path'] = path
    _save_dm_settings(cfg)
    xbmcgui.Dialog().notification("EspaDaily", "Ruta configurada", xbmcgui.NOTIFICATION_INFO)




def _get_backup_dir():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    d = os.path.join(p, 'backups')
    if not os.path.exists(d): os.makedirs(d)
    return d

def _create_backup_full():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(profile): os.makedirs(profile)


    groups = [
        ("Favoritos", ['favorites.json']),
        ("Categorías Personalizadas", ['custom_categories.json']),
        ("Historial de Búsquedas", ['search_history.json']),
        ("Historial de Navegación", ['exploration_history.json']),
        ("Historial de Visionado", ['watch_history.json']),
        ("Historial de URLs", ['url_history.json', 'url_bookmarks.json']),
        ("Configuración General", ['settings.json']),
        ("Ajustes Dailymotion", ['dm_settings.json']),
        ("Listas IPTV Personalizadas", ['custom_iptv.json']),
        ("Historial (v1)", ['history.json']),
        ("Caché de Categorías", '__cache__'),
        ("Instantáneas", '__snapshots__'),
    ]


    available_groups = []
    available_labels = []
    for label, files in groups:
        if files == '__cache__':
            has = any(f.startswith("cat_cache_") and f.endswith(".json") for f in os.listdir(profile))
        elif files == '__snapshots__':
            sd = os.path.join(profile, 'snapshots')
            has = os.path.exists(sd) and any(f.endswith('.json') for f in os.listdir(sd))
        else:
            has = any(os.path.exists(os.path.join(profile, f)) for f in files)
        if has:
            available_groups.append((label, files))
            available_labels.append(label)

    if not available_labels:
        xbmcgui.Dialog().ok("Backup", "No se encontraron datos que respaldar.\n\nEl perfil del addon aún no tiene archivos guardados.")
        return


    selected = xbmcgui.Dialog().multiselect("¿Qué incluir en el backup?", available_labels,
                                            preselect=list(range(len(available_labels))))
    if selected is None or len(selected) == 0:
        return


    ts = time.strftime("%Y%m%d_%H%M%S")
    default_name = "espadaily_backup_{0}.zip".format(ts)
    loc_opts = ["Guardar en carpeta del addon (por defecto)", "Elegir ubicación"]
    loc_sel = xbmcgui.Dialog().select("¿Dónde guardar?", loc_opts)
    if loc_sel < 0:
        return
    if loc_sel == 1:
        d = xbmcgui.Dialog().browse(3, 'Guardar Backup', 'files', '', False, False, default_name)
        if not d:
            return
        if os.path.isdir(d):
            target = os.path.join(d, default_name)
        elif not d.lower().endswith(".zip"):
            target = d + ".zip"
        else:
            target = d
    else:
        bdir = _get_backup_dir()
        target = os.path.join(bdir, default_name)

    dp = xbmcgui.DialogProgress()
    dp.create("Backup", "Creando copia de seguridad...")
    try:
        added = []
        snap_count = 0
        chosen = [available_groups[i] for i in selected]

        dp.update(20, "Empaquetando datos...")
        with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as zf:
            for label, files in chosen:
                if files == '__cache__':
                    for cf in os.listdir(profile):
                        if cf.startswith("cat_cache_") and cf.endswith(".json"):
                            cfp = os.path.join(profile, cf)
                            if os.path.exists(cfp):
                                zf.write(cfp, cf)
                                added.append(cf)
                elif files == '__snapshots__':
                    sd = os.path.join(profile, 'snapshots')
                    if os.path.exists(sd):
                        for sf in os.listdir(sd):
                            if sf.endswith('.json'):
                                zf.write(os.path.join(sd, sf), 'snapshots/' + sf)
                                added.append('snapshots/' + sf)
                                snap_count += 1
                else:
                    for bf in files:
                        fp = os.path.join(profile, bf)
                        if os.path.exists(fp):
                            zf.write(fp, bf)
                            added.append(bf)

        dp.update(80, "Verificando integridad...")
        if not added:
            dp.close()
            if os.path.exists(target):
                os.remove(target)
            xbmcgui.Dialog().ok("Backup", "No se guardó ningún archivo.")
            return

        with zipfile.ZipFile(target, 'r') as zf:
            bad = zf.testzip()
        dp.close()

        size_kb = os.path.getsize(target) / 1024
        msg = "Backup creado correctamente.\n\n"
        msg += "Archivos: {0}\n".format(len(added))
        if snap_count > 0:
            msg += "Instantáneas: {0}\n".format(snap_count)
        msg += "Tamaño: {0:.1f} KB\n\n".format(size_kb)
        msg += "Guardado en:\n{0}".format(target)
        if bad:
            msg += "\n\n[COLOR yellow]Advertencia: algunos archivos pueden estar dañados.[/COLOR]"
        xbmcgui.Dialog().ok("Backup Completo", msg)
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok("Error", str(e))

def _list_backups():
    h = int(sys.argv[1])
    bdir = _get_backup_dir()
    try:
        files = sorted([f for f in os.listdir(bdir) if f.endswith('.zip')], reverse=True)
    except Exception:
        files = []
    if not files:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay copias de seguridad[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    for f in files:
        li = xbmcgui.ListItem(label=f)
        li.setArt({'icon': 'DefaultAddonRepository.png'})
        cm = [("Eliminar backup", "RunPlugin({0})".format(_u(action="delete_single_backup", file=f)))]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="restore_backup_selective", file=f), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

def _restore_backup_selective(fname):
    source = os.path.join(_get_backup_dir(), fname)
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    file_labels = {
        'settings.json': 'Configuraci\u00f3n General',
        'favorites.json': 'Favoritos',
        'search_history.json': 'Historial de B\u00fasquedas',
        'history.json': 'Historial (v1)',
        'custom_categories.json': 'Categor\u00edas Personalizadas',
        'exploration_history.json': 'Historial de Navegaci\u00f3n',
        'dm_settings.json': 'Ajustes Dailymotion',
        'watch_history.json': 'Historial de Visionado',
        'custom_iptv.json': 'Listas IPTV Personalizadas',
        'url_history.json': 'Historial de URLs',
        'url_bookmarks.json': 'Marcadores de URLs',
    }
    mergeable = ['favorites.json', 'search_history.json', 'history.json', 'exploration_history.json',
                 'watch_history.json', 'url_history.json', 'url_bookmarks.json', 'custom_iptv.json']
    try:
        with zipfile.ZipFile(source, 'r') as zf:
            available = zf.namelist()
        known = [f for f in available if f in file_labels]
    
        cache_files = [f for f in available if f.startswith("cat_cache_") and f.endswith(".json")]
        if cache_files:
            known.append('__cache__')
            file_labels['__cache__'] = 'Caché de Categorías ({0})'.format(len(cache_files))
    
        snap_files = [f for f in available if f.startswith('snapshots/') and f.endswith('.json')]
        if snap_files:
            known.append('__snapshots__')
            file_labels['__snapshots__'] = 'Instantáneas ({0})'.format(len(snap_files))
        if not known:
            xbmcgui.Dialog().ok("EspaDaily", "Este backup no contiene datos reconocidos."); return
        options = [file_labels.get(f, f) for f in known]
        selected = xbmcgui.Dialog().multiselect("¿Qué quieres restaurar?", options)
        if selected is None or len(selected) == 0: return
        files_to_restore = [known[i] for i in selected]
        with zipfile.ZipFile(source, 'r') as zf:
            for fz in files_to_restore:
                if fz == '__snapshots__':
                    sd = os.path.join(profile, 'snapshots')
                    if not os.path.exists(sd): os.makedirs(sd)
                    for sf in snap_files:
                        data = zf.read(sf)
                        with open(os.path.join(sd, os.path.basename(sf)), 'wb') as f_out:
                            f_out.write(data)
                    continue
                if fz == '__cache__':
                    for cf in cache_files:
                        data = zf.read(cf)
                        with open(os.path.join(profile, cf), 'wb') as f_out:
                            f_out.write(data)
                    continue
                dest_path = os.path.join(profile, fz)
                if fz in mergeable and os.path.exists(dest_path):
                    choice = xbmcgui.Dialog().select(file_labels[fz], ["Sustituir (borrar actual)", "Añadir (fusionar con actual)", "Omitir"])
                    if choice == 2 or choice == -1: continue
                    elif choice == 1:
                        try:
                            with open(dest_path, 'r', encoding='utf-8') as f: current = json.load(f)
                            with zf.open(fz) as zfile: backup = json.load(zfile)
                            if isinstance(current, list) and isinstance(backup, list):
                                merged = current + [x for x in backup if x not in current]
                                with open(dest_path, 'w', encoding='utf-8') as f: json.dump(merged, f, ensure_ascii=False)
                                continue
                            elif isinstance(current, dict) and isinstance(backup, dict):
                                current.update(backup)
                                with open(dest_path, 'w', encoding='utf-8') as f: json.dump(current, f, ensure_ascii=False)
                                continue
                        except Exception: pass
                resolved = os.path.realpath(os.path.join(profile, fz))
                if not resolved.startswith(os.path.realpath(profile)):
                    continue
                zf.extract(fz, profile)
        xbmcgui.Dialog().notification("EspaDaily", "Restauración completada", xbmcgui.NOTIFICATION_INFO)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", "Fallo en restauraci\u00f3n: {0}".format(e))

def _delete_single_backup(fname):
    path = os.path.join(_get_backup_dir(), fname)
    if xbmcgui.Dialog().yesno("EspaDaily", "\u00bfEliminar '{0}'?".format(fname)):
        try:
            os.remove(path)
            xbmcgui.Dialog().notification("EspaDaily", "Backup eliminado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
            xbmcgui.Dialog().ok("Error", str(e))

def _export_favorites_txt():
    """Exporta la lista de favoritos a un archivo de texto plano legible."""
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("EspaDaily", "No hay favoritos para exportar", xbmcgui.NOTIFICATION_WARNING)
        return

    d = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not d: return

    dest = os.path.join(d, 'favoritos_espadaily.txt')
    try:
        with open(dest, 'w', encoding='utf-8') as f:
            f.write("Favoritos EspaDaily -- {0}\n".format(time.strftime('%d/%m/%Y %H:%M')))
            f.write("Total: {0} favoritos\n".format(len(favs)))
            f.write("=" * 50 + "\n\n")
            for fav in favs:
                title = fav.get('title', 'Sin titulo')
                url = fav.get('url', '')
                action = fav.get('action', '')
                f.write("{0}\n".format(title))
                if url:
                    f.write("  URL: {0}\n".format(url))
                if action:
                    f.write("  Tipo: {0}\n".format(action))
                f.write("\n")
        xbmcgui.Dialog().notification("EspaDaily", "Exportados {0} favoritos a TXT".format(len(favs)))
    except Exception as e:
        xbmcgui.Dialog().ok("Error", "No se pudo exportar: {0}".format(e))

def _backups_menu():
    h = int(sys.argv[1])
    _med = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _mi(n): return os.path.join(_med, n)
    li = xbmcgui.ListItem(label="[COLOR limegreen][B]Crear Backup[/B][/COLOR]")
    li.setArt({'icon': _mi('adv_backup.png')})
    li.setInfo('video', {'plot': "Crea una copia ZIP de tus datos.\nPuedes elegir qué incluir y dónde guardarla."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="create_backup_full"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Restaurar / Ver Backups")
    li.setArt({'icon': _mi('adv_backup.png')})
    li.setInfo('video', {'plot': "Lista los backups creados. Permite restaurar selectivamente."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="list_backups"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[COLOR gold]Importar Backup externo[/COLOR]")
    li.setArt({'icon': _mi('adv_backup.png')})
    li.setInfo('video', {'plot': "Importa un archivo ZIP desde cualquier ubicación.\nPuedes elegir qué datos restaurar.\nÚtil para backups compartidos o de otro dispositivo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="import_backup"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR cyan]Exportar Favoritos a TXT[/COLOR]")
    li.setArt({'icon': _mi('backup_favs.png')})
    li.setInfo('video', {'plot': "Genera un archivo de texto plano con la lista de favoritos."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="export_favs_txt"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Instantáneas")
    li.setArt({'icon': _mi('adv_cache.png')})
    li.setInfo('video', {'plot': "Guarda el estado actual de los menús.\nPermite acceder a los contenidos incluso sin conexión."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="snapshots_menu"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)




def _load_dm_settings():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    sp = os.path.join(p, 'dm_settings.json')
    if not os.path.exists(sp):
        return {}
    try:
        with open(sp, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}

def _save_dm_settings(cfg):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    sp = os.path.join(p, 'dm_settings.json')
    try:
        with open(sp, 'w', encoding='utf-8') as f:
            json.dump(cfg, f, ensure_ascii=False)
    except IOError:
        pass

def _set_dm_safe_level():
    options = [
        "Desactivado (Conexión Normal)",
        "Básico (Móvil + Cookies)",
        "Extremo (Todas las técnicas de Gujal00)",
        "YT-DLP (TLS Spoofing - Recomendado en PC)",
        "ISA (inputstream.adaptive - Sin VPN)",
    ]
    cfg = _load_dm_settings()
    current = cfg.get('dm_safe_level', 0)

    sel = xbmcgui.Dialog().select("Modo Anti-Errores Dailymotion", options, preselect=current)
    if sel >= 0:
        if sel == 3:
            try:
                import yt_dlp
                xbmc.log(f"[EspaDaily] yt-dlp v{yt_dlp.version.__version__} disponible", xbmc.LOGINFO)
            except ImportError:
                xbmcgui.Dialog().ok("EspaDaily", "yt-dlp no está instalado.\n\nInstálalo con:\npip install yt-dlp curl-cffi")
                return
        if sel == 4:
            if not xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
                xbmcgui.Dialog().ok("EspaDaily", "inputstream.adaptive no está instalado.\n\nInstálalo desde el repositorio oficial de Kodi.")
                return
        cfg['dm_safe_level'] = sel
        _save_dm_settings(cfg)
        xbmcgui.Dialog().notification("EspaDaily", f"Modo Anti-Errores DM: {options[sel].split(' (')[0]}")
        xbmc.executebuiltin("Container.Refresh")

def _set_dl_mode():
    opts = [
        "Nivel 1: DIRECTO (Elegir calidad)", 
        "Nivel 2: SAFE MODE (Mejor MP4 directo)", 
        "Nivel 3: ESPADAILY (Descargar por HLS)",
        "Nivel 4: YT-DLP (Mejor calidad, Python 3.10+)",
        "Nivel 5: ULTRA (Mejor calidad, Python 3.10+)"
    ]
    cfg = _load_dm_settings()
    current = cfg.get('dl_mode', 0)
    idx = xbmcgui.Dialog().select("Modo de Descarga", opts, preselect=current)
    if idx >= 0:
        cfg['dl_mode'] = idx
        _save_dm_settings(cfg)
        xbmcgui.Dialog().notification("EspaDaily", f"Modo descarga: Nivel {idx+1} guardado")
        xbmc.executebuiltin("Container.Refresh")

def _dm_playlists_search():
    kb = xbmc.Keyboard("", "Buscar canal de Dailymotion")
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText().strip()
    if not query:
        return
    channels = connector.search_dm_channels(query)
    if not channels:
        xbmcgui.Dialog().ok("EspaDaily", "No se encontraron canales para: " + query)
        return
    h = int(sys.argv[1])
    for ch in channels:
        name = ch.get("screenname") or ch.get("username", "Canal")
        user = ch.get("username", "")
        li = xbmcgui.ListItem(label=name)
        li.setArt({'icon': 'DefaultActor.png'})
        li.setInfo('video', {'plot': "Usuario: " + user})
        cm = [("Guardar canal", "RunPlugin({0})".format(
            _u(action="dm_save_channel", user=user, name=name)
        ))]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="dm_user_playlists", user=user),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)

def _dm_user_playlists(user):
    if not user:
        return
    playlists = connector.list_user_playlists(user)
    if not playlists:
        xbmcgui.Dialog().ok("EspaDaily", "Este canal no tiene playlists.")
        return
    h = int(sys.argv[1])
    for pl in playlists:
        name = pl.get("name", "Playlist")
        count = pl.get("count", 0)
        label = "{0} ({1} videos)".format(name, count) if count else name
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultVideoPlaylists.png'})
        desc = pl.get("description", "")
        if desc:
            li.setInfo('video', {'plot': desc})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="dm_view_playlist", pid=pl.get("id")),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)

def _dm_view_playlist(pid):
    if not pid:
        return
    videos = connector.view_playlist(pid)
    if not videos:
        xbmcgui.Dialog().ok("EspaDaily", "No se encontraron videos en esta playlist.")
        return
    h = int(sys.argv[1])
    for v in videos:
        vid = v.get("id")
        if not vid:
            continue
        tt = v.get("title", "Video")
        th = v.get("thumbnail_720_url", "")
        dur = v.get("duration", 0)
        owner = v.get("owner.screenname", "")
        li = xbmcgui.ListItem(label=tt)
        li.setArt({'thumb': th, 'icon': th})
        info = {'title': tt, 'duration': dur}
        if owner:
            info['plot'] = "Canal: " + owner
        li.setInfo('video', info)
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="pv", vid=vid, title=urllib.parse.quote(tt)),
            listitem=li, isFolder=False,
        )
    xbmcplugin.endOfDirectory(h)

def _dm_playlists_menu():
    h = int(sys.argv[1])
    li = xbmcgui.ListItem(label="Buscar canal")
    li.setArt({'icon': 'DefaultAddonsSearch.png'})
    li.setInfo('video', {'plot': "Busca un canal de Dailymotion por nombre y explora sus playlists."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dm_playlists_search"), listitem=li, isFolder=True)

    saved = _load_dm_saved_channels()
    count = len(saved)
    label = "Canales guardados ({0})".format(count) if count else "Canales guardados"
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': 'DefaultFavourites.png'})
    li.setInfo('video', {'plot': "Canales de Dailymotion que has guardado para acceso directo a sus playlists."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="dm_saved_channels"), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)

def _dm_saved_channels_menu():
    h = int(sys.argv[1])
    saved = _load_dm_saved_channels()
    if not saved:
        li = xbmcgui.ListItem(label="[COLOR gray]No tienes canales guardados[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.setInfo('video', {'plot': "Usa la opci\u00f3n 'Buscar canal' para encontrar canales y gu\u00e1rdalos con el men\u00fa contextual."})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    for ch in saved:
        user = ch.get("user", "")
        name = ch.get("name", user)
        if not user:
            continue
        li = xbmcgui.ListItem(label=name)
        li.setArt({'icon': 'DefaultActor.png'})
        li.setInfo('video', {'plot': "Usuario: {0}".format(user)})
        cm = [("Eliminar canal guardado", "RunPlugin({0})".format(
            _u(action="dm_delete_saved_channel", user=user)
        ))]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="dm_user_playlists", user=user),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)

def _dm_save_channel(user, name):
    if not user:
        return
    saved = _load_dm_saved_channels()
    if any(ch.get("user", "").lower() == user.lower() for ch in saved):
        xbmcgui.Dialog().notification("EspaDaily", "Este canal ya est\u00e1 guardado", xbmcgui.NOTIFICATION_WARNING)
        return
    if not name:
        name = user
    saved.append({"user": user, "name": name})
    _save_dm_saved_channels(saved)
    xbmcgui.Dialog().notification("EspaDaily", "Canal '{0}' guardado".format(name), xbmcgui.NOTIFICATION_INFO)

def _dm_delete_saved_channel(user):
    if not user:
        return
    saved = _load_dm_saved_channels()
    name = next((ch.get("name", user) for ch in saved if ch.get("user") == user), user)
    if not xbmcgui.Dialog().yesno("EspaDaily", "\u00bfEliminar el canal '{0}' de tus guardados?".format(name)):
        return
    new_saved = [ch for ch in saved if ch.get("user") != user]
    _save_dm_saved_channels(new_saved)
    xbmcgui.Dialog().notification("EspaDaily", "Canal eliminado", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _search_external_prompt(query):
    if not query:
        return
    options = []
    actions = []
    _ext_off = core_settings.are_external_integrations_disabled()

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
        options.append("Buscar en Elementum (Torrents)")
        actions.append(("elementum_search", query))

    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
        options.append("Buscar en addon Dailymotion (Gujal)")
        actions.append(("dm_gujal_search", query))

    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.palantir3)"):
        options.append("Buscar en Palantir 3")
        actions.append(("palantir_search", query))

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
        options.append("Buscar en YouTube")
        actions.append(("youtube_search", query))

    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.balandro)"):
        options.append("Buscar en Balandro")
        actions.append(("balandro_search", query))

    if not options:
        xbmcgui.Dialog().ok(
            "EspaDaily",
            "No hay addons de terceros instalados.\n\n"
            "Addons compatibles:\n"
            u"  \u2022 Elementum (torrents)\n"
            u"  \u2022 Dailymotion (Gujal)\n"
            u"  \u2022 Palantir 3\n"
            u"  \u2022 YouTube",
        )
        return

    sel = xbmcgui.Dialog().select(
        u"\u00bfD\u00f3nde quieres buscar '{0}'?".format(query), options
    )
    if sel < 0:
        return

    action_name, q = actions[sel]
    if action_name == "elementum_search":
        _search_elementum(q)
    elif action_name == "dm_gujal_search":
        _search_dailymotion_gujal(q)
    elif action_name == "palantir_search":
        _search_palantir(q)
    elif action_name == "youtube_search":
        xbmc.executebuiltin('Container.Update({0})'.format(_u(action='yt_results', query=q)))
    elif action_name == "balandro_search":
        _search_balandro_from_results(q)

def _search_dailymotion_gujal(query):
    if not query:
        return
    if core_settings.are_external_integrations_disabled():
        return
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
        xbmcgui.Dialog().notification("EspaDaily", "El addon Dailymotion (Gujal) no esta instalado.", xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    url = "plugin://plugin.video.dailymotion_com/?action=search&query=" + urllib.parse.quote(query)
    xbmc.executebuiltin('Container.Update("{0}")'.format(url))

def _search_youtube_from_results(query):
    """Búsqueda en YouTube desde resultados (scraping nativo, sin API key)."""
    if not query: return
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
        xbmcgui.Dialog().ok("EspaDaily",
            "El plugin de YouTube no está instalado.\n\n"
            "Instálalo desde el repositorio oficial de Kodi para reproducir los resultados.")
        return
    kb = xbmc.Keyboard(query, 'Buscar en YouTube')
    kb.doModal()
    if not kb.isConfirmed():
        return
    txt = (kb.getText() or "").strip()
    if not txt:
        return
    xbmc.executebuiltin(f"Container.Update({_u(action='yt_results', query=txt)})")


def _yt_parse_initial_data(html):
    m = re.search(r'var ytInitialData\s*=\s*(\{.*?\});\s*</script>', html, re.DOTALL)
    if not m:
        m = re.search(r'ytInitialData"\]\s*=\s*(\{.*?\});', html, re.DOTALL)
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except (ValueError, TypeError):
        return None


def _yt_extract_videos(data):
    results = []
    try:
        sections = data["contents"]["twoColumnSearchResultsRenderer"]["primaryContents"]["sectionListRenderer"]["contents"]
    except (KeyError, TypeError, AttributeError):
        return results
    for section in sections:
        if not isinstance(section, dict):
            continue
        isr = section.get("itemSectionRenderer")
        if not isr:
            continue
        for item in isr.get("contents", []):
            if not isinstance(item, dict):
                continue
            vr = item.get("videoRenderer")
            if not vr:
                continue
            vid = vr.get("videoId", "")
            if not vid or not isinstance(vid, str) or len(vid) != 11:
                continue
            title = ""
            try:
                runs = vr.get("title", {}).get("runs", [])
                if runs and isinstance(runs, list):
                    title = runs[0].get("text", "") or ""
                if not title:
                    title = vr.get("title", {}).get("simpleText", "") or ""
            except (KeyError, TypeError, AttributeError, IndexError):
                pass
            dur = ""
            try:
                dur = vr.get("lengthText", {}).get("simpleText", "") or ""
            except (KeyError, TypeError, AttributeError):
                pass
            channel = ""
            try:
                chan_runs = vr.get("ownerText", {}).get("runs", [])
                if chan_runs and isinstance(chan_runs, list):
                    channel = chan_runs[0].get("text", "") or ""
            except (KeyError, TypeError, AttributeError, IndexError):
                pass
            views = ""
            try:
                views = vr.get("viewCountText", {}).get("simpleText", "") or ""
                if not views:
                    views = vr.get("shortViewCountText", {}).get("simpleText", "") or ""
            except (KeyError, TypeError, AttributeError):
                pass
            published = ""
            try:
                published = vr.get("publishedTimeText", {}).get("simpleText", "") or ""
            except (KeyError, TypeError, AttributeError):
                pass
            results.append({
                "vid": vid,
                "title": title or "Video",
                "duration": dur,
                "channel": channel,
                "views": views,
                "published": published,
            })
    return results


def _yt_fallback_parse(html):
    results = []
    seen = set()
    pattern = re.compile(
        r'"videoRenderer":\{"videoId":"([^"]{11})".*?"title":\{"runs":\[\{"text":"([^"]+)"\}',
        re.DOTALL,
    )
    for m in pattern.finditer(html):
        vid = m.group(1)
        try:
            title = json.loads('"' + m.group(2) + '"')
        except (ValueError, TypeError):
            title = m.group(2)
        if vid not in seen:
            seen.add(vid)
            results.append({"vid": vid, "title": title, "duration": "", "channel": "", "views": "", "published": ""})
        if len(results) >= 20:
            break
    return results


def _yt_fetch_html(url, timeout=15):
    """Descarga la URL manejando gzip y la cookie de consent EU."""
    import urllib.request
    import gzip
    import io
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, identity",
        "Cookie": "CONSENT=YES+1; SOCS=CAI",
    }
    req = urllib.request.Request(url, headers=headers)
    resp = urllib.request.urlopen(req, timeout=timeout)
    raw = resp.read()
    if (resp.headers.get("Content-Encoding") or "").lower() == "gzip":
        try:
            raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
        except OSError:
            pass
    return raw.decode("utf-8", errors="replace")


def _yt_native_search_results(query):
    """Lista resultados de YouTube scrapeando la web (sin API key)."""
    import urllib.error
    h = int(sys.argv[1])
    query = (query or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", f"Buscando en YouTube: {query}...")
    results = []
    try:
        encoded = urllib.parse.quote_plus(query)
        url = f"https://www.youtube.com/results?search_query={encoded}"
        html = _yt_fetch_html(url)
        if dp.iscanceled():
            dp.close()
            xbmcplugin.endOfDirectory(h, succeeded=False)
            return
        dp.update(60)
        data = _yt_parse_initial_data(html)
        if data:
            results = _yt_extract_videos(data)
        if not results:
            results = _yt_fallback_parse(html)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[EspaDaily] Error buscando en YouTube: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("EspaDaily", f"Error al buscar en YouTube:\n{e}")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    except Exception as e:
        dp.close()
        xbmc.log(f"[EspaDaily] Error inesperado en YouTube: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("EspaDaily", f"Error inesperado al buscar en YouTube:\n{e}")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    if not results:
        xbmcgui.Dialog().ok("EspaDaily", f"No se encontraron resultados para:\n{query}")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    xbmcplugin.setContent(h, 'videos')
    for r in results:
        vid = r["vid"]
        title = r["title"]
        li = xbmcgui.ListItem(label=title)
        thumb = f'https://i.ytimg.com/vi/{vid}/hqdefault.jpg'
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb, 'poster': thumb, 'fanart': thumb})
        plot_lines = []
        if r.get("channel"):    plot_lines.append(f"Canal: {r['channel']}")
        if r.get("duration"):   plot_lines.append(f"Duracion: {r['duration']}")
        if r.get("views"):      plot_lines.append(f"Vistas: {r['views']}")
        if r.get("published"):  plot_lines.append(f"Subido: {r['published']}")
        plot = "\n".join(plot_lines) if plot_lines else title
        li.setInfo('video', {'plot': plot, 'title': title, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        play_url = f"plugin://plugin.video.youtube/play/?video_id={vid}"
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR yellow][B]Buscar otra cosa en YouTube...[/B][/COLOR]")
    li.setArt({'icon': 'DefaultAddonsSearch.png'})
    li.setInfo('video', {'plot': 'YouTube muestra hasta 20 resultados por busqueda. Si necesitas mas, prueba con terminos mas especificos.'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='yt_results_kb'), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def _yt_results_keyboard():
    h = int(sys.argv[1])
    kb = xbmc.Keyboard('', 'Buscar en YouTube')
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    txt = (kb.getText() or "").strip()
    if not txt:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    xbmc.executebuiltin(f"Container.Update({_u(action='yt_results', query=txt)})")

def _search_balandro_from_results(query):
    """Búsqueda en Balandro desde resultados."""
    if core_settings.are_external_integrations_disabled():
        return
    balandro_id = 'plugin.video.balandro'
    if not xbmc.getCondVisibility(f"System.HasAddon({balandro_id})"):
        xbmcgui.Dialog().ok("EspaDaily",
            "El plugin de Balandro no está instalado.\n\n"
            "Instala Balandro para usar esta función.")
        return

    kb = xbmc.Keyboard(query, 'Buscar en Balandro')
    kb.doModal()

    if kb.isConfirmed() and kb.getText().strip():
        texto = kb.getText().strip()
        item_data = {
            'channel': 'search',
            'action': 'search',
            'search_type': 'all',
            'buscando': texto,
        }
        payload = base64.b64encode(json.dumps(item_data).encode('utf-8')).decode('utf-8')
        balandro_url = f"plugin://{balandro_id}/?{urllib.parse.quote_plus(payload)}"
        xbmc.executebuiltin(f"Container.Update({balandro_url})")

def _search_jacktook_from_results(query, mode=''):
    if core_settings.are_external_integrations_disabled():
        return
    jacktook_id = 'plugin.video.jacktook'
    if not xbmc.getCondVisibility(f"System.HasAddon({jacktook_id})"):
        xbmcgui.Dialog().ok("EspaDaily",
            "El plugin de Jacktook no está instalado.\n\n"
            "Instala Jacktook para usar esta función.")
        return

    clean = re.sub(r'\[/?(?:B|I|COLOR[^\]]*)\]', '', query or '', flags=re.IGNORECASE)
    clean = re.sub(r'\s+', ' ', clean).strip()

    kb = xbmc.Keyboard(clean, 'Buscar en Jacktook')
    kb.doModal()
    if not (kb.isConfirmed() and kb.getText().strip()):
        return
    texto = kb.getText().strip()

    params = {
        'action': 'handle_tmdb_search',
        'mode': 'multi',
        'page': '1',
        'query': texto,
    }
    url = f"plugin://{jacktook_id}/?{urllib.parse.urlencode(params)}"
    xbmc.executebuiltin(f'Container.Update("{url}")')

def _show_watch_providers_dialog(title, mode):
    """Muestra un textviewer con las plataformas de streaming en España (TMDB)."""
    import metadata_enricher as me
    me_mode = mode if mode in ('movie', 'show') else 'movie'
    meta = me.enrich(title=title, media_type=me_mode)
    tmdb_id = str((meta.get('ids') or {}).get('tmdb', '')) if meta else ''
    if not tmdb_id:
        xbmcgui.Dialog().notification("EspaDaily", "No se pudo identificar en TMDB", xbmcgui.NOTIFICATION_WARNING)
        return
    providers = me.fetch_watch_providers(tmdb_id, media_type=me_mode)
    lines = []
    if providers.get('flatrate'):
        lines.append("Suscripción: " + ", ".join(providers['flatrate']))
    if providers.get('free'):
        lines.append("Gratis: " + ", ".join(providers['free']))
    if providers.get('rent'):
        lines.append("Alquiler: " + ", ".join(providers['rent']))
    if providers.get('buy'):
        lines.append("Compra: " + ", ".join(providers['buy']))
    if lines:
        xbmcgui.Dialog().textviewer(
            "¿Dónde ver '{0}' en España?".format(title),
            "\n".join(lines),
        )
    else:
        xbmcgui.Dialog().ok(
            "¿Dónde ver '{0}'?".format(title),
            "No disponible en ninguna plataforma de streaming en España según TMDB.\n\n"
            "Puede que aún esté en cines o que TMDB no tenga datos de España.",
        )


def _search_alternatives_prompt(query, ot='', mode=''):
    """Menú de alternativas al pulsar '¿No es lo que buscas?'."""
    opciones = []
    acciones = []
    _ext_off = core_settings.are_external_integrations_disabled()

    # Solo en rankings de pelis/series (mode definido), no en búsquedas manuales
    if mode in ('movie', 'show'):
        opciones.append("[COLOR lightgreen]¿Dónde verla en España?[/COLOR]")
        acciones.append("watch_providers")

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
        opciones.append("[COLOR red]Buscar en YouTube[/COLOR]")
        acciones.append("youtube")

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
        opciones.append("[COLOR white]Buscar en webs de torrent[/COLOR]")
        acciones.append("elementum")

    if mode == "movie":
        opciones.append("[COLOR cyan]Buscar en Dailymotion[/COLOR]")
        acciones.append("dailymotion_espadaily")

    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
        opciones.append("[COLOR deepskyblue]Buscar en addon Dailymotion (Gujal)[/COLOR]")
        acciones.append("dm_gujal")

    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.palantir3)"):
        opciones.append("[COLOR orange]Buscar en Palantir[/COLOR]")
        acciones.append("palantir")

    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.balandro)"):
        opciones.append("[COLOR chartreuse]Buscar en Balandro[/COLOR]")
        acciones.append("balandro")

    if not _ext_off and xbmc.getCondVisibility("System.HasAddon(plugin.video.jacktook)"):
        opciones.append("[COLOR mediumpurple]Buscar en Jacktook[/COLOR]")
        acciones.append("jacktook")

    # Editar búsqueda siempre el último
    opciones.append("[COLOR yellow]Editar búsqueda y reintentar[/COLOR]")
    acciones.append("edit")

    # Si solo hay "editar", ir directo al teclado
    if len(acciones) == 1:
        kb = xbmc.Keyboard(query, 'Editar Búsqueda')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=kb.getText(), ot=ot)})")
        return

    sel = xbmcgui.Dialog().select(
        f"¿Dónde quieres buscar '{query}'?", opciones)
    if sel < 0:
        return
    accion = acciones[sel]
    if accion == "watch_providers":
        _show_watch_providers_dialog(query, mode)
    elif accion == "elementum":
        kb = xbmc.Keyboard(query, 'Buscar en webs de torrent')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            _search_elementum(kb.getText())
    elif accion == "dm_gujal":
        _search_dailymotion_gujal(query)
    elif accion == "palantir":
        kb = xbmc.Keyboard(query, 'Buscar en Palantir 3')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            _search_palantir(kb.getText())
    elif accion == "youtube":
        _search_youtube_from_results(query)
    elif accion == "balandro":
        _search_balandro_from_results(query)
    elif accion == "jacktook":
        _search_jacktook_from_results(query, mode)
    elif accion == "dailymotion_espadaily":
        xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=query, ot=ot, mode=mode)})")
    elif accion == "edit":
        kb = xbmc.Keyboard(query, 'Editar Búsqueda')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            new_url = _u(action='lfr', q=kb.getText(), ot=ot, mode=mode) if mode else _u(action='lfr', q=kb.getText(), ot=ot)
            xbmc.executebuiltin(f"Container.Update({new_url})")


def router(ps):
    if not _check_validity():
        xbmcgui.Dialog().ok("EspaDaily", "Esta versión del addon ha sido desactivada remotamente.\nPor favor, busca una actualización.")
        return

    p = dict(urllib.parse.parse_qsl(ps)); a = p.get("action")

    # Guard: acciones que requieren connector activo
    _CONNECTOR_ACTIONS = {
        "ls", "fs", "lfr", "pv", "ls_rtve", "fs_rtve", "atresplayer_menu",
        "ls_mediaset", "download_video", "top_movies", "trending",
        "cache_top_movies_covers", "dm_playlists_search", "dm_user_playlists",
        "dm_view_playlist", "create_snapshot", "fav_news",
        "rtve_ext_router", "chopo_router", "mediaset_ext_router",
    }
    if a in _CONNECTOR_ACTIONS and connector is None:
        xbmcgui.Dialog().ok("EspaDaily", "El módulo de conexión no está disponible.\nComprueba tu conexión a internet y reinicia el addon.")
        return
    if a == "ls": _ls(p.get("cid"), page=int(p.get("page", 0)))
    elif a == "fs": _fs(p.get("au"), p.get("st"), p.get("sth", ""), p.get("pu", ""))
    elif a == "fs_mediaset": _fs_mediaset(p.get("purl", ""), p.get("st", ""), p.get("sth", ""), p.get("cid", ""))
    elif a == "lfr": _lfd(p.get("q"), p.get("ot"), p.get("mode", ""), nh=p.get("nh"))
    elif a == "pv": _pv(p.get("vid"), p.get("title", ""))
    elif a == "ep_dialog": _ep_dialog(p.get("q", ""), p.get("ot", ""), p.get("t", ""), p.get("eid", ""))
    elif a == "catalog_menu": _catalog_menu()
    elif a == "info_menu": info_menu()
    elif a == "info": _info()
    elif a == "vpn_info": xbmcgui.Dialog().ok("La VPN puede causar fallos o ser necesaria", "Algunos servidores bloquean VPNs (desactívala si algo no carga).\n\nEn Dailymotion puede ocurrir lo contrario, si no carga prueba activando la VPN.")
    elif a == "web_info": _web_info()
    elif a == "atresplayer_menu": atresplayer_menu()
    elif a == "rtve_menu": rtve_menu()
    elif a == "ls_rtve": _ls_rtve(p.get("cid"), page=int(p.get("page", 1)))
    elif a == "fs_rtve": _fs_rtve(p.get("pid"), p.get("st"), p.get("sth", ""))
    elif a == "manual_search": _manual_search()
    elif a == "top_movies": _top_movies(p.get("page"))
    elif a == "mediaset_menu": mediaset_menu()
    elif a == "advanced_menu": advanced_menu()
    elif a == "ls_mediaset":
        _ls_mediaset(p.get("cid"), page=int(p.get("page", 1)))
    elif a == "show_history": _show_history()
    elif a == "history_menu": _history_menu()
    elif a == "search_alt_prompt": _search_alternatives_prompt(p.get("q", ""), p.get("ot", ""), p.get("mode", ""))
    elif a == "clear_history": _clear_history()
    elif a == "remove_history_item": _remove_history_item(p.get("q"))
    elif a == "snapshots_menu": snapshots_menu()
    elif a == "create_snapshot": _create_snapshot()
    elif a == "view_snapshot": _view_snapshot(p.get("file"), p.get("path"))
    elif a == "delete_snapshot_menu": _delete_snapshot_menu()
    elif a == "delete_snapshot": _delete_snapshot(p.get("file"))
    elif a == "import_backup": _import_backup()
    elif a == "toggle_debug": _toggle_debug()
    elif a == "toggle_frozen": _toggle_frozen()
    elif a == "toggle_recent": _toggle_recent()
    elif a == "set_min_duration": _set_min_duration_filter()
    elif a == "toggle_prioritize_match": _toggle_prioritize_match()
    elif a == "show_favorites": _show_favorites()
    elif a == "add_favorite":
         try:
             params = json.loads(p.get("params", "{}"))
         except (ValueError, TypeError):
             # Si el JSON viene mal formado, extraemos solo la 'q' del título
             params = {'q': p.get("title", "")}
         added = core_settings.add_favorite(p.get("title"), p.get("fav_url"), p.get("icon"), p.get("platform"), p.get("fav_action"), params)
         if added:
             xbmcgui.Dialog().notification("EspaDaily", "Añadido a Favoritos", xbmcgui.NOTIFICATION_INFO)
         else:
             xbmcgui.Dialog().notification("EspaDaily", "Ya existe en Favoritos", xbmcgui.NOTIFICATION_WARNING)
    elif a == "remove_favorite":
         core_settings.remove_favorite(p.get("fav_url"))
         xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_rename":
         kb = xbmc.Keyboard(p.get("old_title"), 'Renombrar Favorito')
         kb.doModal()
         if kb.isConfirmed():
             new_t = kb.getText()
             if new_t:
                 core_settings.rename_favorite(p.get("fav_url"), new_t)
                 xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_up":
         if core_settings.move_favorite(p.get("fav_url"), "up"):
             xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_down":
         if core_settings.move_favorite(p.get("fav_url"), "down"):
             xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_news": _show_fav_news()
    elif a == "fav_backup_menu": _fav_backup_menu()
    elif a == "fav_export": _export_favorites()
    elif a == "fav_import": _import_favorites()
    elif a == "show_downloads": _show_downloads()
    elif a == "remove_download":
         core_settings.remove_download(p.get("dl_path"))
         xbmc.executebuiltin("Container.Refresh")
    elif a == "delete_download_file":
         _delete_download_file(p.get("dl_path"), p.get("title"))
    elif a == "check_repo_status": _check_repo_status()
    elif a == "clear_cache": _clear_cache()
    elif a == "cleanup_menu": _cleanup_menu()
    elif a == "cleanup_caches": _cleanup_caches()
    elif a == "vacuum_metadata_db": _vacuum_metadata_db_action()
    elif a == "refresh_main":
        if not _check_legal_compliance(): return
        _force_check_update()
    elif a == "toggle_full_context": _toggle_full_context()
    elif a == "toggle_snapshot_context": _toggle_snapshot_context()
    elif a == "snapshot_context_help": _snapshot_context_help()
    elif a == "download_video": _download_video(p.get("vid"), p.get("title"))
    elif a == "toggle_advanced_search": _toggle_advanced_search()
    elif a == "advanced_search_menu": _advanced_search_menu()


    elif a == "execute_adv_search": _execute_adv_search(p.get("mode", ""))
    elif a == "toggle_iptv_anti_errors": _toggle_iptv_anti_errors()
    elif a == "toggle_tdt_inputstream": _toggle_tdt_inputstream()
    elif a == "toggle_palantir_integration": _toggle_palantir_integration()
    elif a == "toggle_balandro_integration": _toggle_balandro_integration()
    elif a == "toggle_external_integrations": _toggle_external_integrations()
    elif a == "accessibility_menu": accessibility_menu()
    elif a == "acc_set_color": _acc_set_color_mode()
    elif a == "acc_toggle_bold": _acc_toggle_bold()
    elif a == "acc_toggle_symbols": _acc_toggle_symbols()
    elif a == "snapshot_info": _snapshot_info()
    elif a == "export_snapshot_menu": _export_snapshot_menu() # NUEVO
    elif a == "import_snapshot_menu": _import_snapshot_menu()
    
    # --- CATEGORY MANAGER RUTAS ---
    elif a == "cat_menu": category_manager.main_menu()
    elif a == "cat_create": category_manager.create_category()
    elif a == "cat_delete": category_manager.delete_category(p.get("name"))
    elif a == "cat_rename": category_manager.rename_category(p.get("name"))
    elif a == "cat_view": category_manager.view_category(p.get("name"))
    elif a == "cat_add_item_dialog": category_manager.add_item_dialog(p.get("q"))
    elif a == "cat_remove_item": category_manager.remove_item(p.get("cat"), p.get("q"))
    elif a == "cat_move_item": category_manager.move_item(p.get("from_cat"), p.get("q"))
    elif a == "cat_export": category_manager.export_categories()
    elif a == "cat_import": category_manager.import_categories()
    elif a == "cat_move_from_favs": 
         # Acción compuesta: Añadir a categoría -> Si éxito -> Borrar de favoritos
         if category_manager.add_item_dialog(p.get("q")):
             removed = core_settings.remove_favorite(p.get("fav_url"))
             if not removed:
                 # Debug: Avisar si falla el borrado
                 xbmcgui.Dialog().notification("EspaDaily", "Error: No se pudo quitar de favoritos", xbmcgui.NOTIFICATION_ERROR)
             else:
                 time.sleep(0.2) # Pequeña pausa para asegurar escritura
                 xbmc.executebuiltin("Container.Refresh")
    
    elif a == "toggle_palantir_search": _toggle_palantir_search()
    elif a == "palantir_search": _search_palantir(p.get("q"))
    elif a == "elementum_search": _search_elementum(p.get("q"))
    elif a == "yt_results": _yt_native_search_results(p.get("query", ""))
    elif a == "yt_results_kb": _yt_results_keyboard()
    
    elif a == "exp_menu": exploration_history.show_menu()
    elif a == "exp_edit": exploration_history.edit_query(p.get("q"))
    elif a == "exp_to_search": exploration_history.add_to_search_history(p.get("q"))
    elif a == "exp_delete": exploration_history.delete_entry(p.get("q"))
    elif a == "exp_clear_all": exploration_history.clear_all()
    elif a == "exp_set_depth": exploration_history.set_depth()
    elif a == "exp_search_direct": exploration_history.search_direct(p.get("q"))
    elif a == "sanitized_info": _sanitized_info()
    elif a == "version_notes": _version_notes()
    elif a == "version_notes_v1": _version_notes_v1()
    elif a == "view_error_log": _view_error_log()
    elif a == "cache_top_movies_covers": _cache_top_movies_covers()
    elif a == "clear_top_movies_cache": _clear_top_movies_cache()
    elif a == "edit_and_search":

        q = p.get("q", "")
        ot = p.get("ot", "")
        kb = xbmc.Keyboard(q, 'Editar y Buscar')
        kb.doModal()
        if kb.isConfirmed():
             nq = kb.getText()
             if nq:


                 xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=nq, ot=ot)})")


    # --- TRAKT ACIONES ---
    elif a == "menu_collections":
        import trakt_manager
        trakt_manager.menu_collections()
    elif a == "trakt_root":
        import trakt_manager
        trakt_manager.menu_trakt_root()
    elif a == "trakt_options":
        import trakt_manager
        trakt_manager.menu_options()
    elif a == "trakt_help_guide":
        import trakt_manager
        trakt_manager.help_guide()
    elif a == "trakt_set_key":
        import trakt_manager
        trakt_manager.set_api_key()
    elif a == "trakt_import":
        import trakt_manager
        trakt_manager.import_list()
    elif a == "trakt_view_list":
        import trakt_manager
        trakt_manager.view_list(p.get("list_id"), p.get("show_covers") == "1")
    elif a == "trakt_delete_list":
        import trakt_manager
        trakt_manager.delete_list(p.get("list_id"))
    elif a == "trakt_covers_menu":
        import trakt_manager
        trakt_manager.covers_menu(p.get("list_id"), p.get("show_covers", "0"))
    elif a == "trakt_cache_covers":
        import trakt_manager
        trakt_manager.cache_covers(p.get("list_id"))
    elif a == "trakt_clear_cache":
        import trakt_manager
        trakt_manager.clear_cache(p.get("list_id"))
    elif a == "trakt_refresh_defaults":
        import trakt_manager
        trakt_manager.refresh_all_lists()
    elif a == "trakt_cache_all_meta":
        import trakt_manager
        trakt_manager.cache_all_meta()
    elif a == "trakt_clear_all_meta":
        import trakt_manager
        trakt_manager.clear_all_meta()
    elif a == "filmaffinity_menu":
        import filmaffinity
        filmaffinity.menu()
    elif a == "filmaffinity_list":
        import filmaffinity
        filmaffinity.show_list(p.get("genre", ""))
    elif a == "filmaffinity_submenu":
        for label, action, plot in [
            ("En Cines España", "filmaffinity_cartelera", "Películas en cines en España según FilmAffinity."),
            ("Top Valoradas",   "filmaffinity_top",       "Las películas mejor valoradas de la historia."),
        ]:
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': 'DefaultVideoPlaylists.png'})
            li.setInfo('video', {'plot': plot})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action=action), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "filmaffinity_cartelera":
        import filmaffinity
        filmaffinity.show_cartelera()
    elif a == "filmaffinity_top":
        import filmaffinity
        filmaffinity.show_top()
    elif a == "sensacine_submenu":
        for label, action, plot in [
            ("En Cartelera", "sensacine_menu",     "Películas en cines según SensaCine."),
            ("Estrenos",     "sensacine_estrenos",  "Últimos estrenos según SensaCine."),
        ]:
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': 'DefaultVideoPlaylists.png'})
            li.setInfo('video', {'plot': plot})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action=action), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "sensacine_menu":
        import sensacine
        sensacine.show_cartelera()
    elif a == "sensacine_estrenos":
        import sensacine
        sensacine.show_estrenos()
    elif a == "cinemeta_top":
        import cinemeta
        cinemeta.show_top()
    elif a == "cinemeta_cache_meta":
        import cinemeta
        cinemeta.cache_meta()
    elif a == "cinemeta_clear_meta":
        import cinemeta
        cinemeta.clear_meta()
    elif a == "filmaffinity_cache_cartelera_meta":
        import filmaffinity
        filmaffinity.cache_cartelera_meta()
    elif a == "filmaffinity_clear_cartelera_meta":
        import filmaffinity
        filmaffinity.clear_cartelera_meta()
    elif a == "sensacine_cache_cartelera_meta":
        import sensacine
        sensacine.cache_cartelera_meta()
    elif a == "sensacine_clear_cartelera_meta":
        import sensacine
        sensacine.clear_cartelera_meta()
    elif a == "sensacine_cache_estrenos_meta":
        import sensacine
        sensacine.cache_estrenos_meta()
    elif a == "sensacine_clear_estrenos_meta":
        import sensacine
        sensacine.clear_estrenos_meta()


    elif a == "tmdb_lists_menu":
        import tmdb_lists
        tmdb_lists.show_menu()
    elif a == "tmdb_lists_show":
        import tmdb_lists
        tmdb_lists.show_list(p.get("endpoint", ""), p.get("media_type", "movie"), p.get("page", 1))

    elif a == "show_legal_txt": _show_legal_text()
    elif a == "revoke_legal": _revoke_legal()

    # --- URL PLAYER ---
    elif a == "open_url":
        import url_player; url_player.open_url_dialog()
    elif a == "url_input":
        import url_player; url_player.url_input()
    elif a == "url_history":
        import url_player; url_player.url_history_menu()
    elif a == "url_history_clear":
        import url_player; url_player.history_clear()
    elif a == "url_history_remove":
        import url_player; url_player.history_remove(p.get("url"))
    elif a == "url_bookmarks":
        import url_player; url_player.url_bookmarks_menu()
    elif a == "url_bookmark_save_from_history":
        import url_player; url_player.bookmark_save_from_history(p.get("url"))
    elif a == "url_bookmark_rename":
        import url_player; url_player.bookmark_rename(p.get("url"))
    elif a == "url_bookmark_delete":
        import url_player; url_player.bookmark_delete(p.get("url"))
    elif a == "url_play":
        import url_player; url_player.play_url_action(p.get("url"))
    elif a == "play_ace_result":
        _play_ace_result(p.get("infohash", ""), p.get("name", ""))
    elif a == "toggle_acestream_server_mode": _toggle_acestream_server_mode()
    elif a == "toggle_acestream_enabled": _toggle_acestream_enabled()
    elif a == "url_player_ensure_sn":
        import url_player; url_player.url_player_ensure_streamninja()

    # --- DM PLAYLISTS ---
    elif a == "dm_playlists_menu": _dm_playlists_menu()
    elif a == "dm_playlists_search": _dm_playlists_search()
    elif a == "dm_saved_channels": _dm_saved_channels_menu()
    elif a == "dm_save_channel": _dm_save_channel(p.get("user", ""), p.get("name", ""))
    elif a == "dm_delete_saved_channel": _dm_delete_saved_channel(p.get("user", ""))
    elif a == "dm_user_playlists": _dm_user_playlists(p.get("user"))
    elif a == "dm_view_playlist": _dm_view_playlist(p.get("pid"))

    # --- DM AJUSTES ---
    elif a == "set_dm_safe_level": _set_dm_safe_level()
    elif a == "set_dl_mode": _set_dl_mode()

    # --- BUSQUEDAS EXTERNAS ---
    elif a == "search_external_prompt": _search_external_prompt(p.get("q"))
    elif a == "dm_gujal_search": _search_dailymotion_gujal(p.get("q"))
    elif a == "search_atres_catalog": _search_atresplayer_catalog()
    elif a == "search_mediaset_catalog": _search_mediaset_catalog()
    elif a == "search_rtve_catalog": _search_rtve_catalog()
    elif a == "search_elementum_prompt": _search_elementum_prompt()
    elif a == "search_acestream_prompt": _search_acestream_prompt()
    elif a == "search_acestream_results": _search_acestream_results(p.get("q", ""))

    # --- EPG EN TEXTO ---
    elif a == "epg_texto_espadaily":
        import epg_texto; epg_texto.epg_texto_espadaily()
    elif a == "epg_texto_canal":
        import epg_texto; epg_texto.epg_texto_canal(p.get("ch_id", ""), p.get("ch_name", ""))
    elif a == "epg_texto_programa":
        import epg_texto; epg_texto.epg_texto_programa(p.get("title", ""), p.get("plot", ""))
    elif a == "epg_texto_refresh":
        import epg_texto; epg_texto.epg_texto_refresh()
    elif a == "noop": pass

    # --- TDT / TV EN DIRECTO ---
    elif a == "live_tv_menu": live_tv_menu()
    elif a == "live_mediaset_menu": live_mediaset_menu()
    elif a == "play_live_mediaset": play_live_mediaset(p.get("url", ""))
    elif a == "live_atres_menu": live_atres_menu()
    elif a == "play_live_atres": play_live_atres(p.get("ch_id", ""))
    elif a == "live_atres_now": live_atres_now()
    elif a == "play_media": play_atres_episode(p.get("url", ""))
    elif a == "live_rtve_menu": live_rtve_menu()
    elif a == "play_live_rtve": play_live_rtve(p.get("video_id", ""))
    elif a == "tdt_channels_json": tdt_channels_json()
    elif a == "tdt_json_ambit": tdt_json_ambit(p.get("url", ""))
    elif a == "tdt_channels": tdt_channels()
    elif a == "play_tdt": play_tdt(p.get("url", ""), p.get("title", ""))
    elif a == "add_custom_iptv": add_custom_iptv()
    elif a == "view_custom_iptv": view_custom_iptv(p.get("url", ""))
    elif a == "delete_custom_iptv": delete_custom_iptv(p.get("url", ""))

    # --- WATCH HISTORY ---
    elif a == "watch_history": _view_watch_history()
    elif a == "del_watch_entry": _del_watch_entry(p.get("url", ""))
    elif a == "clear_watch_history": _clear_watch_history()

    # --- TRENDING / MULTI-SEARCH ---
    elif a == "trending": _show_trending()
    elif a == "multi_search": _multi_search()

    # --- UTILIDADES ---
    elif a == "dm_open_browser": _dm_open_browser(p.get("url", ""))
    elif a == "log_menu": _log_menu()
    elif a == "view_kodi_log": _view_kodi_log()
    elif a == "view_kodi_log_full": _view_kodi_log_full()
    elif a == "view_kodi_log_errors": _view_kodi_log_errors()
    elif a == "search_kodi_log": _search_kodi_log()
    elif a == "log_info": _log_info()
    elif a == "export_log": _export_log()
    elif a == "view_log_visual": _view_log_visual()
    elif a == "show_log_line": _show_log_line(p.get("data", ""))
    elif a == "clear_error_log": _clear_error_log()
    elif a == "open_flowfav": _open_flowfav()
    elif a == "flowfav_install": _flowfav_install()
    elif a == "set_cache_config": _set_cache_config()
    elif a == "set_download_path": _set_download_path()
    elif a == "toggle_dev_mode": _toggle_dev_mode()

    # --- BACKUPS ---
    elif a == "backups_menu": _backups_menu()
    elif a == "create_backup_full": _create_backup_full()
    elif a == "list_backups": _list_backups()
    elif a == "restore_backup_selective": _restore_backup_selective(p.get("file", ""))
    elif a == "delete_single_backup": _delete_single_backup(p.get("file", ""))
    elif a == "slyguy_install": _slyguy_install(p.get("addon_id", ""), p.get("title", "Addon"))
    elif a == "export_favs_txt": _export_favorites_txt()
    elif a == "open_atresdaily": _open_atresdaily()
    elif a == "atresdaily_install": _atresdaily_install()
    elif a == "open_espatv": _open_espatv()
    elif a == "open_loiolog": _open_loiolog()
    elif a == "loiolog_install": _loiolog_install()

    # --- ESPAKODI ADDONS MENU ---
    elif a == "espakodi_addons_menu": espakodi_addons_menu()
    elif a == "ek_espatv_launch": _ek_espatv_launch()
    elif a == "ek_espadaily_launch": _ek_espadaily_launch()
    elif a == "ek_atresdaily_launch": _ek_atresdaily_launch()
    elif a == "ek_loiolog_launch": _ek_loiolog_launch()
    elif a == "ek_flowfav_launch": _ek_flowfav_launch()
    elif a == "ek_streamninja_launch": _ek_streamninja_launch()

    # --- UNIVERSO ---
    elif a == "show_universo":
        import universo; universo.show()

    # Esta sección se ha hecho mirando el addon Chop0 TV, la idea no es hacer lo mismo, muchas gracias Chop0.
    elif a == "rtve_ext_router" or a == "chopo_router":
        if not _require_connector(): return
        ra = p.get("rtve_action") or p.get("chopo_action") or "main_list"
        fn = connector._RTVE_EXT_ACTIONS.get(ra)
        if fn:
            fn(p)
        else:
            xbmcgui.Dialog().notification("EspaDaily", "Accion RTVE no encontrada: " + ra, xbmcgui.NOTIFICATION_WARNING)

    # Esta sección se ha hecho mirando el addon Chop0 TV, la idea no es hacer lo mismo, muchas gracias Chop0.
    elif a == "mediaset_ext_router":
        if not _require_connector(): return
        ma = p.get("ms_action", "main_list")
        fn = connector._MEDIASET_EXT_ACTIONS.get(ma)
        if fn:
            fn(p)
        else:
            xbmcgui.Dialog().notification("EspaDaily", "Accion Mediaset no encontrada: " + ma, xbmcgui.NOTIFICATION_WARNING)

    else:
        # Verificaciones previas al menu principal
        if not _check_legal_compliance(): return
        if not _check_validity(): return
        # Honeypot: detectar manipulacion del connector
        if getattr(connector, '_DEBUG_MODE_BACKDOOR', False):
            xbmcgui.Dialog().ok("SEGURIDAD", "Se ha detectado una modificaci\u00f3n no autorizada en el m\u00f3dulo de conexi\u00f3n.")
            return
        import stats
        stats.ping()
        _check_messages()
        main_menu()

if __name__ == "__main__":
    try:
        router(sys.argv[2][1:])
    except Exception as e:
        import traceback
        _log_error(f"Unhandled exception: {str(e)}\n{traceback.format_exc()}")
        xbmcgui.Dialog().ok("EspaDaily - Error", "Ocurrió un error inesperado al procesar la ruta.\n\nConsulta el log de errores en Ajustes Avanzados.")
