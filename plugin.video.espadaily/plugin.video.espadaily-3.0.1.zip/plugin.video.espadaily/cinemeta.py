# -*- coding: utf-8 -*-
import sys
import json
import os
import time
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import requests

_TOP_URL     = "https://cinemeta-catalogs.strem.io/top/catalog/movie/top.json"
_POSTER_BASE = "https://images.metahub.space/poster/medium"
_CM_TTL      = 6 * 3600
_CM_MIN      = 3


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])

def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'espadaily_cinemeta_cache.json')


def _load_cache():
    empty = {"top": {}}
    try:
        path = _cache_path()
        if not os.path.exists(path):
            return empty
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if not isinstance(data.get("top"), dict):
            return empty
        return data
    except Exception as e:
        xbmc.log(f"[EspaDaily-CM] cache load error: {e}", xbmc.LOGWARNING)
        return empty


def _save_cache(data):
    try:
        path = _cache_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception as e:
        xbmc.log(f"[EspaDaily-CM] cache save error: {e}", xbmc.LOGWARNING)


def _cache_fresh(cache):
    c = cache.get("top", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _CM_TTL


def _fetch_top():
    """Saca el top de pelis, None si peta."""
    try:
        r = requests.get(_TOP_URL, timeout=12)
        xbmc.log(f"[EspaDaily-CM] top -> {r.status_code}", xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        metas = r.json().get("metas", [])
        films = []
        for m in metas:
            imdb_id = m.get("imdb_id") or m.get("id", "")
            name = m.get("name", "").strip()
            if not name:
                continue
            poster = f"{_POSTER_BASE}/{imdb_id}/img" if imdb_id else m.get("poster", "")
            year = str(m.get("year", ""))
            films.append({
                "id":     imdb_id,
                "title":  name,
                "poster": poster,
                "year":   year,
                "genre":  ", ".join(m.get("genres") or m.get("genre") or []),
                "plot":   m.get("description", ""),
            })
        if len(films) < _CM_MIN:
            xbmc.log(f"[EspaDaily-CM] resultado sospechoso ({len(films)} films), ignorando", xbmc.LOGWARNING)
            return None
        xbmc.log(f"[EspaDaily-CM] {len(films)} películas en top", xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log(f"[EspaDaily-CM] fetch error: {e}", xbmc.LOGERROR)
        return None


def _get_top_films():
    """Top de pelis con cache, sin tocar la UI."""
    cache = _load_cache()

    if _cache_fresh(cache):
        films = cache["top"]["films"]
        xbmc.log(f"[EspaDaily-CM] top desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films

    fetched = _fetch_top()
    if fetched is not None:
        films = fetched
        cache["top"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("top", {}).get("films"):
        films = cache["top"]["films"]
        xbmc.log("[EspaDaily-CM] Cinemeta inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_top():
    films = _get_top_films()
    if not films:
        xbmcgui.Dialog().notification("EspaDaily", "No se pudo cargar Cinemeta", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    for f in films:
        label = f"{f['title']} ({f['year']})" if f.get("year") else f["title"]
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
        li.setInfo('video', {
            'title':     f['title'],
            'year':      int(f['year']) if f.get('year', '').isdigit() else 0,
            'genre':     f.get('genre', ''),
            'plot':      f.get('plot', ''),
            'mediatype': 'movie',
        })
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=f['poster'], mode='movie')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())
