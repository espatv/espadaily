# -*- coding: utf-8 -*-
# EspaDaily — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
import sys
import json
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import core_settings
import requests

def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])

def _get_thumb_cache_path(list_id):
    import os
    import xbmcvfs
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, f"trakt_thumbs_{list_id}.json")

def _load_thumb_cache(list_id):
    import os
    path = _get_thumb_cache_path(list_id)
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception: pass
    return {}

def menu_collections():

    li = xbmcgui.ListItem(label="Listas de Trakt.tv")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_root"), listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(_handle())

def _get_tmdb_thumb(tmdb_id, fallback):
    if not tmdb_id:
        return fallback
    try:
        r = requests.get(
            f"https://api.themoviedb.org/3/movie/{tmdb_id}",
            params={"api_key": core_settings._ESPADAILY_TMDB_API_KEY},
            timeout=5
        )
        if r.status_code == 200:
            poster_path = r.json().get("poster_path")
            if poster_path:
                return f"https://image.tmdb.org/t/p/w342{poster_path}"
    except Exception:
        pass
    return fallback

def menu_trakt_root():
    core_settings.seed_default_trakt_lists(core_settings.get_trakt_api_key())

    li = xbmcgui.ListItem(label="[COLOR yellow][B]>>> Actualizar nombres y datos <<<[/B][/COLOR]")
    li.setArt({'icon': 'DefaultAddonUpdate.png'})
    li.setInfo('video', {'plot': "Obtiene el nombre real y el número de ítems de todas las listas desde Trakt."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_refresh_defaults"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR blue]Opciones / Importar Lista[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_options"), listitem=li, isFolder=True)
    

    lists = core_settings.get_trakt_lists()
    for l in lists:
        count = l.get('item_count', 0)
        label = f"{l['name']} [COLOR gray]({count} ítems)[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultFolder.png'})
        li.setInfo('video', {'plot': f"ID: {l['id']}\nUsuario: {l['user']}\nTotal: {count} elementos."})
        
        cm = [("Eliminar lista", f"RunPlugin({_u(action='trakt_delete_list', list_id=l['id'])})")]
        li.addContextMenuItems(cm)
        
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_view_list", list_id=l['id']), listitem=li, isFolder=True)
        
    xbmcplugin.endOfDirectory(_handle())

def refresh_all_lists():
    api_key = core_settings.get_trakt_api_key()
    if not api_key:
        xbmcgui.Dialog().notification("Error", "No hay API Key configurada", xbmcgui.NOTIFICATION_ERROR)
        return
    lists = core_settings.get_trakt_lists()
    if not lists:
        xbmcgui.Dialog().notification("Trakt", "No hay listas para actualizar", xbmcgui.NOTIFICATION_INFO)
        return
    headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': api_key}
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaDaily", "Actualizando listas de Trakt...")
    total = len(lists)
    for i, l in enumerate(lists):
        if pDialog.iscanceled():
            break
        pDialog.update(int((i / total) * 100), f"({i+1}/{total}) {l['name']}")
        try:
            r = requests.get(f"https://api.trakt.tv/lists/{l['id']}", headers=headers, timeout=5)
            if r.status_code == 200:
                data = r.json()
                l['name'] = data.get('name', l['name'])
                l['user'] = data.get('user', {}).get('username', l.get('user', 'official')) if isinstance(data.get('user'), dict) else l.get('user', 'official')
                l['item_count'] = data.get('item_count', l.get('item_count', 0))
        except Exception:
            pass
    pDialog.close()
    settings = core_settings.get_trakt_settings()
    existing = {l['id']: l for l in settings.get('lists', [])}
    for l in lists:
        if l['id'] in existing:
            existing[l['id']].update(l)
    settings['lists'] = list(existing.values())
    core_settings.save_trakt_settings(settings)
    xbmcgui.Dialog().notification("EspaDaily", "Listas actualizadas correctamente", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def menu_options():

    

    li = xbmcgui.ListItem(label="[COLOR yellow][B]Guía: Cómo obtener tu API Key (Paso a Paso)[/B][/COLOR]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    li.setInfo('video', {'plot': "Instrucciones detalladas de cómo registrarte en Trakt.tv para obtener tu propia llave Client ID."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_help_guide"), listitem=li, isFolder=False)


    key = core_settings.get_trakt_api_key()
    status = "[COLOR green]CONFIGURADA[/COLOR]" if key else "[COLOR red]NO CONFIGURADA[/COLOR]"
    
    li = xbmcgui.ListItem(label=f"Configurar API Key {status}")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Pulsa aquí para introducir tu Client ID una vez lo tengas."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_set_key"), listitem=li, isFolder=False)
    

    if key:
        li = xbmcgui.ListItem(label="Importar Lista por ID")
        li.setArt({'icon': 'DefaultAddonService.png'})
        li.setInfo('video', {'plot': "Introduce el ID numérico de la lista pública (ej: 21583416)"})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_import"), listitem=li, isFolder=False)
    
    xbmcplugin.endOfDirectory(_handle())

def help_guide():
    heading = "[COLOR yellow]GUÍA: CONFIGURAR TRAKT.TV[/COLOR]"
    
    text = (
        "[B]PASO 1: REGISTRO[/B]\n"
        "Entra en tu navegador (PC o móvil) a:\n"
        "[COLOR cyan]https://trakt.tv/oauth/applications[/COLOR]\n"
        "Identifícate con tu cuenta de usuario.\n\n"
        
        "[B]PASO 2: CREAR APLICACIÓN[/B]\n"
        "Pulsa el botón verde [B]NEW APPLICATION[/B].\n\n"
        
        "[B]PASO 3: RELLENAR DATOS[/B]\n"
        "Copia y pega exactamente esto en los cuadros:\n"
        " • [B]Name:[/B] EspaDaily\n"
        " • [B]Description:[/B] Addon de Kodi\n"
        " • [B]Redirect uri:[/B] urn:ietf:wg:oauth:2.0:oob\n"
        " • [B]Javascript (cors) origins:[/B] (Vacío)\n"
        " • [B]Permissions:[/B] No marques nada.\n\n"
        "Baja al final y dale al botón morado [B]SAVE APP[/B].\n\n"
        
        "[B]PASO 4: OBTENER EL CÓDIGO[/B]\n"
        "Tras guardar, aparecerán varios códigos.\n"
        "Busca el que dice [B]Client ID[/B] (es una línea de letras y números).\n\n"
        "Copia ese código y pégalo en el menú 'Configurar API Key' de este addon.\n\n"
        "--------------------------------------------------\n"
        "[I]* Nota: La API Key es personal y gratuita. Solo sirve para que el addon pueda leer las listas públicas de Trakt.tv.[/I]"
    )
    
    xbmcgui.Dialog().textviewer(heading, text)

def set_api_key():
    k = xbmc.Keyboard(core_settings.get_trakt_api_key(), 'Introduce Trakt Client ID (API Key)')
    k.doModal()
    if k.isConfirmed():
        key = k.getText().strip()
        core_settings.set_trakt_api_key(key)
        xbmcgui.Dialog().notification("EspaDaily", "API Key Guardada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")

def import_list():
    key = core_settings.get_trakt_api_key()
    if not key:
        xbmcgui.Dialog().notification("Error", "Configura la API Key primero", xbmcgui.NOTIFICATION_ERROR)
        return

    k = xbmc.Keyboard('', 'Introduce ID numérico de la lista')
    k.doModal()
    if k.isConfirmed():
        list_id = k.getText().strip()
        if not list_id: return
        

        headers = {
            'Content-Type': 'application/json',
            'trakt-api-version': '2',
            'trakt-api-key': key
        }
        

        pDialog = xbmcgui.DialogProgress()
        pDialog.create("EspaDaily", "Importando lista de Trakt...")
        
        try:
    
            r = requests.get(f'https://api.trakt.tv/lists/{list_id}', headers=headers)
            if r.status_code != 200:
                pDialog.close()
                xbmcgui.Dialog().notification("Error Trakt", f"Error {r.status_code}: No se pudo leer la lista", xbmcgui.NOTIFICATION_ERROR)
                return
            
            data = r.json()
            name = data.get('name', f'Lista {list_id}')
            user = data.get('user', {}).get('username', 'Unknown')
            item_count = data.get('item_count', 0)
            
    
            core_settings.add_trakt_list(list_id, name, user, item_count)
            
            pDialog.close()
            
            # Preguntar si abrirla ya
            if xbmcgui.Dialog().yesno("EspaDaily", f"Lista '{name}' importada con éxito.\n\n¿Quieres abrirla ahora mismo?"):
                xbmc.executebuiltin(f"Container.Update({_u(action='trakt_view_list', list_id=list_id)})")
            else:
                # Volver a la raiz de Trakt
                xbmc.executebuiltin(f"Container.Update({_u(action='trakt_root')})")
            
        except Exception as e:
            if 'pDialog' in locals(): pDialog.close()
            xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)

def view_list(list_id, show_covers=False):
    try:
        key = core_settings.get_trakt_api_key()
        if not key:
            xbmcgui.Dialog().notification("Error", "Falta API Key", xbmcgui.NOTIFICATION_ERROR)
            return

        headers = {
            'Content-Type': 'application/json',
            'trakt-api-version': '2',
            'trakt-api-key': key
        }
        
        url = f'https://api.trakt.tv/lists/{list_id}/items?extended=full'
        
        try:
            r = requests.get(url, headers=headers, timeout=15)
            items = r.json()
        except Exception:
            xbmcplugin.endOfDirectory(_handle())
            return

        if not isinstance(items, list):
            msg = items.get('message', 'Error desconocido') if isinstance(items, dict) else "Respuesta no válida"
            xbmcgui.Dialog().ok("Error Trakt", f"No se pudieron cargar los elementos:\n{msg}")
            xbmcplugin.endOfDirectory(_handle())
            return

        addon = xbmcaddon.Addon()
        ai = addon.getAddonInfo('icon')
        af = addon.getAddonInfo('fanart')


        cache = _load_thumb_cache(list_id)
        has_cache = len(cache) > 0


        if not has_cache:
            li = xbmcgui.ListItem(label="[COLOR yellow][B]>>> Descargar y GUARDAR Carátulas permanentemente <<<[/B][/COLOR]")
            li.setArt({'icon': 'DefaultAddonService.png'})
            li.setInfo('video', {'plot': "Esta opción buscará las fotos de TODA la lista y las guardará en tu dispositivo.\n\n[COLOR red][B]ADVERTENCIA:[/B][/COLOR] Una vez guardadas, la lista tardará un poco más en cargar cada vez que entres, pero se verá mucho mejor."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_cache_covers", list_id=list_id), listitem=li, isFolder=False)
            
            if not show_covers:
                li = xbmcgui.ListItem(label="[COLOR green]Ver carátulas solo esta vez (Sin guardar)[/COLOR]")
                li.setArt({'icon': 'DefaultAddonService.png'})
                xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_view_list", list_id=list_id, show_covers="1"), listitem=li, isFolder=True)
            else:
                li = xbmcgui.ListItem(label="[COLOR cyan]Ocultar carátulas temporales[/COLOR]")
                li.setArt({'icon': 'DefaultAddonService.png'})
                xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_view_list", list_id=list_id, show_covers="0"), listitem=li, isFolder=True)
        else:
            li = xbmcgui.ListItem(label="[COLOR red][B]Borrar carátulas guardadas (Volver a carga rápida)[/B][/COLOR]")
            li.setArt({'icon': 'DefaultIconError.png'})
            li.setInfo('video', {'plot': "Elimina las fotos guardadas para que la lista vuelva a cargar al instante."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_clear_cache", list_id=list_id), listitem=li, isFolder=False)

        for item in items:
            if not isinstance(item, dict): continue
            t = item.get('type')
            data = item.get(t)
            if not data: continue
            
            title = data.get('title')
            year = data.get('year')
            overview = data.get('overview', '')
            tagline = data.get('tagline', '')
            
            tmdb_id = data.get('ids', {}).get('tmdb')
            item_key = f"{title}_{year}"
            label = f"{title} ({year})" if year else title
            li = xbmcgui.ListItem(label=label)

            thumb = ai
            if has_cache and item_key in cache:
                thumb = cache[item_key]
            elif show_covers:
                thumb = _get_tmdb_thumb(tmdb_id, ai)

            li.setArt({'icon': 'DefaultVideo.png', 'thumb': thumb, 'poster': thumb, 'fanart': af})
            
            video_info = {
                'title': title,
                'year': year,
                'plot': f"[B]{tagline}[/B]\n\n{overview}" if tagline else overview,
                'mediatype': 'movie' if t == 'movie' else 'tvshow'
            }
            li.setInfo('video', video_info)
            
            cm = []
            if core_settings.is_palantir_installed() and core_settings.is_palantir_integration_enabled():
                cm.append(("Buscar en Palantir 3", f"RunPlugin({_u(action='palantir_search', q=title)})"))
            
            cm.append(("Buscar en webs de torrent", f"RunPlugin({_u(action='elementum_search', q=title)})"))
            

            params_json = json.dumps({'q': title})
            fav_url = _u(action='add_favorite', title=title, fav_url=title, icon=thumb, platform='Trakt', fav_action='lfr', params=params_json)
            cm.append(("Añadir a Mis Favoritos", f"RunPlugin({fav_url})"))
            
            li.addContextMenuItems(cm)
            li.setProperty('IsPlayable', 'false')
            play_url = _u(action='search_alt_prompt', q=title, ot=thumb, mode='movie')
            xbmcplugin.addDirectoryItem(handle=_handle(), url=play_url, listitem=li, isFolder=False)
            
        xbmcplugin.endOfDirectory(_handle())
    except Exception as e:
        xbmcgui.Dialog().ok("Error Trakt", f"Ocurrió un error al ver la lista:\n{str(e)}")

def cache_covers(list_id):
    try:
        if not xbmcgui.Dialog().yesno("EspaDaily", 
            "[B]AVISO DE CARGA:[/B]\n\n"
            "Al guardar las carátulas, el addon mostrará las fotos siempre que entres.\n\n"
            "Esto hará que la lista [COLOR yellow]tarde más en cargar[/COLOR] cada vez.\n\n"
            "¿Quieres continuar con la descarga?"):
            return

        key = core_settings.get_trakt_api_key()
        headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': key}
        url = f'https://api.trakt.tv/lists/{list_id}/items?extended=full'
        
        try:
            r = requests.get(url, headers=headers, timeout=15)
            items = r.json()
        except Exception: 
            xbmcgui.Dialog().notification("Error", "No se pudo conectar con Trakt", xbmcgui.NOTIFICATION_ERROR)
            return

        if not isinstance(items, list):
            msg = items.get('message', 'Error desconocido') if isinstance(items, dict) else "Respuesta no válida"
            xbmcgui.Dialog().ok("Error Trakt", f"No se pudo obtener la lista para cachear:\n{msg}")
            return

        cache = {}
        pDialog = xbmcgui.DialogProgress()
        pDialog.create("EspaDaily", "Descargando carátulas...")
        
        total = len(items)
        if total == 0:
            pDialog.close()
            xbmcgui.Dialog().notification("Trakt", "La lista está vacía", xbmcgui.NOTIFICATION_INFO)
            return

        for i, item in enumerate(items):
            if pDialog.iscanceled(): break
            if not isinstance(item, dict): continue
            
            t = item.get('type')
            data = item.get(t)
            if not data: continue
            
            title = data.get('title')
            year = data.get('year')
            tmdb_id = data.get('ids', {}).get('tmdb')
            item_key = f"{title}_{year}"

            percent = int((float(i) / total) * 100)
            pDialog.update(percent, f"Procesando ({i}/{total}): {title}")

            thumb = _get_tmdb_thumb(tmdb_id, None)
            if thumb:
                cache[item_key] = thumb
            
        pDialog.close()
        
        if cache:
            with open(_get_thumb_cache_path(list_id), 'w', encoding='utf-8') as f:
                json.dump(cache, f)
            xbmcgui.Dialog().notification("EspaDaily", "Carátulas guardadas correctamente", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().ok("Error Cache", f"Error al guardar carátulas:\n{str(e)}")

def clear_cache(list_id):
    try:
        import os
        path = _get_thumb_cache_path(list_id)
        if os.path.exists(path):
            os.remove(path)
            xbmcgui.Dialog().notification("EspaDaily", "Cache eliminada: Volvemos a carga rápida", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)

def delete_list(list_id):
    try:
        if xbmcgui.Dialog().yesno("Eliminar Lista", "¿Seguro que quieres borrar esta lista de tu colección?"):
            core_settings.remove_trakt_list(list_id)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)
